(function () {
	'use strict';

	const selectors = {
		offload: '#cfr2-bulk-offload-all',
		restore: '#cfr2-bulk-restore-all',
		deleteLocal: '#cfr2-bulk-delete-local',
		cancel: '#cfr2-cancel-bulk',
		progressSection: '#cfr2-bulk-progress-section',
		progressFill: '.cfr2-progress-fill',
		progressPercent: '.cfr2-progress-percentage',
		progressText: '.cfr2-progress-text',
		currentFile: '#cfr2-current-file',
		elapsed: '#cfr2-elapsed',
		terminal: '#cfr2-terminal-output',
	};

	const state = {
		monitor: null,
		elapsed: null,
		startedAt: null,
		actionLabel: '',
		lastDone: -1,
	};

	document.addEventListener('click', handleBulkClick, true);

	function handleBulkClick(event) {
		const button = event.target.closest([
			selectors.offload,
			selectors.restore,
			selectors.deleteLocal,
			selectors.cancel,
		].join(','));

		if (!button) {
			return;
		}

		event.preventDefault();
		event.stopPropagation();
		event.stopImmediatePropagation();

		if (button.matches(selectors.cancel)) {
			cancelBulk();
			return;
		}

		if (button.matches(selectors.offload)) {
			queueBulk('cfr2_bulk_offload_all', button, 'offload', 'Queue all media files for background offload to R2?');
			return;
		}

		if (button.matches(selectors.restore)) {
			queueBulk('cfr2_bulk_restore_all', button, 'restore', 'Queue all offloaded media for background restore?');
			return;
		}

		if (button.matches(selectors.deleteLocal)) {
			queueBulk('cfr2_bulk_delete_local', button, 'local file deletion', 'Queue local-file deletion for all offloaded media? Files will remain on R2.');
		}
	}

	function queueBulk(action, button, actionLabel, confirmMessage) {
		if (!window.confirm(confirmMessage)) {
			return;
		}

		const originalText = button.textContent;
		button.disabled = true;
		button.textContent = 'Queuing...';

		post(action, {}).then(function (response) {
			if (!response || !response.success) {
				const message = getMessage(response, 'Failed to queue files.');
				log('error', message);
				toast(message, 'error');
				button.disabled = false;
				button.textContent = originalText;
				return;
			}

			const total = parseInt(response.data && response.data.total, 10) || 0;
			state.actionLabel = actionLabel;
			state.lastDone = -1;
			state.startedAt = Date.now();

			log('info', 'Queued ' + total + ' files for ' + actionLabel + '. You can leave this page; processing will continue in the background.');
			toast('Queued ' + total + ' files for background processing.', 'success');
			showBackgroundUi();
			startMonitoring();

			if (action === 'cfr2_bulk_offload_all' && response.data && response.data.has_more) {
				continueQueueingOffload(parseInt(response.data.cursor, 10) || 0, total);
			}
		}).catch(function () {
			log('error', 'Failed to queue files.');
			toast('Failed to queue files.', 'error');
			button.disabled = false;
			button.textContent = originalText;
		});
	}

	function continueQueueingOffload(cursor, totalQueued) {
		if (!cursor) {
			return;
		}

		window.setTimeout(function () {
			post('cfr2_bulk_offload_all', { cursor: cursor }).then(function (response) {
				if (!response || !response.success) {
					log('warning', getMessage(response, 'Queue continuation stopped. Already queued items will keep processing.'));
					return;
				}

				const added = parseInt(response.data && response.data.total, 10) || 0;
				const nextTotal = totalQueued + added;
				log('info', 'Queued another ' + added + ' files. Total queued so far: ' + nextTotal + '.');

				if (response.data && response.data.has_more) {
					continueQueueingOffload(parseInt(response.data.cursor, 10) || 0, nextTotal);
				} else {
					log('success', 'Finished queueing all remaining files. Total queued: ' + nextTotal + '.');
				}
			}).catch(function () {
				log('warning', 'Queue continuation failed. Already queued items will keep processing.');
			});
		}, 1500);
	}

	function startMonitoring() {
		stopTimersOnly();
		updateElapsed();
		state.elapsed = window.setInterval(updateElapsed, 1000);
		pollProgress();
		state.monitor = window.setInterval(pollProgress, 5000);
	}

	function pollProgress() {
		post('cfr2_get_bulk_progress', {}).then(function (response) {
			if (!response || !response.success) {
				return;
			}

			const data = response.data || {};
			const completed = parseInt(data.completed, 10) || 0;
			const failed = parseInt(data.failed, 10) || 0;
			const pending = parseInt(data.pending, 10) || 0;
			const processing = parseInt(data.processing, 10) || 0;
			const total = parseInt(data.total, 10) || 0;
			const done = completed + failed;
			const percent = total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0;

			setText(selectors.currentFile, data.current_file || '');
			setText(selectors.progressPercent, percent + '%');
			const fill = document.querySelector(selectors.progressFill);
			if (fill) {
				fill.style.width = percent + '%';
			}

			const progressText = document.querySelector(selectors.progressText);
			if (progressText) {
				progressText.innerHTML = '<span style="color:#46b450;">✓ ' + completed + '</span> | <span style="color:#dc3232;">✗ ' + failed + '</span> | <span style="color:#646970;">○ ' + (pending + processing) + ' remaining</span>';
			}

			if (done !== state.lastDone) {
				state.lastDone = done;
				log('info', 'Background progress: ' + done + '/' + total + ' completed.');
			}

			if (total > 0 && !data.is_running) {
				log('success', 'Background ' + state.actionLabel + ' completed. Completed: ' + completed + ' | Failed: ' + failed);
				toast('Background operation completed.', failed > 0 ? 'error' : 'success');
				stopBackgroundUi();
			}
		}).catch(function () {
			log('warning', 'Progress check failed. The background queue may still be running.');
		});
	}

	function cancelBulk() {
		if (!window.confirm('Cancel bulk operation?')) {
			return;
		}

		post('cfr2_cancel_bulk', {}).then(function (response) {
			const message = getMessage(response, 'Bulk operation cancelled.');
			log('warning', message);
			toast(message, response && response.success ? 'success' : 'error');
			stopBackgroundUi();
		}).catch(function () {
			toast('Failed to cancel bulk operation', 'error');
		});
	}

	function showBackgroundUi() {
		show(selectors.progressSection, true);
		show(selectors.cancel, true);
		show(selectors.offload, false);
		show(selectors.restore, false);
		show(selectors.deleteLocal, false);
	}

	function stopBackgroundUi() {
		stopTimersOnly();
		show(selectors.cancel, false);
		show(selectors.offload, true);
		show(selectors.restore, true);
		show(selectors.deleteLocal, true);
		enable(selectors.offload);
		enable(selectors.restore);
		enable(selectors.deleteLocal);
		refreshCounts();
	}

	function stopTimersOnly() {
		if (state.monitor) {
			window.clearInterval(state.monitor);
			state.monitor = null;
		}
		if (state.elapsed) {
			window.clearInterval(state.elapsed);
			state.elapsed = null;
		}
	}

	function refreshCounts() {
		post('cfr2_get_bulk_counts', {}).then(function (response) {
			if (!response || !response.success || !response.data) {
				return;
			}

			updateButton(selectors.offload, response.data.not_offloaded, 'Offload All Media');
			updateButton(selectors.restore, response.data.offloaded, 'Restore All');
			updateButton(selectors.deleteLocal, response.data.disk_saveable, 'Free Disk Space');
		}).catch(function () {});
	}

	function updateButton(selector, count, label) {
		const button = document.querySelector(selector);
		if (!button) {
			return;
		}

		count = parseInt(count, 10) || 0;
		button.textContent = label + ' (' + count + ')';
		button.style.display = count > 0 ? '' : 'none';
		button.disabled = false;
	}

	function updateElapsed() {
		if (!state.startedAt) {
			return;
		}

		const seconds = Math.floor((Date.now() - state.startedAt) / 1000);
		const minutes = Math.floor(seconds / 60);
		setText(selectors.elapsed, minutes + 'm ' + (seconds % 60) + 's');
	}

	function post(action, data) {
		const body = new URLSearchParams(Object.assign({
			action: action,
			nonce: getNonce(),
		}, data || {}));

		return window.fetch(cfr2Admin.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
			},
			body: body.toString(),
		}).then(function (response) {
			return response.json();
		});
	}

	function getNonce() {
		const field = document.getElementById('cfr2_nonce');
		return field ? field.value : (window.cfr2Admin && cfr2Admin.nonce ? cfr2Admin.nonce : '');
	}

	function getMessage(response, fallback) {
		return response && response.data && response.data.message ? response.data.message : fallback;
	}

	function show(selector, visible) {
		const element = document.querySelector(selector);
		if (element) {
			element.style.display = visible ? '' : 'none';
		}
	}

	function enable(selector) {
		const element = document.querySelector(selector);
		if (element) {
			element.disabled = false;
		}
	}

	function setText(selector, value) {
		const element = document.querySelector(selector);
		if (element) {
			element.textContent = value;
		}
	}

	function toast(message, type) {
		const container = document.getElementById('cloudflare-r2-offload-cdn-toast');
		if (!container) {
			return;
		}

		const item = document.createElement('div');
		item.className = 'cloudflare-r2-offload-cdn-toast-item ' + (type || 'success');
		item.textContent = message;
		container.appendChild(item);
		window.setTimeout(function () {
			item.remove();
		}, 4000);
	}

	function log(type, message) {
		const output = document.querySelector(selectors.terminal);
		if (!output) {
			return;
		}

		const line = document.createElement('div');
		line.className = 'cfr2-terminal-line cfr2-terminal-' + type;
		line.innerHTML = '<span class="cfr2-terminal-time">[' + new Date().toLocaleTimeString() + ']</span><span class="cfr2-terminal-icon">' + icon(type) + '</span><span class="cfr2-terminal-message"></span>';
		line.querySelector('.cfr2-terminal-message').textContent = message;
		output.appendChild(line);
		output.scrollTop = output.scrollHeight;
	}

	function icon(type) {
		if (type === 'success') {
			return '✓';
		}
		if (type === 'error') {
			return '✗';
		}
		if (type === 'warning') {
			return '!';
		}
		return '●';
	}
})();
