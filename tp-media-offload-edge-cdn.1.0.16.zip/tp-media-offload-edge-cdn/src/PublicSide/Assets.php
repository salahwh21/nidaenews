<?php
/**
 * Assets class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\PublicSide;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Interfaces\HookableInterface;
use Salahdev\NidaEdge\Constants\NonceActions;
use Salahdev\NidaEdge\Services\PluginSettings;

/**
 * Assets class - handles script and style enqueuing.
 */
class Assets implements HookableInterface {

	/**
	 * Register hooks.
	 */
	public function register_hooks(): void {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_public_assets' ) );
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_admin_assets( string $hook ): void {
		$is_plugin_page = strpos( $hook, 'tp-media-offload-edge-cdn' ) !== false;
		$is_media_page  = in_array( $hook, array( 'upload.php', 'post.php' ), true );

		// Check if editing an attachment.
		if ( 'post.php' === $hook ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
			if ( $post_id && 'attachment' !== get_post_type( $post_id ) ) {
				$is_media_page = false;
			}
		}

		// Only load on plugin pages or media pages.
		if ( ! $is_plugin_page && ! $is_media_page ) {
			return;
		}

		wp_enqueue_style(
			'cloudflare-r2-offload-cdn-admin',
			\CFR2_URL . 'assets/css/admin.css',
			array(),
			\CFR2_VERSION
		);

		wp_enqueue_style(
			'nidaedge-admin-refresh',
			\CFR2_URL . 'assets/css/nidaedge-admin.css',
			array( 'cloudflare-r2-offload-cdn-admin' ),
			\CFR2_VERSION
		);

		wp_enqueue_script(
			'cloudflare-r2-offload-cdn-admin',
			\CFR2_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			\CFR2_VERSION,
			true
		);

		wp_enqueue_script(
			'nidaedge-bulk-background',
			\CFR2_URL . 'assets/js/nidaedge-bulk-background.js',
			array( 'cloudflare-r2-offload-cdn-admin' ),
			\CFR2_VERSION,
			true
		);

		wp_localize_script(
			'cloudflare-r2-offload-cdn-admin',
			'cfr2Admin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( NonceActions::SETTINGS ),
				'strings' => array(
					'confirm' => __( 'Are you sure?', 'tp-media-offload-edge-cdn' ),
					'saving'  => __( 'Saving...', 'tp-media-offload-edge-cdn' ),
					'saved'   => __( 'Settings saved.', 'tp-media-offload-edge-cdn' ),
					'error'   => __( 'An error occurred. Please try again.', 'tp-media-offload-edge-cdn' ),
				),
			)
		);

		if ( $this->is_arabic_locale() ) {
			wp_add_inline_script(
				'cloudflare-r2-offload-cdn-admin',
				$this->get_arabic_admin_inline_script(),
				'after'
			);
		}
	}

	/**
	 * Enqueue public assets.
	 */
	public function enqueue_public_assets(): void {
		$settings       = PluginSettings::get();
		$should_enqueue = ! empty( $settings['cdn_enabled'] ) || ! empty( $settings['r2_public_domain'] );

		if ( ! $should_enqueue ) {
			return;
		}

		wp_enqueue_style(
			'cloudflare-r2-offload-cdn-public',
			\CFR2_URL . 'assets/css/public.css',
			array(),
			\CFR2_VERSION
		);

		wp_enqueue_script(
			'cloudflare-r2-offload-cdn-public',
			\CFR2_URL . 'assets/js/public.js',
			array(),
			\CFR2_VERSION,
			true
		);
	}

	/**
	 * Check whether the current admin locale is Arabic.
	 *
	 * @return bool
	 */
	private function is_arabic_locale(): bool {
		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();

		return 0 === strpos( (string) $locale, 'ar' );
	}

	/**
	 * Add a lightweight Arabic layer for dynamic JavaScript messages.
	 *
	 * PHP-rendered strings use gettext. This covers messages that are created
	 * dynamically by the bundled admin script after AJAX actions.
	 *
	 * @return string
	 */
	private function get_arabic_admin_inline_script(): string {
		$text_map = array(
			'Connection failed' => 'فشل الاتصال',
			'Connection test failed' => 'فشل اختبار الاتصال',
			'Queue all media files for offload to R2?' => 'هل تريد إضافة كل الوسائط إلى قائمة الرفع إلى R2؟',
			'Queue all media files for background offload to R2?' => 'هل تريد إضافة كل الوسائط إلى طابور الرفع في الخلفية إلى R2؟',
			'Queue all offloaded media for background restore?' => 'هل تريد إضافة كل الوسائط المرفوعة إلى طابور الاسترجاع في الخلفية؟',
			'Queue local-file deletion for all offloaded media? Files will remain on R2.' => 'هل تريد إضافة حذف الملفات المحلية إلى الطابور لكل الوسائط المرفوعة؟ ستبقى الملفات على R2.',
			'Queuing...' => 'جار الإضافة إلى القائمة...',
			'Offload All Media' => 'رفع كل الوسائط إلى R2',
			'Failed to queue files.' => 'تعذرت إضافة الملفات إلى القائمة.',
			'Failed to start bulk offload' => 'تعذر بدء الرفع الجماعي',
			'Restore all media files from R2 to local?' => 'هل تريد استرجاع كل الوسائط من R2 إلى التخزين المحلي؟',
			'Restore All' => 'استرجاع الكل',
			'Failed to queue files for restore.' => 'تعذرت إضافة الملفات للاسترجاع.',
			'Failed to start bulk restore' => 'تعذر بدء الاسترجاع الجماعي',
			'Delete local files for all offloaded media? Files will remain on R2. This cannot be undone.' => 'حذف الملفات المحلية لكل الوسائط المرفوعة؟ ستبقى الملفات على R2 ولا يمكن التراجع عن ذلك.',
			'Free Disk Space' => 'توفير مساحة القرص',
			'Failed to queue files for deletion.' => 'تعذرت إضافة الملفات للحذف.',
			'Failed to start bulk delete' => 'تعذر بدء حذف الملفات المحلية',
			'Cancel bulk operation?' => 'هل تريد إلغاء العملية الجماعية؟',
			'Bulk operation cancelled by user.' => 'تم إلغاء العملية الجماعية بواسطة المستخدم.',
			'Bulk operation cancelled.' => 'تم إلغاء العملية الجماعية.',
			'Background operation completed.' => 'اكتملت العملية في الخلفية.',
			'Failed to cancel bulk operation' => 'تعذر إلغاء العملية الجماعية',
			'Network error. Retrying in 3 seconds...' => 'خطأ في الشبكة. ستتم إعادة المحاولة بعد 3 ثوان.',
			'Remove deployed Worker? This will disable CDN URL rewriting.' => 'حذف Worker المنشور؟ سيؤدي ذلك إلى تعطيل تبديل روابط CDN.',
			'Deployment failed' => 'فشل النشر',
			'Worker deployment failed' => 'فشل نشر Worker',
			'Remove failed' => 'فشل الحذف',
			'Worker removal failed' => 'فشل حذف Worker',
			'Please enter a CDN URL first' => 'أدخل رابط CDN أولاً',
			'Validating...' => 'جار الفحص...',
			'Checking DNS...' => 'جار فحص DNS...',
			'Enable Proxy Now' => 'تفعيل البروكسي الآن',
			'DNS record found but needs configuration' => 'تم العثور على سجل DNS لكنه يحتاج ضبطاً',
			'DNS record found with proxy enabled. Ready to deploy!' => 'تم العثور على سجل DNS والبروكسي مفعّل. جاهز للنشر!',
			'DNS validation passed!' => 'نجح فحص DNS!',
			'Validation request failed' => 'فشل طلب الفحص',
			'DNS validation failed' => 'فشل فحص DNS',
			'Enabling...' => 'جار التفعيل...',
			'Failed to enable proxy' => 'تعذر تفعيل البروكسي',
			'Ready to deploy!' => 'جاهز للنشر!',
			'Loading...' => 'جار التحميل...',
			'No pending items in queue.' => 'لا توجد عناصر قيد الانتظار.',
			'File' => 'الملف',
			'Action' => 'الإجراء',
			'Status' => 'الحالة',
			'Cancel' => 'إلغاء',
			'Cancelling...' => 'جار الإلغاء...',
			'Cancel all pending items? This will not affect items currently being processed.' => 'إلغاء كل العناصر قيد الانتظار؟ لن يؤثر ذلك على العناصر التي تتم معالجتها الآن.',
			'Clearing...' => 'جار المسح...',
			'Clear All' => 'مسح الكل',
			'Failed to clear pending items' => 'تعذر مسح العناصر قيد الانتظار',
			'Failed to load pending items.' => 'تعذر تحميل العناصر قيد الانتظار.',
			'Failed to cancel item' => 'تعذر إلغاء العنصر',
			'Retry all failed items?' => 'إعادة محاولة كل العناصر الفاشلة؟',
			'Failed to retry items' => 'تعذرت إعادة محاولة العناصر',
			'Failed to retry item' => 'تعذرت إعادة محاولة العنصر',
			'Offloading...' => 'جار الرفع إلى R2...',
			'Offloaded to R2' => 'تم الرفع إلى R2',
			'Offload to R2' => 'رفع إلى R2',
			'Request failed' => 'فشل الطلب',
			'Clear process log?' => 'مسح سجل العملية؟',
			'Failed to clear log' => 'تعذر مسح السجل',
			'Ready. Click "Offload All Media" to start.' => 'جاهز. اضغط "رفع كل الوسائط إلى R2" للبدء.',
			'remaining' => 'متبقية',
			'offload' => 'الرفع إلى R2',
			'restore' => 'الاسترجاع',
			'local file deletion' => 'حذف الملفات المحلية',
			'delete local' => 'حذف المحلي',
			'You can leave this page; processing will continue in the background.' => 'يمكنك مغادرة هذه الصفحة؛ ستستمر المعالجة في الخلفية.',
			'Progress check failed. The background queue may still be running.' => 'فشل فحص التقدم. قد يكون الطابور ما زال يعمل في الخلفية.',
			'Queue continuation stopped. Already queued items will keep processing.' => 'توقفت متابعة إضافة الملفات للطابور. العناصر التي أضيفت ستستمر بالمعالجة.',
			'Queue continuation failed. Already queued items will keep processing.' => 'فشلت متابعة إضافة الملفات للطابور. العناصر التي أضيفت ستستمر بالمعالجة.',
		);

		$patterns = array(
			array( 'pattern' => 'Offload All Media \\((\\d+)\\)', 'replacement' => 'رفع كل الوسائط إلى R2 ($1)' ),
			array( 'pattern' => 'Restore All \\((\\d+)\\)', 'replacement' => 'استرجاع الكل ($1)' ),
			array( 'pattern' => 'Free Disk Space \\((\\d+)\\)', 'replacement' => 'توفير مساحة القرص ($1)' ),
			array( 'pattern' => 'Queued (\\d+) files for offload\\.', 'replacement' => 'تمت إضافة $1 ملفاً للرفع إلى R2.' ),
			array( 'pattern' => 'Queued (\\d+) files for offload\\. You can leave this page; processing will continue in the background\\.', 'replacement' => 'تمت إضافة $1 ملفاً للرفع إلى R2. يمكنك مغادرة هذه الصفحة وستستمر المعالجة في الخلفية.' ),
			array( 'pattern' => 'Queued (\\d+) files for background processing\\.', 'replacement' => 'تمت إضافة $1 ملفاً للمعالجة في الخلفية.' ),
			array( 'pattern' => 'Queued (\\d+) files for restore\\.', 'replacement' => 'تمت إضافة $1 ملفاً للاسترجاع.' ),
			array( 'pattern' => 'Queued (\\d+) files for local deletion\\.', 'replacement' => 'تمت إضافة $1 ملفاً لحذف النسخة المحلية.' ),
			array( 'pattern' => 'Background progress: (\\d+)/(\\d+) completed\\.', 'replacement' => 'تقدم الخلفية: اكتمل $1 من $2.' ),
			array( 'pattern' => 'Background (.+) completed\\. Completed: (\\d+) \\| Failed: (\\d+)', 'replacement' => 'اكتملت عملية $1 في الخلفية. اكتمل: $2 | فشل: $3' ),
			array( 'pattern' => 'Queued another (\\d+) files\\. Total queued so far: (\\d+)\\.', 'replacement' => 'تمت إضافة $1 ملفاً إضافياً. إجمالي ما أضيف حتى الآن: $2.' ),
			array( 'pattern' => 'Finished queueing all remaining files\\. Total queued: (\\d+)\\.', 'replacement' => 'اكتملت إضافة كل الملفات المتبقية للطابور. الإجمالي: $1.' ),
			array( 'pattern' => 'Queued (\\d+) items for retry\\.', 'replacement' => 'تمت إضافة $1 عنصر لإعادة المحاولة.' ),
			array( 'pattern' => 'Starting (.+) process\\.\\.\\.', 'replacement' => 'جار بدء عملية $1...' ),
			array( 'pattern' => 'Completed: (\\d+) \\| Failed: (\\d+)', 'replacement' => 'اكتمل: $1 | فشل: $2' ),
			array( 'pattern' => 'Bulk (.+) completed', 'replacement' => 'اكتملت عملية $1 الجماعية' ),
			array( 'pattern' => '(\\d+) remaining', 'replacement' => '$1 متبقية' ),
		);

		$payload = array(
			'text'     => $text_map,
			'patterns' => $patterns,
		);

		$json = wp_json_encode( $payload );
		if ( false === $json ) {
			return '';
		}

		return 'window.cfr2ArabicUi=' . $json . ';
(function(){
	const payload = window.cfr2ArabicUi || {text:{},patterns:[]};
	const exact = payload.text || {};
	const patterns = (payload.patterns || []).map(function(item){
		return { regex: new RegExp(item.pattern), replacement: item.replacement };
	});
	const skipTags = new Set(["SCRIPT","STYLE","TEXTAREA","PRE","CODE","INPUT","SELECT","OPTION"]);
	const nativeConfirm = window.confirm;
	window.confirm = function(message){
		return nativeConfirm.call(window, translate(String(message || "")));
	};
	function translate(value){
		if (!value) {
			return value;
		}
		const leading = value.match(/^\\s*/)[0];
		const trailing = value.match(/\\s*$/)[0];
		let core = value.trim();
		if (exact[core]) {
			return leading + exact[core] + trailing;
		}
		patterns.forEach(function(item){
			core = core.replace(item.regex, item.replacement);
		});
		Object.keys(exact).forEach(function(key){
			if (key.length < 12) {
				return;
			}
			if (core.indexOf(key) !== -1) {
				core = core.split(key).join(exact[key]);
			}
		});
		return leading + core + trailing;
	}
	function shouldSkip(node){
		const parent = node && node.parentElement;
		return !parent || skipTags.has(parent.tagName);
	}
	function translateNode(node){
		if (!node || node.nodeType !== Node.TEXT_NODE || shouldSkip(node)) {
			return;
		}
		const next = translate(node.nodeValue);
		if (next !== node.nodeValue) {
			node.nodeValue = next;
		}
	}
	function walk(root){
		if (!root) {
			return;
		}
		const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
		let node;
		while ((node = walker.nextNode())) {
			translateNode(node);
		}
	}
	function run(){
		document.querySelectorAll(".cloudflare-r2-offload-cdn-settings-wrap, .cfr2-offload-status, .cfr2-pending-list").forEach(walk);
	}
	document.addEventListener("DOMContentLoaded", function(){
		run();
		const root = document.querySelector(".cloudflare-r2-offload-cdn-settings-wrap") || document.body;
		new MutationObserver(function(mutations){
			mutations.forEach(function(mutation){
				mutation.addedNodes.forEach(function(node){
					if (node.nodeType === Node.TEXT_NODE) {
						translateNode(node);
					} else if (node.nodeType === Node.ELEMENT_NODE) {
						walk(node);
					}
				});
				if (mutation.type === "characterData") {
					translateNode(mutation.target);
				}
			});
		}).observe(root, {childList:true, subtree:true, characterData:true});
	});
})();';
	}
}
