<?php
/**
 * Settings Constants.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Constants;

defined( 'ABSPATH' ) || exit;

/**
 * Settings constants.
 */
class Settings {
	public const OPTION_KEY     = 'cfr2_settings';
	public const CF_TOKEN_KEY   = 'cfr2_cf_api_token';
	public const SETTINGS_GROUP = 'cfr2_settings_group';
}
