<?php
/**
 * Admin Menu class.
 *
 * Slim coordinator for admin menu registration and AJAX handler delegation.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Admin;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Admin\Ajax\SettingsAjaxHandler;
use Salahdev\NidaEdge\Admin\Ajax\BulkOperationAjaxHandler;
use Salahdev\NidaEdge\Admin\Ajax\WorkerAjaxHandler;
use Salahdev\NidaEdge\Admin\Ajax\ActivityAjaxHandler;
use Salahdev\NidaEdge\Constants\Settings;
use Salahdev\NidaEdge\Constants\BatchConfig;
use Salahdev\NidaEdge\Interfaces\HookableInterface;
use Salahdev\NidaEdge\Services\PluginSettings;

/**
 * AdminMenu class - handles admin menu registration and AJAX delegation.
 */
class AdminMenu implements HookableInterface {

	/**
	 * Admin menu slug.
	 */
	private const MENU_SLUG = 'tp-media-offload-edge-cdn';

	/**
	 * Settings AJAX handler.
	 *
	 * @var SettingsAjaxHandler
	 */
	private SettingsAjaxHandler $settings_handler;

	/**
	 * Bulk operation AJAX handler.
	 *
	 * @var BulkOperationAjaxHandler
	 */
	private BulkOperationAjaxHandler $bulk_handler;

	/**
	 * Worker AJAX handler.
	 *
	 * @var WorkerAjaxHandler
	 */
	private WorkerAjaxHandler $worker_handler;

	/**
	 * Activity AJAX handler.
	 *
	 * @var ActivityAjaxHandler
	 */
	private ActivityAjaxHandler $activity_handler;

	/**
	 * Constructor - initialize AJAX handlers.
	 */
	public function __construct() {
		$this->settings_handler = new SettingsAjaxHandler();
		$this->bulk_handler     = new BulkOperationAjaxHandler();
		$this->worker_handler   = new WorkerAjaxHandler();
		$this->activity_handler = new ActivityAjaxHandler();
	}

	/**
	 * Register hooks.
	 */
	public function register_hooks(): void {
		add_action( 'admin_menu', array( $this, 'add_menu_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		// Delegate AJAX hooks to specialized handlers.
		$this->settings_handler->register_hooks();
		$this->bulk_handler->register_hooks();
		$this->worker_handler->register_hooks();
		$this->activity_handler->register_hooks();
	}

	/**
	 * Add menu page.
	 */
	public function add_menu_page(): void {
		add_menu_page(
			__( 'NidaEdge Settings', 'tp-media-offload-edge-cdn' ),
			__( 'NidaEdge', 'tp-media-offload-edge-cdn' ),
			'manage_options',
			self::MENU_SLUG,
			array( SettingsPage::class, 'render' ),
			$this->get_menu_icon(),
			80
		);
	}

	/**
	 * Get a small RT admin menu icon.
	 *
	 * @return string SVG data URI.
	 */
	private function get_menu_icon(): string {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="20" height="20" aria-hidden="true"><rect x="1.8" y="1.8" width="16.4" height="16.4" rx="4" fill="black"/><text x="10" y="12.9" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="7.2" font-weight="700" fill="white">RT</text></svg>';

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- WordPress admin menu supports SVG data URIs.
		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}


	/**
	 * Register settings.
	 */
	public function register_settings(): void {
		register_setting(
			Settings::SETTINGS_GROUP,
			Settings::OPTION_KEY,
			array(
				'type'              => 'array',
				'default'           => PluginSettings::defaults(),
				'sanitize_callback' => array( $this, 'sanitize_registered_settings' ),
			)
		);
	}

	/**
	 * Sanitize settings registered through register_setting.
	 *
	 * @param mixed $input Raw option value.
	 * @return array Sanitized option value.
	 */
	public function sanitize_registered_settings( $input ): array {
		if ( ! is_array( $input ) ) {
			return PluginSettings::defaults();
		}

		$existing = PluginSettings::get();
		$merged   = wp_parse_args( $input, $existing );

		$secret_value = array_key_exists( 'r2_secret_access_key', $input )
			? sanitize_text_field( (string) $input['r2_secret_access_key'] )
			: '********';

		$token_value = array_key_exists( 'cf_api_token', $input )
			? (string) $input['cf_api_token']
			: '********';

		$normalized = array(
			'r2_account_id'        => sanitize_text_field( (string) ( $merged['r2_account_id'] ?? '' ) ),
			'r2_region'            => sanitize_text_field( (string) ( $merged['r2_region'] ?? 'auto' ) ),
			'r2_endpoint'          => esc_url_raw( (string) ( $merged['r2_endpoint'] ?? '' ) ),
			'r2_access_key_id'     => sanitize_text_field( (string) ( $merged['r2_access_key_id'] ?? '' ) ),
			'r2_secret_access_key' => $secret_value,
			'r2_bucket'            => sanitize_text_field( (string) ( $merged['r2_bucket'] ?? '' ) ),
			'r2_public_domain'     => esc_url_raw( (string) ( $merged['r2_public_domain'] ?? '' ) ),
			'auto_offload'         => ! empty( $merged['auto_offload'] ) ? 1 : 0,
			'batch_size'           => absint( $merged['batch_size'] ?? BatchConfig::DEFAULT_SIZE ),
			'keep_local_files'     => ! empty( $merged['keep_local_files'] ) ? 1 : 0,
			'sync_delete'          => ! empty( $merged['sync_delete'] ) ? 1 : 0,
			'cdn_enabled'          => ! empty( $merged['cdn_enabled'] ) ? 1 : 0,
			'local_fallback_enabled' => ! empty( $merged['local_fallback_enabled'] ) ? 1 : 0,
			'cdn_url'              => esc_url_raw( (string) ( $merged['cdn_url'] ?? '' ) ),
			'quality'              => absint( $merged['quality'] ?? 85 ),
			'image_format'         => sanitize_text_field( (string) ( $merged['image_format'] ?? 'webp' ) ),
			'smart_sizes'          => ! empty( $merged['smart_sizes'] ) ? 1 : 0,
			'content_max_width'    => absint( $merged['content_max_width'] ?? 800 ),
			'cf_api_token'         => $token_value,
		);

		return $this->settings_handler->sanitize_settings( $normalized );
	}

	/**
	 * Get default settings.
	 *
	 * @return array Default settings.
	 */
	private function get_default_settings(): array {
		return PluginSettings::defaults();
	}
}

