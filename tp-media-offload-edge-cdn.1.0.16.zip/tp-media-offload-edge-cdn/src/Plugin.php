<?php
/**
 * Main Plugin class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Traits\SingletonTrait;
use Salahdev\NidaEdge\Core\Loader;
use Salahdev\NidaEdge\Admin\AdminMenu;
use Salahdev\NidaEdge\Admin\MediaLibraryExtension;
use Salahdev\NidaEdge\Admin\DeactivationHandler;
use Salahdev\NidaEdge\PublicSide\Assets;
use Salahdev\NidaEdge\Database\Schema;
use Salahdev\NidaEdge\Services\PluginSettings;
use Salahdev\NidaEdge\Hooks\MediaUploadHooks;
use Salahdev\NidaEdge\Services\URLRewriter;
use Salahdev\NidaEdge\Integrations\WooCommerceIntegration;
use Salahdev\NidaEdge\Integrations\GutenbergIntegration;
use Salahdev\NidaEdge\Integrations\RestApiIntegration;

/**
 * Plugin class - main entry point.
 */
class Plugin {

	use SingletonTrait;

	/**
	 * Hook loader instance.
	 *
	 * @var Loader
	 */
	private Loader $loader;

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->loader = new Loader();
		$this->load_textdomain();
		$this->register_inline_arabic_translations();
		Schema::maybe_upgrade();
		PluginSettings::migrate_if_needed();
		$this->define_hooks();
		$this->loader->run();
	}

	/**
	 * Load bundled translations.
	 */
	private function load_textdomain(): void {
		load_plugin_textdomain(
			'tp-media-offload-edge-cdn',
			false,
			dirname( \CFR2_BASENAME ) . '/languages'
		);
	}

	/**
	 * Register Arabic translations without relying on stale generated MO files.
	 */
	private function register_inline_arabic_translations(): void {
		add_filter( 'gettext', array( $this, 'translate_inline_arabic' ), 20, 3 );
	}

	/**
	 * Translate key admin strings for Arabic WordPress dashboards.
	 *
	 * @param string $translation Current translation.
	 * @param string $text        Original text.
	 * @param string $domain      Text domain.
	 * @return string
	 */
	public function translate_inline_arabic( string $translation, string $text, string $domain ): string {
		if ( 'tp-media-offload-edge-cdn' !== $domain ) {
			return $translation;
		}

		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		if ( 0 !== strpos( (string) $locale, 'ar' ) ) {
			return $translation;
		}

		$translations = self::get_inline_arabic_translations();

		return $translations[ $text ] ?? $translation;
	}

	/**
	 * Key Arabic translations used in the admin screens.
	 *
	 * @return array<string, string>
	 */
	private static function get_inline_arabic_translations(): array {
		return array(
			'NidaEdge Settings' => 'إعدادات NidaEdge',
			'NidaEdge' => 'NidaEdge',
			'by salahdev' => 'تطوير salahdev',
			'Dashboard' => 'لوحة التحكم',
			'Storage' => 'التخزين',
			'CDN' => 'CDN',
			'Offload' => 'النقل إلى R2',
			'Bulk Actions' => 'العمليات الجماعية',
			'System Info' => 'معلومات النظام',
			'Offload WordPress media to Cloudflare R2 storage and serve via CDN with automatic image optimization (WebP/AVIF, resize, quality).' => 'ارفع وسائط ووردبريس إلى Cloudflare R2 وقدّمها عبر CDN مع تحسين تلقائي للصور بصيغ WebP/AVIF وتغيير الحجم والجودة.',
			'Save Settings' => 'حفظ الإعدادات',
			'Settings saved.' => 'تم حفظ الإعدادات.',
			'No changes detected.' => 'لا توجد تغييرات.',
			'Failed to save settings. Please try again.' => 'تعذر حفظ الإعدادات. حاول مرة أخرى.',
			'Security check failed.' => 'فشل التحقق الأمني.',
			'Permission denied.' => 'الصلاحية مرفوضة.',
			'Too many requests. Please try again later.' => 'طلبات كثيرة جداً. حاول لاحقاً.',
			'An error occurred. Please try again.' => 'حدث خطأ. حاول مرة أخرى.',
			'Saving...' => 'جار الحفظ...',
			'Are you sure?' => 'هل أنت متأكد؟',
			'R2 Storage Configuration' => 'إعدادات تخزين R2',
			'Configure your Cloudflare R2 storage credentials. Get these from Cloudflare Dashboard > R2 > Manage R2 API Tokens.' => 'أدخل بيانات تخزين Cloudflare R2. يمكنك الحصول عليها من لوحة Cloudflare ثم R2 ثم إدارة رموز API الخاصة بـ R2.',
			'Account ID' => 'معرّف الحساب',
			'Your Cloudflare account ID (alphanumeric).' => 'معرّف حساب Cloudflare.',
			'Region' => 'المنطقة',
			'Use "auto" for Cloudflare R2. Change only for compatible S3 providers that require a specific region.' => 'استخدم "auto" مع Cloudflare R2. غيّرها فقط عند استخدام مزوّد S3 متوافق يحتاج منطقة محددة.',
			'S3 Endpoint' => 'نقطة نهاية S3',
			'Optional. Leave empty to build the Cloudflare R2 endpoint from Account ID. Do not include the bucket name at the end.' => 'اختياري. اتركه فارغاً لبناء رابط R2 من معرّف الحساب. لا تضف اسم الحاوية في النهاية.',
			'Access Key ID' => 'معرّف مفتاح الوصول',
			'R2 Access Key ID from API token.' => 'معرّف مفتاح الوصول من رمز R2 API.',
			'Secret Access Key' => 'مفتاح الوصول السري',
			'R2 Secret Access Key (encrypted in database). Leave blank to keep existing value.' => 'مفتاح R2 السري، ويتم تشفيره في قاعدة البيانات. اتركه فارغاً للإبقاء على القيمة الحالية.',
			'Bucket Name' => 'اسم الحاوية',
			'R2 bucket name (lowercase alphanumeric and hyphens only).' => 'اسم حاوية R2 بأحرف صغيرة وأرقام وشرطات فقط.',
			'Public Domain' => 'الدومين العام',
			'Public URL for R2 bucket. Required for CDN Worker deployment.' => 'الرابط العام لحاوية R2. مطلوب لتشغيل Worker الخاص بالـ CDN.',
			'Optional public URL for direct R2 delivery. The Worker uses an R2 binding, so public bucket access is not required for image optimization.' => 'رابط عام اختياري للتسليم المباشر من R2. يستخدم Worker ربط R2 مباشر، لذلك لا يلزم فتح الحاوية للعامة من أجل تحسين الصور.',
			'Connection Test' => 'اختبار الاتصال',
			'Test Connection' => 'اختبار الاتصال',
			'Verify R2 credentials by testing connection.' => 'تحقق من بيانات R2 عبر اختبار الاتصال.',
			'Connection successful!' => 'تم الاتصال بنجاح!',
			'Use R2.dev subdomain (e.g., https://pub-xxx.r2.dev) or custom domain.' => 'يمكن استخدام نطاق R2.dev مثل https://pub-xxx.r2.dev أو دومين مخصص.',
			'To enable public access, follow the "Public buckets" section in Cloudflare R2 documentation.' => 'لتفعيل الوصول العام، اتبع قسم "Public buckets" في توثيق Cloudflare R2.',
			'CDN Configuration' => 'إعدادات CDN',
			'Configure CDN URL rewriting and image optimization settings.' => 'إعداد تبديل روابط CDN وتحسين الصور.',
			'Token fix build: %s' => 'إصدار إصلاح الرمز: %s',
			'Enable CDN (Auto Avif/WebP & Optimization)' => 'تفعيل CDN والتحويل التلقائي إلى AVIF/WebP',
			'Replace media URLs with CDN URLs for optimized delivery.' => 'استبدال روابط الوسائط بروابط CDN لتسليم أسرع ومحسّن.',
			'Local Emergency Fallback' => 'الرجوع المحلي للطوارئ',
			'Serve local WordPress media URLs instead of CDN/R2 URLs. Use this as an emergency switch if the Worker or R2 delivery is unavailable.' => 'استخدم روابط وسائط ووردبريس المحلية بدلاً من روابط CDN/R2 عند الطوارئ أو تعطل Worker.',
			'Cloudflare API Token' => 'رمز Cloudflare API',
			'Required permissions: Workers Scripts, Workers R2, Zone, Zone Settings, DNS, Workers Routes, Cache Purge' => 'الصلاحيات المطلوبة: Workers Scripts و Workers R2 و Zone و Zone Settings و DNS و Workers Routes و Cache Purge',
			'Required permissions: Workers Scripts Edit, Workers R2 Storage Edit, Zone Read, DNS Edit, Workers Routes Edit, Cache Purge' => 'الصلاحيات المطلوبة: تعديل Workers Scripts، تعديل Workers R2 Storage، قراءة Zone، تعديل DNS، تعديل Workers Routes، وتنظيف Cache Purge',
			'Paste the raw token only. Do not include the word "Bearer".' => 'ألصق الرمز الخام فقط بدون كلمة "Bearer".',
			'Paste the raw token only. If you paste an Authorization Bearer header or Cloudflare curl verify command, the plugin will extract the token automatically.' => 'ألصق الرمز الخام فقط. وإذا ألصقت ترويسة Authorization Bearer أو أمر curl الخاص بالتحقق من Cloudflare فستستخرج الإضافة الرمز تلقائياً.',
			'Save Token Only' => 'حفظ الرمز فقط',
			'Saving token...' => 'جار حفظ الرمز...',
			'Paste a new Cloudflare API token before saving.' => 'ألصق رمز Cloudflare API جديداً قبل الحفظ.',
			'If the main Save Settings button does not keep the token, use Save Token Only. This stores the token in a separate option and the plugin will read it first.' => 'إذا كان زر حفظ الإعدادات لا يحتفظ بالرمز، استخدم حفظ الرمز فقط. سيتم تخزين الرمز في خيار مستقل وستقرأه الإضافة أولاً.',
			'wp-config.php fallback' => 'حل بديل عبر wp-config.php',
			'If your host or security plugin blocks saving API tokens from wp-admin, add cf_api_token to ACOOFM_SETTINGS in wp-config.php.' => 'إذا كانت الاستضافة أو إضافة الحماية تمنع حفظ رموز API من لوحة ووردبريس، أضف cf_api_token إلى ACOOFM_SETTINGS داخل wp-config.php.',
			'Cloudflare API token was not saved because it could not be recognized. Paste the raw token, the Authorization Bearer header, or the Cloudflare curl verify command.' => 'لم يتم حفظ رمز Cloudflare API لأن الإضافة لم تستطع التعرف عليه. ألصق الرمز الخام أو ترويسة Authorization Bearer أو أمر curl الخاص بالتحقق من Cloudflare.',
			'Cloudflare API token could not be saved in the standalone token store. Use the wp-config.php fallback shown below.' => 'تعذر حفظ رمز Cloudflare API في مخزن الرمز المستقل. استخدم الحل البديل عبر wp-config.php الظاهر أدناه.',
			'Cloudflare API token saved and can be read by the plugin.' => 'تم حفظ رمز Cloudflare API ويمكن للإضافة قراءته.',
			'Create at: Cloudflare Dashboard → My Profile → API Tokens' => 'أنشئه من لوحة Cloudflare ← My Profile ← API Tokens',
			'CDN URL' => 'رابط CDN',
			'Validate DNS' => 'فحص DNS',
			'Your custom domain pointing to the Worker. DNS record will be created automatically if not exists.' => 'الدومين المخصص الذي يشير إلى Worker. سيتم إنشاء سجل DNS تلقائياً إذا لم يكن موجوداً.',
			'How does automatic DNS setup work?' => 'كيف يعمل إعداد DNS التلقائي؟',
			'Automatic Setup (Recommended)' => 'الإعداد التلقائي (موصى به)',
			'Enter your desired CDN URL (e.g., https://cdn.yourdomain.com)' => 'أدخل رابط CDN المطلوب مثل https://cdn.yourdomain.com',
			'Click "Validate DNS" to check or create a proxied DNS record automatically' => 'اضغط "فحص DNS" لفحص أو إنشاء سجل DNS مفعّل البروكسي تلقائياً',
			'Click "Deploy Worker" to upload the Worker, bind the R2 bucket, and configure the route' => 'اضغط "نشر Worker" لرفع Worker وربط حاوية R2 وإعداد المسار',
			'What happens when you validate:' => 'ماذا يحدث عند الفحص:',
			'If DNS record does not exist → Creates A record with proxy enabled' => 'إذا لم يكن سجل DNS موجوداً، سيتم إنشاء سجل A مع تفعيل البروكسي',
			'If DNS record exists but proxy disabled → Shows warning with fix button' => 'إذا كان السجل موجوداً لكن البروكسي معطل، ستظهر رسالة تحذير مع زر إصلاح',
			'If DNS record exists with proxy → Ready to deploy!' => 'إذا كان السجل موجوداً والبروكسي مفعل، يصبح جاهزاً للنشر',
			'Requirements:' => 'المتطلبات:',
			'Domain must be in your Cloudflare account' => 'يجب أن يكون الدومين داخل حسابك في Cloudflare',
			'API Token with Workers Scripts, Workers R2 Storage, Zone Read, DNS Edit, Workers Routes Edit, and Cache Purge permissions' => 'رمز API يجب أن يحتوي صلاحيات Workers Scripts و Workers R2 Storage و Zone Read و DNS Edit و Workers Routes Edit و Cache Purge',
			'Zone Resources must include your domain' => 'يجب أن تشمل Zone Resources الدومين الخاص بك',
			'Image Quality' => 'جودة الصورة',
			'1-100. Higher = better quality, larger files. Default: 85' => 'من 1 إلى 100. الرقم الأعلى يعني جودة أعلى وحجماً أكبر. الافتراضي: 85',
			'Image Format' => 'صيغة الصورة',
			'Original' => 'الأصلية',
			'Keep original format (JPEG, PNG, GIF). No conversion, maximum compatibility. Larger file sizes.' => 'الإبقاء على الصيغة الأصلية بدون تحويل لضمان أعلى توافق، مع حجم ملفات أكبر.',
			'WebP (Recommended)' => 'WebP (موصى به)',
			'25-35% smaller than JPEG. Supported by 97%+ browsers. Best balance of compression and compatibility.' => 'أصغر من JPEG بنسبة 25-35% ومدعوم على أغلب المتصفحات.',
			'AVIF' => 'AVIF',
			'50% smaller than JPEG. Best compression. Supported by 93%+ browsers. Falls back to WebP for older browsers.' => 'ضغط أعلى وحجم أصغر، مع الرجوع إلى WebP للمتصفحات الأقدم.',
			'Smart Sizes' => 'الأحجام الذكية',
			'Calculate optimal sizes attribute based on content width. Reduces bandwidth on mobile but increases Cloudflare Transformations cost.' => 'حساب أحجام الصور المناسبة حسب عرض المحتوى لتقليل الاستهلاك على الجوال.',
			'Content Max Width' => 'أقصى عرض للمحتوى',
			'Maximum content area width in your theme. Used to calculate optimal image sizes.' => 'أقصى عرض لمنطقة المحتوى في القالب، ويستخدم لحساب أحجام الصور.',
			'Worker Deployment' => 'نشر Worker',
			'Deploy Cloudflare Worker for image transformation.' => 'نشر Cloudflare Worker لتحويل الصور.',
			'Worker Status' => 'حالة Worker',
			'Actions' => 'الإجراءات',
			'Deploy Worker' => 'نشر Worker',
			'Remove Worker' => 'حذف Worker',
			'Deployed' => 'تم النشر',
			'Route responding' => 'المسار يستجيب',
			'local status will sync on the next deploy/status check' => 'ستتزامن الحالة المحلية عند النشر أو الفحص التالي',
			'Not deployed' => 'غير منشور',
			'Worker deployed successfully!' => 'تم نشر Worker بنجاح!',
			'Worker removed.' => 'تم حذف Worker.',
			'Invalid CDN URL' => 'رابط CDN غير صحيح',
			'Could not read Cloudflare zones: %s' => 'تعذر قراءة مناطق Cloudflare: %s',
			'Cloudflare rejected the Authorization header. Paste the raw API token again, without "Bearer", spaces, or hidden characters.' => 'رفضت Cloudflare ترويسة التفويض. ألصق رمز API الخام مرة أخرى بدون "Bearer" أو مسافات أو محارف مخفية.',
			'Missing Cloudflare API token. Paste the raw token only, without "Bearer".' => 'رمز Cloudflare API غير موجود. ألصق الرمز الخام فقط بدون "Bearer".',
			'Cloudflare API token is missing or could not be decrypted. Paste the raw token again and save settings.' => 'رمز Cloudflare API غير موجود أو تعذر فكّه. ألصق الرمز الخام مرة أخرى ثم احفظ الإعدادات.',
			'Cloudflare API token verification failed: %s' => 'فشل التحقق من رمز Cloudflare API: %s',
			'Invalid API token' => 'رمز API غير صحيح',
			'Domain "%s" was not found. Make sure the root zone is in this Cloudflare account and the token can read zones.' => 'لم يتم العثور على الدومين "%s". تأكد أن النطاق الأساسي موجود في حساب Cloudflare وأن الرمز يملك صلاحية قراءة المناطق.',
			'DNS record exists but Cloudflare proxy is DISABLED. Worker will NOT work without proxy.' => 'سجل DNS موجود لكن Proxy في Cloudflare غير مفعل. لن يعمل Worker بدون تفعيل Proxy.',
			'DNS record created for %s with Cloudflare proxy enabled.' => 'تم إنشاء سجل DNS لـ %s مع تفعيل Cloudflare Proxy.',
			'Failed to create DNS record' => 'تعذر إنشاء سجل DNS',
			'Missing Cloudflare API token.' => 'رمز Cloudflare API غير موجود.',
			'Missing Cloudflare account ID.' => 'معرّف حساب Cloudflare غير موجود.',
			'Missing R2 bucket.' => 'اسم حاوية R2 غير موجود.',
			'Missing CDN URL.' => 'رابط CDN غير موجود.',
			'Configured' => 'مضبوط',
			'Not configured' => 'غير مضبوط',
			'Enabled' => 'مفعّل',
			'Disabled' => 'معطّل',
			'System Information' => 'معلومات النظام',
			'System status and debug information for troubleshooting.' => 'حالة النظام ومعلومات التشخيص للمساعدة في حل المشاكل.',
			'System Status' => 'حالة النظام',
			'Plugin Version' => 'إصدار الإضافة',
			'PHP Version' => 'إصدار PHP',
			'WordPress Version' => 'إصدار ووردبريس',
			'R2 Credentials' => 'بيانات R2',
			'CDN Status' => 'حالة CDN',
			'cURL Extension' => 'امتداد cURL',
			'OpenSSL Extension' => 'امتداد OpenSSL',
			'PHP Memory Limit' => 'حد ذاكرة PHP',
			'Max Execution Time' => 'أقصى وقت تنفيذ',
			'Unlimited' => 'غير محدود',
			'Not available' => 'غير متاح',
			'Media Overview' => 'ملخص الوسائط',
			'Total Media' => 'إجمالي الوسائط',
			'Offloaded' => 'مرفوعة إلى R2',
			'Pending' => 'قيد الانتظار',
			'Local' => 'محلية',
			'Go to Bulk Actions' => 'الانتقال إلى العمليات الجماعية',
			'Worker Statistics' => 'إحصاءات Worker',
			'Requests This Month' => 'طلبات هذا الشهر',
			'Deploy the Worker to see analytics.' => 'انشر Worker لعرض الإحصاءات.',
			'View detailed analytics in your <a href="%s" target="_blank" rel="noopener">Cloudflare Dashboard</a>' => 'اعرض الإحصاءات التفصيلية من <a href="%s" target="_blank" rel="noopener">لوحة Cloudflare</a>',
			'Setup Guides' => 'دليل الإعداد',
			'1. Create R2 Bucket' => '1. إنشاء حاوية R2',
			'Log in to <a href="https://dash.cloudflare.com" target="_blank">Cloudflare Dashboard</a>' => 'سجّل الدخول إلى <a href="https://dash.cloudflare.com" target="_blank">لوحة Cloudflare</a>',
			'Go to <strong>R2 Object Storage</strong> in the left sidebar' => 'انتقل إلى <strong>R2 Object Storage</strong> من القائمة الجانبية',
			'Click <strong>Create bucket</strong>' => 'اضغط <strong>Create bucket</strong>',
			'Enter bucket name (e.g., <code>my-wp-media</code>) and select location' => 'أدخل اسم الحاوية مثل <code>my-wp-media</code> واختر الموقع',
			'Click <strong>Create bucket</strong> to finish' => 'اضغط <strong>Create bucket</strong> لإنهاء الإنشاء',
			'Get R2 API Credentials:' => 'الحصول على مفاتيح R2 API:',
			'In R2 page, click <strong>Manage R2 API Tokens</strong>' => 'من صفحة R2 اضغط <strong>Manage R2 API Tokens</strong>',
			'Click <strong>Create API token</strong>' => 'اضغط <strong>Create API token</strong>',
			'Set permissions: <strong>Object Read & Write</strong>' => 'اجعل الصلاحيات <strong>Object Read & Write</strong>',
			'Specify bucket (or all buckets)' => 'حدد الحاوية أو كل الحاويات',
			'Copy <strong>Access Key ID</strong> and <strong>Secret Access Key</strong>' => 'انسخ <strong>Access Key ID</strong> و <strong>Secret Access Key</strong>',
			'Your Account ID is shown in the Cloudflare dashboard. Keep Region as "auto" for R2. Leave S3 Endpoint empty unless you are using another S3-compatible provider.' => 'يظهر معرّف الحساب داخل لوحة Cloudflare. اترك المنطقة "auto" مع R2، واترك S3 Endpoint فارغاً إلا إذا كنت تستخدم مزوّد S3 آخر.',
			'2. Create Cloudflare API Token' => '2. إنشاء رمز Cloudflare API',
			'API Token is required for Worker deployment and cache purging.' => 'رمز API مطلوب لنشر Worker وتنظيف الكاش.',
			'Go to <a href="https://dash.cloudflare.com/profile/api-tokens" target="_blank">API Tokens</a> page' => 'انتقل إلى صفحة <a href="https://dash.cloudflare.com/profile/api-tokens" target="_blank">API Tokens</a>',
			'Click <strong>Create Token</strong>' => 'اضغط <strong>Create Token</strong>',
			'Select <strong>Create Custom Token</strong>' => 'اختر <strong>Create Custom Token</strong>',
			'Add the following permissions:' => 'أضف الصلاحيات التالية:',
			'Permission' => 'الصلاحية',
			'Access' => 'الوصول',
			'Purpose' => 'الغرض',
			'Edit' => 'تعديل',
			'Read' => 'قراءة',
			'Purge' => 'تنظيف',
			'Bind R2 to Worker' => 'ربط R2 بالـ Worker',
			'List zones/domains' => 'قراءة النطاقات والمناطق',
			'Create/edit DNS records' => 'إنشاء وتعديل سجلات DNS',
			'Configure Worker route' => 'إعداد مسار Worker',
			'Clear cached transformed images when needed' => 'تنظيف الصور المحوّلة من الكاش عند الحاجة',
			'Set <strong>Account Resources</strong>: Include your account' => 'اجعل <strong>Account Resources</strong>: تشمل حسابك',
			'Set <strong>Zone Resources</strong>: Include your domain' => 'اجعل <strong>Zone Resources</strong>: تشمل نطاقك',
			'Click <strong>Continue to summary</strong> > <strong>Create Token</strong>' => 'اضغط <strong>Continue to summary</strong> ثم <strong>Create Token</strong>',
			'Copy the token (shown only once!) and paste the raw token only, without "Bearer".' => 'انسخ الرمز لأنه يظهر مرة واحدة فقط، والصقه خاماً بدون كلمة "Bearer".',
			'3. Configure CDN URL' => '3. إعداد رابط CDN',
			'Use a Cloudflare proxied subdomain for optimized image delivery through the Worker.' => 'استخدم نطاقاً فرعياً مفعّل البروكسي في Cloudflare لتسليم الصور المحسّنة عبر Worker.',
			'Recommended automatic setup' => 'الإعداد التلقائي الموصى به',
			'Enter a CDN URL in the CDN tab, for example <code>https://cdn.yourdomain.com</code>.' => 'أدخل رابط CDN في تبويب CDN، مثل <code>https://cdn.yourdomain.com</code>.',
			'Click <strong>Validate DNS</strong>. The plugin will find the root zone and create a proxied DNS record if it is missing.' => 'اضغط <strong>فحص DNS</strong>. ستبحث الإضافة عن النطاق الأساسي وتنشئ سجل DNS مفعّل البروكسي إذا لم يكن موجوداً.',
			'Click <strong>Deploy Worker</strong>. The plugin uploads the Worker, binds the R2 bucket, and creates the route <code>cdn.yourdomain.com/*</code>.' => 'اضغط <strong>نشر Worker</strong>. سترفع الإضافة Worker وتربط حاوية R2 وتنشئ المسار <code>cdn.yourdomain.com/*</code>.',
			'Keep the DNS record proxied in Cloudflare. The Worker route will not run through DNS-only records.' => 'أبقِ سجل DNS مفعّل البروكسي في Cloudflare. لن يعمل مسار Worker عبر سجلات DNS-only.',
			'Manual fallback' => 'الإعداد اليدوي البديل',
			'Create a proxied DNS record for the CDN subdomain inside Cloudflare.' => 'أنشئ سجل DNS مفعّل البروكسي للنطاق الفرعي الخاص بالـ CDN داخل Cloudflare.',
			'Create a Worker route that matches the CDN host, such as <code>cdn.yourdomain.com/*</code>.' => 'أنشئ مسار Worker يطابق دومين CDN مثل <code>cdn.yourdomain.com/*</code>.',
			'Use Local Emergency Fallback if the Worker or CDN delivery is unavailable.' => 'استخدم الرجوع المحلي للطوارئ إذا تعطل Worker أو تسليم CDN.',
			'R2 public access is optional because the Worker reads the bucket through an R2 binding.' => 'الوصول العام لـ R2 اختياري لأن Worker يقرأ الحاوية عبر R2 Binding.',
			'4. Offload Media to R2' => '4. رفع الوسائط إلى R2',
			'Automatic Offload:' => 'الرفع التلقائي:',
			'Enable <strong>Auto Offload</strong> in Offload tab' => 'فعّل <strong>Auto Offload</strong> من تبويب النقل إلى R2',
			'New uploads will be automatically offloaded to R2' => 'سيتم رفع الملفات الجديدة تلقائياً إلى R2',
			'Bulk Offload Existing Media:' => 'رفع الوسائط القديمة دفعة واحدة:',
			'Go to <strong>Bulk Actions</strong> tab' => 'انتقل إلى تبويب <strong>العمليات الجماعية</strong>',
			'Set batch size (25-50 recommended)' => 'حدد حجم الدفعة، والموصى به بين 25 و50',
			'Click <strong>Start Bulk Offload</strong>' => 'اضغط <strong>بدء الرفع الجماعي</strong>',
			'Wait for completion (you can cancel anytime)' => 'انتظر اكتمال العملية، ويمكنك الإلغاء في أي وقت',
			'Manual Offload:' => 'الرفع اليدوي:',
			'In Media Library, click <strong>Offload to R2</strong> for individual items' => 'من مكتبة الوسائط اضغط <strong>Offload to R2</strong> للعناصر الفردية',
			'Or use attachment edit page for single file offload' => 'أو استخدم صفحة تحرير المرفق لرفع ملف واحد',
			'5. Image Optimization Settings' => '5. إعدادات تحسين الصور',
			'Configure image optimization in the <strong>CDN</strong> tab:' => 'اضبط تحسين الصور من تبويب <strong>CDN</strong>:',
			'Quality' => 'الجودة',
			'1-100 (default 85). Lower = smaller file, less quality.' => 'من 1 إلى 100، الافتراضي 85. الرقم الأقل يعني حجماً أصغر وجودة أقل.',
			'Enable AVIF' => 'تفعيل AVIF',
			'Serve AVIF format for supported browsers. Better compression than WebP.' => 'تقديم صيغة AVIF للمتصفحات المدعومة، وهي تضغط أفضل من WebP.',
			'Auto-calculate responsive sizes. Increases Transformations usage.' => 'حساب الأحجام المتجاوبة تلقائياً، وقد يزيد استخدام التحويلات.',
			'Cost Information:' => 'معلومات التكلفة:',
			'R2 Storage: $0.015/GB/month' => 'تخزين R2: ‏0.015 دولار لكل جيجابايت شهرياً',
			'R2 Class A Operations (write): $4.50/million' => 'عمليات R2 Class A للكتابة: ‏4.50 دولار لكل مليون عملية',
			'R2 Class B Operations (read): $0.36/million' => 'عمليات R2 Class B للقراءة: ‏0.36 دولار لكل مليون عملية',
			'Image Transformations: First 5,000/month free, then $0.50/1,000' => 'تحويلات الصور: أول 5,000 شهرياً مجانية، ثم 0.50 دولار لكل 1,000',
			'Monitor usage in Worker Statistics above and Cloudflare Dashboard.' => 'راقب الاستخدام من إحصاءات Worker أعلاه ومن لوحة Cloudflare.',
			'Debug Information' => 'معلومات التشخيص',
			'Copy this information when requesting support.' => 'انسخ هذه المعلومات عند طلب الدعم.',
			'Copy to Clipboard' => 'نسخ إلى الحافظة',
			'Copied!' => 'تم النسخ!',
			'Reset Tools' => 'أدوات إعادة الضبط',
			'Use this when an old token, endpoint, or cached setting is stuck in the database. wp-config.php constants will still override database settings.' => 'استخدم هذا الخيار عند بقاء رمز قديم أو Endpoint أو إعداد مخزّن في قاعدة البيانات. إعدادات wp-config.php ستبقى لها الأولوية.',
			'Reset Saved Settings and Cache' => 'إعادة ضبط الإعدادات والكاش',
			'Delete All Plugin Data' => 'حذف كل بيانات الإضافة',
			'Delete stored plugin settings, tables, queues, status records, and attachment metadata. Files on R2 are not deleted.' => 'يحذف إعدادات الإضافة والجداول والطوابير وسجلات الحالة وبيانات المرفقات. لا يتم حذف الملفات من R2.',
			'Reset saved settings and cached data? This will remove stored credentials and CDN/R2 settings from the database. Files on R2 and media library items will not be deleted.' => 'هل تريد إعادة ضبط الإعدادات والكاش؟ سيتم حذف بيانات الربط وإعدادات CDN/R2 المخزنة في قاعدة البيانات. لن تُحذف ملفات R2 أو عناصر مكتبة الوسائط.',
			'Delete all plugin data from the database? This removes settings, plugin tables, queue/status records, and media metadata. Files on R2 and WordPress media files will not be deleted.' => 'هل تريد حذف كل بيانات الإضافة من قاعدة البيانات؟ سيتم حذف الإعدادات وجداول الإضافة وسجلات الطابور والحالة وبيانات الوسائط الخاصة بالإضافة. لن تُحذف ملفات R2 أو ملفات ووردبريس.',
			'Reset completed. The page will reload now.' => 'اكتملت إعادة الضبط. سيتم تحديث الصفحة الآن.',
			'All plugin data was deleted. The page will reload now.' => 'تم حذف كل بيانات الإضافة. سيتم تحديث الصفحة الآن.',
			'Reset failed. Please try again.' => 'فشلت إعادة الضبط. حاول مرة أخرى.',
			'Saved settings and cached data were reset. Re-enter your credentials and save settings.' => 'تمت إعادة ضبط الإعدادات والكاش. أدخل بيانات الربط من جديد ثم احفظ الإعدادات.',
			'Offload Settings' => 'إعدادات النقل إلى R2',
			'Configure how media files are offloaded to R2 storage.' => 'اضبط طريقة رفع ملفات الوسائط إلى تخزين R2.',
			'Auto-Offload on Upload' => 'الرفع التلقائي عند التحميل',
			'Automatically offload media files to R2 when uploaded.' => 'رفع ملفات الوسائط تلقائياً إلى R2 عند تحميلها.',
			'Batch Size' => 'حجم الدفعة',
			'1 file per batch' => 'ملف واحد في كل دفعة',
			'3 files per batch' => '3 ملفات في كل دفعة',
			'5 files per batch' => '5 ملفات في كل دفعة',
			'10 files per batch' => '10 ملفات في كل دفعة',
			'25 files per batch' => '25 ملفاً في كل دفعة',
			'50 files per batch' => '50 ملفاً في كل دفعة',
			'Number of files to process in each batch during bulk offload.' => 'عدد الملفات التي تعالج في كل دفعة أثناء النقل الجماعي.',
			'Number of files to process in each background batch. Use 1 on shared hosting to avoid memory errors.' => 'عدد الملفات التي تعالج في كل دفعة خلفية. استخدم ملفاً واحداً على الاستضافة المشتركة لتجنب أخطاء الذاكرة.',
			'Keep Local Files' => 'الاحتفاظ بالملفات المحلية',
			'Keep local copies of files after offloading to R2. Disable to save disk space (files will be served from R2/CDN).' => 'احتفظ بنسخ محلية بعد رفع الملفات إلى R2. عطّل الخيار لتوفير مساحة القرص، وستُقدّم الملفات من R2/CDN.',
			'Sync Delete' => 'مزامنة الحذف',
			'When deleting media from WordPress, also delete from R2 storage. Disable to keep R2 copies as backup.' => 'عند حذف الوسائط من ووردبريس، احذفها أيضاً من R2. عطّل الخيار للإبقاء على نسخ R2 كنسخة احتياطية.',
			'Manage bulk offload operations and monitor progress.' => 'إدارة عمليات النقل الجماعي ومراقبة التقدم.',
			'Quick Stats' => 'إحصاءات سريعة',
			'Pending Queue' => 'قائمة الانتظار',
			'Clear All' => 'مسح الكل',
			'Close' => 'إغلاق',
			'Loading...' => 'جار التحميل...',
			'Offload All (%d)' => 'رفع الكل إلى R2 (%d)',
			'Restore All (%d)' => 'استرجاع الكل (%d)',
			'Retry Failed (%d)' => 'إعادة محاولة الفاشلة (%d)',
			'Free Disk Space (%d)' => 'توفير مساحة القرص (%d)',
			'Cancel' => 'إلغاء',
			'Progress' => 'التقدم',
			'Current:' => 'الحالي:',
			'Elapsed Time:' => 'الوقت المنقضي:',
			'Process Log' => 'سجل العملية',
			'Clear' => 'مسح',
			'R2 Offload Terminal' => 'سجل نقل R2',
			'Ready. Click "Offload All Media" to start.' => 'جاهز. اضغط "رفع كل الوسائط" للبدء.',
			'Failed Items' => 'العناصر الفاشلة',
			'Retry All' => 'إعادة محاولة الكل',
			'All items processed.' => 'تمت معالجة كل العناصر.',
			'All items restored.' => 'تم استرجاع كل العناصر.',
			'All local files deleted.' => 'تم حذف كل الملفات المحلية.',
			'Operation completed.' => 'اكتملت العملية.',
			'Operation cancelled.' => 'تم إلغاء العملية.',
			'Bulk offload cancelled.' => 'تم إلغاء الرفع الجماعي.',
			'Bulk restore cancelled.' => 'تم إلغاء الاسترجاع الجماعي.',
			'Bulk delete cancelled.' => 'تم إلغاء حذف الملفات المحلية.',
			'Activity log cleared.' => 'تم مسح سجل النشاط.',
			'%1$d files queued for %2$s.' => 'تمت إضافة %1$d ملفاً إلى قائمة انتظار %2$s.',
			'%d items queued for retry.' => 'تمت إضافة %d عنصر لإعادة المحاولة.',
			'%d pending items cancelled.' => 'تم إلغاء %d عنصر قيد الانتظار.',
			'Could not cancel item. It may already be processing.' => 'تعذر إلغاء العنصر. ربما تتم معالجته الآن.',
			'Invalid item ID.' => 'معرّف العنصر غير صحيح.',
			'Invalid attachment ID.' => 'معرّف المرفق غير صحيح.',
			'Item cancelled.' => 'تم إلغاء العنصر.',
			'Item queued for retry.' => 'تمت إضافة العنصر لإعادة المحاولة.',
			'Failed to queue item.' => 'تعذرت إضافة العنصر إلى قائمة الانتظار.',
			'Too many attempts. Wait 60 seconds.' => 'محاولات كثيرة. انتظر 60 ثانية.',
			'CDN URL is required.' => 'رابط CDN مطلوب.',
			'Missing zone or record ID.' => 'معرّف المنطقة أو السجل غير موجود.',
			'Proxy enabled successfully!' => 'تم تفعيل البروكسي بنجاح!',
			'Failed to enable proxy.' => 'تعذر تفعيل البروكسي.',
			'R2 Status' => 'حالة R2',
			'Local / R2' => 'محلي / R2',
			'R2' => 'R2',
			'No local file' => 'لا يوجد ملف محلي',
			'Queued for offload' => 'في انتظار الرفع إلى R2',
			'Offload to R2' => 'رفع إلى R2',
			'Re-offload' => 'إعادة الرفع',
			'Restore to Local' => 'استرجاع محلي',
			'Download to Local' => 'تنزيل إلى المحلي',
			'Delete Local' => 'حذف المحلي',
			'Delete local files? This cannot be undone. Files will remain on R2.' => 'حذف الملفات المحلية؟ لا يمكن التراجع عن ذلك. ستبقى الملفات على R2.',
			'An error occurred during the operation.' => 'حدث خطأ أثناء العملية.',
			'File offloaded to R2 successfully.' => 'تم رفع الملف إلى R2 بنجاح.',
			'File downloaded to local storage. Website continues serving from R2.' => 'تم تنزيل الملف إلى التخزين المحلي. سيستمر الموقع بالتقديم من R2.',
			'Local files deleted successfully. Files remain on R2.' => 'تم حذف الملفات المحلية بنجاح. ستبقى الملفات على R2.',
			'Offloaded successfully!' => 'تم الرفع إلى R2 بنجاح!',
			'Offload failed.' => 'فشل الرفع إلى R2.',
			'Connection successful' => 'تم الاتصال بنجاح',
			'Unknown error' => 'خطأ غير معروف',
			'Unknown action' => 'إجراء غير معروف',
			'Completed' => 'اكتمل',
			'Operation failed' => 'فشلت العملية',
			'Offloaded successfully' => 'تم الرفع إلى R2 بنجاح',
			'Offloaded to R2' => 'تم الرفع إلى R2',
			'Restored to local' => 'تم الاسترجاع إلى المحلي',
			'Attachment is not offloaded to R2' => 'المرفق غير مرفوع إلى R2',
			'Could not determine file path' => 'تعذر تحديد مسار الملف',
			'Deleted local files (+%d thumbnails)' => 'تم حذف الملفات المحلية (+%d مصغرات)',
			'Failed to configure route' => 'تعذر إعداد المسار',
			'Failed to download main file: %s' => 'تعذر تنزيل الملف الرئيسي: %s',
			'Failed to upload Worker script: %s' => 'تعذر رفع سكربت Worker: %s',
			'File exceeds 70MB limit' => 'حجم الملف يتجاوز حد 70 ميجابايت',
			'File not found' => 'الملف غير موجود',
			'Files already exist locally' => 'الملفات موجودة محلياً بالفعل',
			'Files restored to local (+%d thumbnails)' => 'تم استرجاع الملفات محلياً (+%d مصغرات)',
			'Local file not found' => 'الملف المحلي غير موجود',
			'Local files deleted (+%d thumbnails)' => 'تم حذف الملفات المحلية (+%d مصغرات)',
			'MIME type "%s" is not allowed for offload' => 'نوع الملف "%s" غير مسموح برفعه إلى R2',
			'Missing file path or R2 key' => 'مسار الملف أو مفتاح R2 غير موجود',
			'Sync delete skipped because no R2 object key was found for this attachment.' => 'تم تخطي مزامنة الحذف لأنه لم يتم العثور على مفتاح ملف R2 لهذا المرفق.',
			'Main file delete failed: %s' => 'فشل حذف الملف الرئيسي: %s',
			'Thumbnail %1$s delete failed: %2$s' => 'فشل حذف المصغّر %1$s: %2$s',
			'Missing R2 access key ID.' => 'معرّف مفتاح وصول R2 غير موجود.',
			'Missing R2 account ID or custom endpoint.' => 'معرّف حساب R2 أو Endpoint مخصص غير موجود.',
			'Missing R2 secret access key.' => 'مفتاح وصول R2 السري غير موجود.',
			'No local files found to delete' => 'لا توجد ملفات محلية لحذفها',
			'No local files to delete' => 'لا توجد ملفات محلية للحذف',
			'No R2 key found' => 'لم يتم العثور على مفتاح R2',
			'Offload blocked by filter (cfr2_should_offload)' => 'تم منع الرفع بواسطة فلتر cfr2_should_offload',
			'Worker deployed successfully' => 'تم نشر Worker بنجاح',
			'Zone not found for domain: %s' => 'لم يتم العثور على منطقة Cloudflare للدومين: %s',
			'Deleted %d file(s) from R2' => 'تم حذف %d ملف من R2',
			'This plugin requires PHP 8.0 or higher.' => 'تتطلب هذه الإضافة PHP 8.0 أو أحدث.',
			'This plugin requires WordPress 6.0 or higher.' => 'تتطلب هذه الإضافة ووردبريس 6.0 أو أحدث.',
			'Data cleaned.' => 'تم تنظيف البيانات.',
			'You do not have permission to access this page.' => 'لا تملك صلاحية الوصول إلى هذه الصفحة.',
			'Cloudflare Diagnostics' => 'تشخيص Cloudflare',
			'Run Diagnostics' => 'تشغيل التشخيص',
			'Runs safe read-only checks and shows whether the blocker is in the plugin, the server, Cloudflare API, DNS, Worker, or R2.' => 'يشغّل فحوصات آمنة للقراءة فقط ويعرض هل مصدر التعطل من الإضافة أو السيرفر أو Cloudflare API أو DNS أو Worker أو R2.',
			'Running diagnostics...' => 'جار تشغيل التشخيص...',
			'Diagnostics request failed.' => 'فشل طلب التشخيص.',
			'Main blocker' => 'العائق الرئيسي',
			'No critical blocker found. Review warnings if any.' => 'لم يتم العثور على عائق حرج. راجع التحذيرات إن وجدت.',
			'Source' => 'المصدر',
			'Advice' => 'النصيحة',
			'OK' => 'سليم',
			'Warning' => 'تحذير',
			'Error' => 'خطأ',
			'Cloudflare API token is not readable by the plugin.' => 'رمز Cloudflare API غير قابل للقراءة داخل الإضافة.',
			'A Cloudflare API token value exists in the database, but the plugin cannot decrypt or recognize it.' => 'توجد قيمة لرمز Cloudflare API في قاعدة البيانات، لكن الإضافة لا تستطيع فكها أو التعرف عليها.',
			'Cloudflare API token is not saved in the plugin settings.' => 'رمز Cloudflare API غير محفوظ في إعدادات الإضافة.',
			'Plugin settings' => 'إعدادات الإضافة',
			'Paste the raw token again, save settings, or remove any stale saved value with Reset Tools.' => 'ألصق الرمز الخام مرة أخرى ثم احفظ الإعدادات، أو احذف أي قيمة قديمة عالقة عبر أدوات إعادة الضبط.',
			'Use Reset Tools, paste the token again, and save. If it still fails, put cf_api_token in ACOOFM_SETTINGS inside wp-config.php.' => 'استخدم أدوات إعادة الضبط، ثم ألصق الرمز مرة أخرى واحفظ. إذا استمر الفشل، ضع cf_api_token داخل ACOOFM_SETTINGS في ملف wp-config.php.',
			'Paste the token and click Save Settings before running diagnostics or deploying the Worker.' => 'ألصق الرمز واضغط حفظ الإعدادات قبل تشغيل التشخيص أو نشر Worker.',
			'Cloudflare API token is saved and readable locally.' => 'رمز Cloudflare API محفوظ ويمكن قراءته محلياً.',
			'Cloudflare Account ID is missing.' => 'معرّف حساب Cloudflare غير موجود.',
			'R2 bucket name is missing.' => 'اسم حاوية R2 غير موجود.',
			'R2 credentials are complete locally.' => 'بيانات R2 مكتملة محلياً.',
			'CDN URL is missing or invalid, so Worker route checks cannot run.' => 'رابط CDN غير موجود أو غير صحيح، لذلك لا يمكن فحص مسار Worker.',
			'CDN hostname parsed successfully: %s' => 'تم قراءة دومين CDN بنجاح: %s',
			'Cloudflare accepted the API token. Status: %s' => 'قبلت Cloudflare رمز API. الحالة: %s',
			'Cloudflare API' => 'Cloudflare API',
			'Cloudflare token verification failed: %s' => 'فشل تحقق Cloudflare من الرمز: %s',
			'This is the first remote blocker. Confirm the token is raw, active, and not restricted to another IP/account.' => 'هذا أول عائق من المصدر الخارجي. تأكد أن الرمز خام ونشط وغير مقيّد بعنوان IP أو حساب آخر.',
			'R2 bucket access succeeded.' => 'نجح الوصول إلى حاوية R2.',
			'Cloudflare R2' => 'Cloudflare R2',
			'R2 bucket access failed.' => 'فشل الوصول إلى حاوية R2.',
			'Check the R2 Access Key, Secret Key, bucket name, endpoint, and bucket-scoped permissions.' => 'تحقق من Access Key و Secret Key واسم الحاوية وEndpoint وصلاحيات الحاوية.',
			'No Cloudflare zone was found for %s.' => 'لم يتم العثور على منطقة Cloudflare لـ %s.',
			'Cloudflare Zone/DNS' => 'منطقة Cloudflare وDNS',
			'Make sure the root domain is in this Cloudflare account and the token has Zone Read permission.' => 'تأكد أن الدومين الأساسي موجود داخل حساب Cloudflare نفسه وأن الرمز يملك صلاحية Zone Read.',
			'Cloudflare zone found for %s.' => 'تم العثور على منطقة Cloudflare لـ %s.',
			'No DNS record exists for the CDN hostname yet.' => 'لا يوجد سجل DNS لدومين CDN حتى الآن.',
			'Use Validate DNS or Deploy Worker to create a proxied record automatically.' => 'استخدم فحص DNS أو نشر Worker لإنشاء سجل مفعّل البروكسي تلقائياً.',
			'DNS record exists but Cloudflare proxy is disabled.' => 'سجل DNS موجود لكن بروكسي Cloudflare معطّل.',
			'Enable the orange cloud proxy. Worker routes do not run on DNS-only records.' => 'فعّل البروكسي ذي السحابة البرتقالية. مسارات Worker لا تعمل مع سجلات DNS-only.',
			'DNS record exists and Cloudflare proxy is enabled.' => 'سجل DNS موجود وبروكسي Cloudflare مفعّل.',
			'Worker script exists in Cloudflare.' => 'سكريبت Worker موجود في Cloudflare.',
			'Cloudflare Workers' => 'Cloudflare Workers',
			'Worker is not confirmed as deployed: %s' => 'لم يتم تأكيد نشر Worker: %s',
			'Worker route is responding; Cloudflare API status check was inconclusive: %s' => 'مسار Worker يستجيب، لكن فحص حالته من Cloudflare API لم يكن حاسماً: %s',
			'Worker route is responding.' => 'مسار Worker يستجيب.',
			'This is expected before the first successful Deploy Worker action.' => 'هذا طبيعي قبل أول عملية نشر Worker ناجحة.',
			'CDN health check could not connect: %s' => 'تعذر الاتصال بفحص صحة CDN: %s',
			'Server network/DNS' => 'شبكة السيرفر أو DNS',
			'The WordPress server could not reach the CDN URL. Check DNS propagation, SSL, or outbound HTTPS access.' => 'سيرفر ووردبريس لم يستطع الوصول إلى رابط CDN. تحقق من انتشار DNS وSSL وسماح الاستضافة بالاتصال الخارجي عبر HTTPS.',
			'CDN health endpoint responded correctly.' => 'استجاب رابط صحة CDN بشكل صحيح.',
			'Worker runtime' => 'تشغيل Worker',
			'CDN health endpoint returned HTTP %d instead of 200.' => 'أرجع رابط صحة CDN كود HTTP %d بدلاً من 200.',
			'Worker route/CDN' => 'مسار Worker أو CDN',
			'The Worker route is not active yet, DNS is not proxied, or the Worker is returning an error.' => 'مسار Worker غير نشط بعد، أو DNS ليس مفعّل البروكسي، أو Worker يعيد خطأ.',
			'No offloaded media item was found for a live image transformation test.' => 'لم يتم العثور على ملف وسائط مرفوع إلى R2 لاختبار تحويل صورة فعلي.',
			'WordPress media' => 'وسائط ووردبريس',
			'Upload a new image or run bulk offload, then run diagnostics again.' => 'ارفع صورة جديدة أو شغّل الرفع الجماعي، ثم أعد التشخيص.',
			'Sample image request failed: %s' => 'فشل طلب صورة التجربة: %s',
			'Sample image responded with Content-Type: %s' => 'استجابت صورة التجربة بنوع محتوى: %s',
			'Worker image optimization' => 'تحسين الصور عبر Worker',
			'The image is reachable, but WebP conversion was not confirmed. If this persists, the Worker transform path needs adjustment.' => 'الصورة قابلة للوصول، لكن لم يتم تأكيد تحويل WebP. إذا استمر ذلك، يحتاج مسار التحويل في Worker إلى تعديل.',
			'Worker served the original image because transformation failed: %s' => 'قدّم Worker الصورة الأصلية لأن التحويل فشل: %s',
			'Check that Cloudflare Image Transformations is available for this zone and that the Worker was redeployed after changing the plugin version.' => 'تحقق أن Cloudflare Image Transformations متاحة لهذا النطاق، وأن Worker أُعيد نشره بعد تحديث الإضافة.',
			'Sample image returned HTTP %d.' => 'أرجعت صورة التجربة كود HTTP %d.',
			'Worker/R2 delivery' => 'تسليم Worker/R2',
			'The Worker route is active but could not serve this R2 object. Check the R2 binding and object key.' => 'مسار Worker نشط لكنه لم يستطع تقديم هذا الملف من R2. تحقق من ربط R2 ومفتاح الملف.',
			'Unknown Cloudflare API error' => 'خطأ غير معروف من Cloudflare API',
			'Cloudflare API returned an empty response (HTTP %d).' => 'أرجع Cloudflare API استجابة فارغة (HTTP %d).',
			'Cloudflare API returned a non-JSON response (HTTP %1$d, Content-Type: %2$s).' => 'أرجع Cloudflare API استجابة ليست JSON (HTTP %1$d، نوع المحتوى: %2$s).',
			'Server network' => 'شبكة السيرفر',
			'Cloudflare authentication' => 'مصادقة Cloudflare',
			'Disclaimer:' => 'تنبيه:',
			'This plugin is an independent, third-party project and is not affiliated with, endorsed by, or officially associated with Cloudflare, Inc. "Cloudflare" and "R2" are trademarks of Cloudflare, Inc. The use of these names is solely for descriptive purposes to indicate compatibility with Cloudflare services.' => 'هذه الإضافة مشروع مستقل من طرف ثالث وليست تابعة أو معتمدة أو مرتبطة رسمياً بشركة Cloudflare, Inc. إن اسمي "Cloudflare" و "R2" علامتان تجاريتان لشركة Cloudflare, Inc. ويُستخدمان هنا فقط للوصف وبيان التوافق مع خدمات Cloudflare.',
		);
	}

	/**
	 * Define all hooks.
	 */
	private function define_hooks(): void {
		// Admin hooks.
		if ( is_admin() ) {
			$admin_menu = new AdminMenu();
			$admin_menu->register_hooks();

			$media_lib = new MediaLibraryExtension();
			$media_lib->register_hooks();

			$deactivation = new DeactivationHandler();
			$deactivation->register_hooks();
		}

		// Assets.
		$assets = new Assets();
		$assets->register_hooks();

		// Media upload hooks.
		$media_hooks = new MediaUploadHooks();
		$media_hooks->register_hooks();

		// URL rewriting (frontend + admin for previews).
		$url_rewriter = new URLRewriter();
		$url_rewriter->register_hooks();

		// REST API integration (always).
		$rest_api = new RestApiIntegration();
		$rest_api->register_hooks();

		// WooCommerce integration (conditional).
		if ( class_exists( 'WooCommerce' ) ) {
			$woo = new WooCommerceIntegration();
			$woo->register_hooks();
		}

		// Gutenberg integration (always).
		$gutenberg = new GutenbergIntegration();
		$gutenberg->register_hooks();

		// Stats cleanup cron.
		add_action( 'cfr2_cleanup_stats', array( Services\StatsTracker::class, 'cleanup_old_stats' ) );
	}

	/**
	 * Get loader instance.
	 *
	 * @return Loader
	 */
	public function get_loader(): Loader {
		return $this->loader;
	}
}
