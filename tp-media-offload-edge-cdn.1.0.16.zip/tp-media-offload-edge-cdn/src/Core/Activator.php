<?php
/**
 * Plugin Activator class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Core;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Database\Schema;
use Salahdev\NidaEdge\Services\PluginSettings;

/**
 * Activator class - runs on plugin activation.
 */
class Activator {

	/**
	 * Activate the plugin.
	 */
	public static function activate(): void {
		// Check PHP version.
		if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
			wp_die(
				esc_html__( 'This plugin requires PHP 8.0 or higher.', 'tp-media-offload-edge-cdn' ),
				'Plugin Activation Error',
				array( 'back_link' => true )
			);
		}

		// Check WP version.
		if ( version_compare( get_bloginfo( 'version' ), '6.0', '<' ) ) {
			wp_die(
				esc_html__( 'This plugin requires WordPress 6.0 or higher.', 'tp-media-offload-edge-cdn' ),
				'Plugin Activation Error',
				array( 'back_link' => true )
			);
		}

		// Create database tables.
		Schema::create_tables();

		// Schedule stats cleanup.
		if ( ! wp_next_scheduled( 'cfr2_cleanup_stats' ) ) {
			wp_schedule_event( time(), 'weekly', 'cfr2_cleanup_stats' );
		}

		// Create default settings with the canonical schema.
		PluginSettings::initialize();

		// Flush rewrite rules.
		flush_rewrite_rules();
	}
}
