<?php
/**
 * Queue Processor class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Services;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Traits\CredentialsHelperTrait;

/**
 * QueueProcessor class - processes background offload queue.
 */
class QueueProcessor {

	use CredentialsHelperTrait;

	/**
	 * Default batch size.
	 */
	private const BATCH_SIZE = 1;

	/**
	 * Maximum batch size.
	 */
	private const MAX_BATCH_SIZE = 3;

	/**
	 * Lock transient used to avoid concurrent queue workers.
	 */
	private const LOCK_KEY = 'cfr2_queue_processor_lock';

	/**
	 * Process queue items.
	 */
	public static function process(): void {
		global $wpdb;

		if ( get_transient( self::LOCK_KEY ) ) {
			return;
		}

		set_transient( self::LOCK_KEY, 1, 10 * MINUTE_IN_SECONDS );

		try {
			self::process_locked();
		} finally {
			delete_transient( self::LOCK_KEY );
		}
	}

	/**
	 * Process queue items while the queue lock is held.
	 */
	private static function process_locked(): void {
		global $wpdb;

		// Recover items left in processing state by a timeout or fatal error.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Queue recovery requires fresh state.
		$wpdb->query(
			"UPDATE {$wpdb->prefix}cfr2_offload_queue
			 SET status = 'pending'
			 WHERE status = 'processing'
			 AND processed_at IS NOT NULL
			 AND processed_at < DATE_SUB(NOW(), INTERVAL 15 MINUTE)"
		);

		// Get batch size from settings.
		$settings   = PluginSettings::get();
		$batch_size = min( max( 1, (int) ( $settings['batch_size'] ?? self::BATCH_SIZE ) ), self::MAX_BATCH_SIZE );

		// Check if cancelled.
		if ( get_transient( 'cfr2_bulk_cancelled' ) ) {
			delete_transient( 'cfr2_bulk_cancelled' );
			return;
		}

		// Fetch pending items.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Queue processing requires fresh data.
		$items = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}cfr2_offload_queue
				 WHERE status = 'pending'
				 ORDER BY created_at ASC
				 LIMIT %d",
				$batch_size
			)
		);

		if ( empty( $items ) ) {
			return;
		}

		$credentials   = self::get_r2_credentials();
		$error_message = SettingsValidator::validate_r2_credentials( $credentials );

		if ( null !== $error_message ) {
			foreach ( $items as $item ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom queue table.
				$wpdb->update(
					$wpdb->prefix . 'cfr2_offload_queue',
					array(
						'status'        => 'failed',
						'error_message' => $error_message,
						'processed_at'  => current_time( 'mysql' ),
					),
					array( 'id' => $item->id ),
					array( '%s', '%s', '%s' ),
					array( '%d' )
				);

				BulkOperationLogger::log( (int) $item->attachment_id, 'error', $error_message );
			}

			return;
		}

		foreach ( $items as $item ) {
			if ( self::is_memory_near_limit() ) {
				QueueScheduler::schedule( 30 );
				return;
			}

			$r2      = new R2Client( $credentials );
			$offload = new OffloadService( $r2 );

			// Mark as processing.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom queue table.
			$wpdb->update(
				$wpdb->prefix . 'cfr2_offload_queue',
				array(
					'status'       => 'processing',
					'processed_at' => current_time( 'mysql' ),
				),
				array( 'id' => $item->id ),
				array( '%s', '%s' ),
				array( '%d' )
			);

			// Process based on action.
			$result = match ( $item->action ) {
				'offload'      => $offload->offload( $item->attachment_id ),
				'restore'      => $offload->restore( $item->attachment_id ),
				'delete_local' => $offload->delete_local_files( $item->attachment_id ),
				default        => array(
					'success' => false,
					'message' => __( 'Unknown action', 'tp-media-offload-edge-cdn' ),
				),
			};

			// Update queue status.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom queue table.
			$wpdb->update(
				$wpdb->prefix . 'cfr2_offload_queue',
				array(
					'status'        => $result['success'] ? 'completed' : 'failed',
					'error_message' => $result['message'] ?? null,
					'processed_at'  => current_time( 'mysql' ),
				),
				array( 'id' => $item->id ),
				array( '%s', '%s', '%s' ),
				array( '%d' )
			);

			// Log operation.
			BulkOperationLogger::log(
				$item->attachment_id,
				$result['success'] ? 'success' : 'error',
				$result['message'] ?? ( $result['success'] ? __( 'Offloaded successfully', 'tp-media-offload-edge-cdn' ) : __( 'Operation failed', 'tp-media-offload-edge-cdn' ) )
			);

			// Check for cancellation between items.
			if ( get_transient( 'cfr2_bulk_cancelled' ) ) {
				break;
			}
		}

		// Schedule next batch if more pending.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Queue count for scheduling.
		$remaining = $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->prefix}cfr2_offload_queue WHERE status = 'pending'"
		);

		if ( $remaining > 0 && ! get_transient( 'cfr2_bulk_cancelled' ) ) {
			QueueScheduler::schedule( 30 );
		}
	}

	/**
	 * Check whether PHP memory is near the configured limit.
	 *
	 * @return bool
	 */
	private static function is_memory_near_limit(): bool {
		$limit = wp_convert_hr_to_bytes( ini_get( 'memory_limit' ) );
		if ( $limit <= 0 ) {
			return false;
		}

		return memory_get_usage( true ) > (int) ( $limit * 0.75 );
	}

	/**
	 * Delete file from R2.
	 *
	 * @param R2Client $r2            R2Client instance.
	 * @param int      $attachment_id Attachment ID.
	 * @return array Result array with success/message.
	 */
	private static function delete_from_r2( R2Client $r2, int $attachment_id ): array {
		$r2_key = get_post_meta( $attachment_id, '_cfr2_r2_key', true );
		if ( ! $r2_key ) {
			return array(
				'success' => false,
				'message' => __( 'No R2 key found', 'tp-media-offload-edge-cdn' ),
			);
		}
		return $r2->delete_file( $r2_key );
	}
}
