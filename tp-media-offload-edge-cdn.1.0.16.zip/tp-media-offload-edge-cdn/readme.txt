=== NidaEdge ===
Contributors: salahdev
Tags: cloudflare, cdn, media, offload, image optimization
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 8.0
Stable tag: 1.0.16
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Offload WordPress media to Cloudflare R2 storage and serve via CDN with automatic image optimization.

== Description ==

**NidaEdge** is a WordPress plugin that offloads your media files to Cloudflare R2 object storage and serves them through Cloudflare's global CDN network with automatic image optimization.

= Key Features =

* **R2 Storage Integration** - Seamlessly upload media to Cloudflare R2 with S3-compatible API
* **Automatic Offload** - New uploads are automatically offloaded to R2
* **Bulk Offload** - Offload existing media library with configurable batch size
* **CDN Delivery** - Serve media through Cloudflare's global CDN network
* **Image Optimization** - Automatic WebP/AVIF conversion via Cloudflare Image Transformations
* **Responsive Images** - Smart srcset generation with preset breakpoints (320, 640, 768, 1024, 1280, 1536)
* **Quality Control** - Configurable image quality (1-100)
* **Worker Auto-Deploy** - One-click Cloudflare Worker deployment for image processing
* **WooCommerce Support** - Full integration with product images and galleries
* **Background Processing** - Queue-based processing with WP Cron (Action Scheduler supported)
* **Media Library Integration** - Status column, bulk actions, and row actions
* **WP-CLI Support** - Command line interface for bulk operations and automation

= Requirements =

* WordPress 6.0 or higher
* PHP 8.0 or higher
* Cloudflare account with R2 storage enabled
* R2 bucket with API credentials. Public bucket access is optional when using the Worker R2 binding.
* Cloudflare API Token (for Worker deployment)

= How It Works =

1. Configure your R2 credentials (Account ID, Access Key, Secret Key, Bucket)
2. Set up your CDN URL on a Cloudflare proxied custom domain
3. Enable auto-offload or use bulk offload for existing media
4. Plugin automatically rewrites URLs to serve from CDN
5. Cloudflare Worker handles image transformations on-the-fly

= Security =

* API credentials encrypted with AES-256-CBC + HMAC
* Rate limiting on settings saves
* Nonce verification on all AJAX requests
* Capability checks for all admin operations
* Secure uninstall (wipes all sensitive data)

= Performance =

* Batch processing to prevent memory exhaustion
* Transient caching for dashboard stats
* Conditional asset loading
* Background queue processing

= Build and Generated Assets =

This plugin includes compiled frontend assets in:

* `assets/js/admin.js` and `assets/js/public.js`
* `assets/css/admin.css` and `assets/css/public.css`

Source files are included in the same plugin package:

* JavaScript source: `assets/src/js/admin.js`, `assets/src/js/public.js`
* SCSS source: `assets/src/scss/admin.scss`, `assets/src/scss/public.scss`

Build steps used to generate compiled files:

1. `npm install`
2. `npm run build`

Development watch mode:

* `npm run dev`

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/tp-media-offload-edge-cdn` or install through WordPress plugins screen
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to **NidaEdge** in the admin menu

= Initial Setup =

**Step 1: Configure R2 Storage**

1. Log in to your Cloudflare dashboard
2. Go to R2 > Overview and create a bucket
3. Go to R2 > Manage R2 API Tokens
4. Create a new API token with read/write access
5. Copy Account ID, Access Key ID, and Secret Access Key
6. Enter these in the plugin's Storage tab

**Step 2: Configure CDN (Optional but Recommended)**

1. In Cloudflare, set up a custom domain for your R2 bucket
2. Or use the R2.dev public URL
3. Enter the CDN URL in the plugin's CDN tab

**Step 3: Deploy Worker (For Image Optimization)**

1. Create a Cloudflare API Token with Workers permissions
2. Enter the token in the CDN tab
3. Click "Deploy Worker" button
4. Worker will be automatically deployed

**Step 4: Start Offloading**

1. Enable "Auto Offload" for new uploads
2. Use "Bulk Actions" tab to offload existing media
3. Monitor progress in the terminal-style activity log

= WP-CLI Commands =

The plugin provides WP-CLI commands for automation and bulk operations:

`wp cfr2 status`
Show offload statistics (total, offloaded, not offloaded, disk saveable, pending).

`wp cfr2 offload <id|all> [--dry-run] [--batch-size=50]`
Offload media to R2. Use specific ID or "all" for bulk offload.

`wp cfr2 restore <id|all> [--dry-run] [--batch-size=50]`
Restore media from R2 (removes R2 metadata, reverts to local URLs).

`wp cfr2 free-space <id|all> [--dry-run] [--batch-size=50]`
Delete local files for offloaded media to free disk space.

**Examples:**

    # Check current offload status
    wp cfr2 status

    # Offload single attachment
    wp cfr2 offload 123

    # Offload all media with larger batch size
    wp cfr2 offload all --batch-size=100

    # Preview what would be offloaded (dry run)
    wp cfr2 offload all --dry-run

    # Free disk space by removing local copies
    wp cfr2 free-space all

== External services ==

This plugin connects to Cloudflare services to offload media and deliver files via CDN.

= Cloudflare R2 Object Storage =

* **What it is used for:** Store and serve media objects.
* **Data sent:** Account ID, Access Key ID, Secret Access Key, bucket name, file paths, and media file contents.
* **When data is sent:** During connection testing, single/bulk offload, restore, and local-file cleanup actions.
* **Service provider:** Cloudflare, Inc.
* **Terms of Service:** https://www.cloudflare.com/website-terms/
* **Privacy Policy:** https://www.cloudflare.com/privacypolicy/

= Cloudflare API (Workers and DNS) =

* **What it is used for:** Deploy/remove Workers, validate DNS records, and enable DNS proxy for CDN routing.
* **Data sent:** API token, account ID, zone ID, DNS record ID, worker configuration, and configured CDN domain.
* **When data is sent:** When you click Deploy Worker, Remove Worker, Validate DNS, or Enable Proxy.
* **Service provider:** Cloudflare, Inc.
* **Terms of Service:** https://www.cloudflare.com/website-terms/
* **Privacy Policy:** https://www.cloudflare.com/privacypolicy/

== Frequently Asked Questions ==

= What is Cloudflare R2? =

Cloudflare R2 is an S3-compatible object storage service with zero egress fees. It's perfect for storing and serving media files.

= Do I need a paid Cloudflare plan? =

No, R2 storage is available on all Cloudflare plans including Free. You get 10GB storage free per month. Pricing: $0.015/GB/month after that.

= What about Cloudflare Image Transformations pricing? =

First 5,000 transformations per month are free. After that, it's $0.50 per 1,000 transformations. The plugin tracks your usage in the dashboard.

= Can I keep local files after offloading? =

Yes, there's an option to keep local files. This is useful for backup or if you need local file access.

= What happens if I deactivate the plugin? =

Media URLs will revert to local paths. Your files remain in R2 storage. The plugin stores original local URLs for seamless fallback.

= Does it work with WooCommerce? =

Yes! Full WooCommerce integration for product images, galleries, and thumbnails.

= Can I restore files from R2 to local? =

Yes, use the "Restore" action in Media Library or bulk restore in the Bulk Actions tab.

= What image formats are supported for optimization? =

The plugin supports WebP (recommended) and AVIF conversion. Original format is preserved as fallback.

= Is it multisite compatible? =

Currently designed for single-site installations. Multisite support is planned for future releases.

= Does it support WP-CLI? =

Yes! The plugin includes WP-CLI commands for bulk operations: `wp cfr2 status`, `wp cfr2 offload`, `wp cfr2 restore`, and `wp cfr2 free-space`. All commands support `--dry-run` and `--batch-size` options.

== Screenshots ==

1. Dashboard with setup guides and statistics
2. Storage settings with R2 credentials
3. CDN settings with Worker deployment
4. Bulk Actions with terminal-style activity log
5. Media Library with offload status column
6. System Info with debug information

== Changelog ==

= 1.0.16 =
* Reduced background processing to memory-safe batches for shared hosting.
* Added a queue worker lock to prevent concurrent WP-Cron runs from processing multiple images at once.
* Limited bulk enqueue requests to small chunks so the Bulk Actions page does not exhaust PHP memory.
* Added safer batch-size options starting at one file per batch.

= 1.0.15 =
* Changed bulk actions to queue background work and monitor progress instead of processing every file in the browser tab.
* Added queue recovery for items left in processing state after a timeout.
* Improved Worker status detection by treating a valid Worker health response as an active route.
* Tightened CDN availability checks to require the plugin Worker health response, not just any HTTP 200 page.
* Improved the Worker transform path and added diagnostics for fallback-to-original image responses.

= 1.0.14 =
* Fixed Worker status diagnostics to use the Cloudflare Workers settings API instead of the raw script download endpoint.
* Improved diagnostics so a healthy Worker `/health` response is treated as a working route even if the API status check is inconclusive.
* Added a visible "Delete All Plugin Data" button in Reset Tools.
* Hardened sync delete by falling back to the offload status table when attachment metadata is incomplete, and by logging R2 delete failures clearly.

= 1.0.13 =
* Moved the Cloudflare API token field and "Save Token Only" action outside the hidden CDN options area so it is always visible in the CDN tab.
* Added a visible token-fix build marker in the CDN tab to confirm the installed build is the current package.

= 1.0.12 =
* Added a standalone Cloudflare token store and a dedicated "Save Token Only" action to bypass hosts or security tools that drop token values from the main settings form.
* Updated all Cloudflare validation and diagnostics to read the standalone token store before falling back to the general settings option.
* Added a wp-config.php fallback snippet in the CDN tab for environments that block saving API tokens from wp-admin.

= 1.0.11 =
* Hardened Cloudflare API token saving so pasted curl verify commands and Authorization Bearer headers are recognized automatically.
* Added a clear save-time error when the API token cannot be recognized instead of silently keeping an empty token.
* Improved diagnostics for saved-but-unreadable token values.

= 1.0.10 =
* Added a read-only Cloudflare Diagnostics tool that identifies whether the blocker is plugin settings, server networking, Cloudflare API authentication, DNS, Worker routing, R2, or image transformation.
* Added stronger RTL handling for Arabic admin paragraphs, setup guides, notices, diagnostics, and form descriptions while preserving the existing design.
* Added Arabic handling for dynamic JavaScript messages shown after AJAX actions.

= 1.0.9 =
* Completed Arabic translations for the setup guide, CDN instructions, permissions table, reset tools, and legal disclaimer.
* Updated CDN/R2 setup guidance to match the current Worker route and R2 binding flow.
* Added a reset tool for clearing saved settings and local plugin cache from the database without deleting R2 files or media library records.
* Clarified that R2 public access is optional for Worker image optimization.

= 1.0.8 =
* Replaced corrupted Arabic MO files with safe inline Arabic translations for the main admin screens.
* Hardened Cloudflare token normalization to prevent invalid Authorization headers.
* Removed the old embedded custom admin icon and switched fully to a WordPress default cloud icon.
* Improved the sidebar visual overrides so the active tab stays light and clean.

= 1.0.7 =
* Removed bundled site-specific Cloudflare account and bucket defaults.
* Added optional R2 region and S3 endpoint settings for per-site configuration.
* Hardened Cloudflare API token handling to strip Bearer prefixes and whitespace before requests.
* Fixed uninstall cleanup so plugin deletion does not require Composer classes.
* Switched to a standard WordPress admin menu icon.
* Added bundled Arabic translations for the main settings UI.

= 1.0.6 =
* Rebranded the plugin as NidaEdge by salahdev.
* Added uploads/ object prefix for new R2 media files and thumbnails.
* Added a refreshed admin UI layer without changing the settings order.

= 1.0.2 =
* Follow-up release for 1.0.1 to correct packaged version metadata in WordPress.org SVN trunk and tag builds.
* Added stricter release verification so plugin header `Version`, `CFR2_VERSION`, `Stable tag`, and generated SVN artifacts must match the requested release version before deployment.
* Updated release documentation and changelog metadata for the 1.0.2 rollout.

= 1.0.1 =
* Fixed plugin activation to create the full R2/CDN settings schema instead of legacy placeholder settings.
* Added settings normalization and migration so existing installs automatically receive missing keys safely.
* Improved validation across settings save, Worker actions, WP-CLI, media actions, and queue processing with clearer configuration errors.
* Hardened queue scheduling fallback for sites without Action Scheduler and reduced duplicate queue items in bulk operations.
* Fixed Cloudflare zone detection for custom domains, corrected Worker route generation, and cleared CDN availability cache when CDN settings change.
* Updated uninstall/deactivation cleanup to handle current encrypted secrets correctly.
* Cleaned up PHPCS violations, repaired PHPMD and pre-commit tooling, refreshed bundled documentation, and added regression tests.

= 1.0.0 =
* Initial release
* R2 storage integration with AWS SDK
* Automatic and bulk media offload
* CDN URL rewriting
* Cloudflare Worker auto-deployment
* Image optimization (WebP/AVIF)
* Responsive srcset generation
* WooCommerce integration
* Background queue processing
* Rate limiting and security features
* Dashboard with usage statistics
* WP-CLI commands (status, offload, restore, free-space)

== Upgrade Notice ==

= 1.0.16 =
Prevents Out of Memory failures by processing one small background batch at a time and preventing concurrent queue workers.

= 1.0.15 =
Bulk operations now run through the background queue, Worker route detection is clearer, and image transform fallbacks are diagnosed.

= 1.0.14 =
Fixes the false Worker "Invalid JSON response" warning, adds full data cleanup from the UI, and improves sync delete reliability.

= 1.0.13 =
Makes the dedicated Cloudflare token save control always visible and adds an on-screen build marker to confirm the active package.

= 1.0.12 =
Adds the root fix for Cloudflare token persistence using a standalone token store and a dedicated token save button.

= 1.0.11 =
Fixes Cloudflare API token saving when pasted from Cloudflare examples or curl commands.

= 1.0.10 =
Adds Cloudflare Diagnostics and improved Arabic/RTL handling for dynamic admin messages.

= 1.0.9 =
Adds Arabic setup instructions and a safe reset button for stale saved settings or cached Cloudflare/R2 values.

= 1.0.8 =
Fixes Arabic question marks, Cloudflare invalid request headers, and the sidebar active-tab styling.

= 1.0.7 =
Recommended security and compatibility update. Re-enter the raw Cloudflare API token if Worker deployment still reports token errors.

= 1.0.6 =
Recommended update for NidaEdge branding, uploads/ R2 organization, and admin UI polish.

= 1.0.2 =
Recommended update. This release republishes the 1.0.1 fixes with corrected release metadata and stronger SVN packaging verification.

= 1.0.1 =
Recommended update. This release fixes settings schema mismatches, improves validation and queue reliability, and updates release tooling/docs.

= 1.0.0 =
Initial release. Please backup your database before installing.

== Privacy Policy ==

This plugin:
* Stores your Cloudflare API credentials encrypted in your WordPress database
* Uploads your media files to your Cloudflare R2 bucket
* Sends required API data directly to Cloudflare services to provide plugin functionality
* Does not include any tracking or analytics

Your data stays between your WordPress site and your Cloudflare account.

== Support ==

For support, feature requests, or bug reports, contact the site developer or open a private maintenance issue for this project.

== Credits ==

* Built with AWS SDK for PHP for R2 compatibility
* Uses WP Cron for background processing (Action Scheduler compatible)
* Cloudflare Workers for image transformations

== Disclaimer ==

This plugin is an independent, third-party project and is **not affiliated with, endorsed by, or officially associated with Cloudflare, Inc.** in any way. "Cloudflare" and "R2" are trademarks of Cloudflare, Inc. The use of these names is solely for descriptive purposes to indicate compatibility with Cloudflare services.

This plugin is developed and maintained independently by salahdev.
