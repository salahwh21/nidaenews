<?php
/**
 * Per-request correlation id for logs and support (NidaEdge / CFR2).
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Services;

defined( 'ABSPATH' ) || exit;

/**
 * Generates a stable id for the current HTTP request lifecycle.
 */
class RequestCorrelation {

	/**
	 * Cached id for this request.
	 *
	 * @var string|null
	 */
	private static ?string $id = null;

	/**
	 * Get or create the correlation id (16 hex chars).
	 */
	public static function get_id(): string {
		if ( null === self::$id ) {
			try {
				self::$id = bin2hex( random_bytes( 8 ) );
			} catch ( \Throwable $e ) {
				self::$id = substr( sha1( (string) wp_rand() . microtime( true ) ), 0, 16 );
			}
		}

		return self::$id;
	}

	/**
	 * Add request_id to a result array when it represents a failure.
	 *
	 * @param array<string, mixed> $result Must include boolean "success".
	 * @return array<string, mixed>
	 */
	public static function enrich_failure( array $result ): array {
		if ( isset( $result['success'] ) && ! $result['success'] ) {
			$result['request_id'] = self::get_id();
		}

		return $result;
	}
}
