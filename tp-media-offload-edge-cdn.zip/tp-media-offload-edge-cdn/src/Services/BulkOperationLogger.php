<?php
/**
 * Bulk Operation Logger class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Services;

defined( 'ABSPATH' ) || exit;

/**
 * Bulk Operation Logger class - enhanced logging with levels and context.
 */
class BulkOperationLogger {

	/**
	 * Option key for storing logs.
	 */
	private const OPTION_KEY = 'cfr2_bulk_operation_logs';

	/**
	 * Maximum number of logs to store.
	 */
	private const MAX_LOGS = 100;

	/**
	 * Log levels.
	 */
	public const LEVEL_DEBUG = 'debug';
	public const LEVEL_INFO = 'info';
	public const LEVEL_WARNING = 'warning';
	public const LEVEL_ERROR = 'error';
	public const LEVEL_CRITICAL = 'critical';

	/**
	 * Log an operation with enhanced context.
	 *
	 * @param int    $attachment_id Attachment ID.
	 * @param string $status        Status (success|error).
	 * @param string $message       Log message.
	 * @param string $level         Log level (debug|info|warning|error|critical).
	 * @param array  $context       Additional context data.
	 */
	public static function log( int $attachment_id, string $status, string $message, string $level = self::LEVEL_INFO, array $context = array() ): void {
		$logs = self::get_all_logs();

		// Get attachment filename.
		$filename = basename( get_attached_file( $attachment_id ) );

		// Build enhanced context.
		$enhanced_context = array_merge(
			$context,
			array(
				'user_id' => get_current_user_id(),
				'memory'  => memory_get_usage( true ),
				'time'    => microtime( true ),
			)
		);

		// Add new log entry.
		$logs[] = array(
			'timestamp'     => time(),
			'attachment_id' => $attachment_id,
			'filename'      => $filename,
			'status'        => $status,
			'level'         => $level,
			'message'       => $message,
			'context'       => $enhanced_context,
		);

		// Keep only last MAX_LOGS entries.
		if ( count( $logs ) > self::MAX_LOGS ) {
			$logs = array_slice( $logs, -self::MAX_LOGS );
		}

		update_option( self::OPTION_KEY, $logs, false );
	}

	/**
	 * Get recent logs.
	 *
	 * @param int    $limit Number of logs to retrieve.
	 * @param string $level Optional log level filter.
	 * @return array Log entries.
	 */
	public static function get_logs( int $limit = 20, string $level = '' ): array {
		$logs = self::get_all_logs();

		// Filter by level if specified.
		if ( $level && '' !== $level ) {
			$logs = array_filter(
				$logs,
				function ( $log ) use ( $level ) {
					return isset( $log['level'] ) && $log['level'] === $level;
				}
			);
		}

		// Return most recent first.
		$logs = array_reverse( $logs );

		return array_slice( $logs, 0, $limit );
	}

	/**
	 * Get failed logs.
	 *
	 * @return array Failed log entries.
	 */
	public static function get_failed(): array {
		$logs = self::get_all_logs();

		return array_filter(
			$logs,
			function ( $log ) {
				return 'error' === $log['status'];
			}
		);
	}

	/**
	 * Clear all logs.
	 */
	public static function clear(): void {
		delete_option( self::OPTION_KEY );
	}

	/**
	 * Get log summary.
	 *
	 * @return array Summary with counts by status and level.
	 */
	public static function get_summary(): array {
		$logs = self::get_all_logs();

		$summary = array(
			'total'     => count( $logs ),
			'success'   => 0,
			'error'     => 0,
			'levels'    => array(
				'debug'    => 0,
				'info'     => 0,
				'warning'  => 0,
				'error'    => 0,
				'critical' => 0,
			),
		);

		foreach ( $logs as $log ) {
			// Count by status.
			if ( 'success' === $log['status'] ) {
				++$summary['success'];
			} elseif ( 'error' === $log['status'] ) {
				++$summary['error'];
			}

			// Count by level.
			if ( isset( $log['level'] ) && isset( $summary['levels'][ $log['level'] ] ) ) {
				++$summary['levels'][ $log['level'] ];
			}
		}

		return $summary;
	}

	/**
	 * Export logs as JSON.
	 *
	 * @param string $level Optional log level filter.
	 * @return string JSON string.
	 */
	public static function export_json( string $level = '' ): string {
		$logs = self::get_logs( self::MAX_LOGS, $level );
		return wp_json_encode( $logs, JSON_PRETTY_PRINT );
	}

	/**
	 * Export logs as CSV.
	 *
	 * @param string $level Optional log level filter.
	 * @return string CSV string.
	 */
	public static function export_csv( string $level = '' ): string {
		$logs = self::get_logs( self::MAX_LOGS, $level );

		if ( empty( $logs ) ) {
			return '';
		}

		$csv = 'Timestamp,Attachment ID,Filename,Status,Level,Message' . PHP_EOL;

		foreach ( $logs as $log ) {
			$csv .= sprintf(
				'%d,%d,"%s","%s","%s","%s"',
				$log['timestamp'],
				$log['attachment_id'],
				$log['filename'],
				$log['status'],
				$log['level'] ?? '',
				str_replace( '"', '""', $log['message'] )
			);
			$csv .= PHP_EOL;
		}

		return $csv;
	}

	/**
	 * Get all logs from database.
	 *
	 * @return array All log entries.
	 */
	private static function get_all_logs(): array {
		$logs = get_option( self::OPTION_KEY, array() );

		if ( ! is_array( $logs ) ) {
			return array();
		}

		return $logs;
	}
}
