<?php
/**
 * R2 key migrator service.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Services;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Constants\MetaKeys;

/**
 * Migrates legacy/invalid R2 keys into the canonical uploads/ path format.
 */
class R2KeyMigrator {

	/**
	 * Process a migration batch.
	 *
	 * @param int $cursor Last scanned attachment ID.
	 * @param int $limit  Maximum rows to scan in this request.
	 * @param bool $dry_run Whether to simulate updates without writing.
	 * @return array<string, int|bool>
	 */
	public function migrate_batch( int $cursor = 0, int $limit = 200, bool $dry_run = false ): array {
		global $wpdb;

		$cursor = max( 0, $cursor );
		$limit  = max( 1, min( $limit, 500 ) );

		// +1 row for has_more detection.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-off migration utility.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID
				 FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} pm
					on p.ID = pm.post_id
					AND pm.meta_key = %s
					AND pm.meta_value = '1'
				 WHERE p.post_type = 'attachment'
					AND p.post_status = 'inherit'
					AND p.ID > %d
				 ORDER BY p.ID ASC
				 LIMIT %d",
				MetaKeys::OFFLOADED,
				$cursor,
				$limit + 1
			)
		);

		if ( empty( $rows ) ) {
			return array(
				'scanned'   => 0,
				'updated'   => 0,
				'cursor'    => $cursor,
				'has_more'  => false,
			);
		}

		$has_more   = count( $rows ) > $limit;
		$rows       = array_slice( $rows, 0, $limit );
		$updated    = 0;
		$last_id    = $cursor;

		foreach ( $rows as $row ) {
			$attachment_id = (int) $row->ID;
			$last_id       = $attachment_id;

			if ( $this->migrate_attachment( $attachment_id, $dry_run ) ) {
				++$updated;
			}
		}

		return array(
			'scanned'   => count( $rows ),
			'updated'   => $updated,
			'cursor'    => $last_id,
			'has_more'  => $has_more,
		);
	}

	/**
	 * Migrate one attachment keys.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @param bool $dry_run Whether to simulate updates.
	 * @return bool True when any value was updated.
	 */
	private function migrate_attachment( int $attachment_id, bool $dry_run = false ): bool {
		global $wpdb;

		$changed = false;

		$raw_r2_key = (string) get_post_meta( $attachment_id, MetaKeys::R2_KEY, true );
		$raw_r2_url = (string) get_post_meta( $attachment_id, MetaKeys::R2_URL, true );

		$normalized_main = $this->normalize_key( $raw_r2_key );
		if ( '' === $normalized_main && '' !== $raw_r2_url ) {
			$normalized_main = $this->normalize_key( $raw_r2_url );
		}

		if ( '' !== $normalized_main && $normalized_main !== $raw_r2_key ) {
			if ( ! $dry_run ) {
				update_post_meta( $attachment_id, MetaKeys::R2_KEY, $normalized_main );

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Migration update.
				$wpdb->update(
					$wpdb->prefix . 'cfr2_offload_status',
					array( 'r2_key' => $normalized_main ),
					array( 'attachment_id' => $attachment_id ),
					array( '%s' ),
					array( '%d' )
				);
			}

			$changed = true;
		}

		$thumbs = get_post_meta( $attachment_id, MetaKeys::THUMBNAILS, true );
		if ( is_array( $thumbs ) && ! empty( $thumbs ) ) {
			$thumbs_changed = false;

			foreach ( $thumbs as $size => $thumb_data ) {
				if ( ! is_array( $thumb_data ) ) {
					continue;
				}

				$current_thumb_key = (string) ( $thumb_data['r2_key'] ?? '' );
				if ( '' === $current_thumb_key ) {
					continue;
				}

				$normalized_thumb_key = $this->normalize_key( $current_thumb_key );
				if ( '' !== $normalized_thumb_key && $normalized_thumb_key !== $current_thumb_key ) {
					$thumbs[ $size ]['r2_key'] = $normalized_thumb_key;
					$thumbs_changed            = true;
				}
			}

			if ( $thumbs_changed ) {
				if ( ! $dry_run ) {
					update_post_meta( $attachment_id, MetaKeys::THUMBNAILS, $thumbs );
				}
				$changed = true;
			}
		}

		return $changed;
	}

	/**
	 * Normalize key (or URL-like value) into canonical uploads/... object key.
	 *
	 * @param string $value Raw key or URL.
	 * @return string
	 */
	private function normalize_key( string $value ): string {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}

		$value = str_replace( '\\', '/', $value );

		$parsed = wp_parse_url( $value );
		if ( is_array( $parsed ) && isset( $parsed['path'] ) ) {
			$value = (string) $parsed['path'];
		}

		$value = rawurldecode( $value );
		$value = ltrim( $value, '/' );

		if ( 0 === strpos( $value, 'wp-content/uploads/' ) ) {
			$value = substr( $value, strlen( 'wp-content/uploads/' ) );
		}

		while ( 0 === strpos( $value, 'uploads/uploads/' ) ) {
			$value = substr( $value, strlen( 'uploads/' ) );
		}

		if ( '' === $value ) {
			return '';
		}

		if ( 0 !== strpos( $value, 'uploads/' ) ) {
			$value = 'uploads/' . $value;
		}

		return trim( $value );
	}
}
