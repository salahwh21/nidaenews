<?php
/**
 * Cloudflare token helper.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Services;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Constants\Settings;

/**
 * Normalizes Cloudflare API tokens before they are used in HTTP headers.
 */
class CloudflareToken {

	/**
	 * Normalize a token copied from the Cloudflare dashboard.
	 *
	 * @param string $token Raw token.
	 * @return string Header-safe token, or empty string when invalid.
	 */
	public static function normalize( string $token ): string {
		$token = html_entity_decode( trim( $token ), ENT_QUOTES, 'UTF-8' );
		$token = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $token );

		if ( preg_match( '/Authorization\s*:\s*Bearer\s+([A-Za-z0-9_.-]{20,})/i', (string) $token, $matches ) ) {
			$token = $matches[1];
		} elseif ( preg_match( '/Bearer\s+([A-Za-z0-9_.-]{20,})/i', (string) $token, $matches ) ) {
			$token = $matches[1];
		} elseif ( preg_match( '/\b(cf[a-z0-9]*_[A-Za-z0-9_.-]{20,})\b/i', (string) $token, $matches ) ) {
			$token = $matches[1];
		}

		$token = preg_replace( '/^\s*Authorization\s*:\s*/i', '', (string) $token );
		$token = preg_replace( '/^\s*Bearer\s+/i', '', (string) $token );
		$token = trim( (string) $token, " \t\n\r\0\x0B\"'" );
		$clean = preg_replace( '/[\s\p{Cf}]+/u', '', (string) $token );
		$token = null !== $clean ? $clean : preg_replace( '/\s+/', '', (string) $token );

		if ( ! preg_match( '/\A[A-Za-z0-9_.-]{20,}\z/', (string) $token ) ) {
			return '';
		}

		return sanitize_text_field( (string) $token );
	}

	/**
	 * Resolve the API token from plugin settings or wp-config constants.
	 *
	 * @param array<string, mixed> $settings Plugin settings.
	 * @return string
	 */
	public static function from_settings( array $settings ): string {
		$stored = (string) ( $settings['cf_api_token'] ?? '' );

		if ( PluginSettings::has_wp_config_setting( 'cf_api_token' ) ) {
			return self::normalize( $stored );
		}

		$standalone = self::from_standalone_option();
		if ( '' !== $standalone ) {
			return $standalone;
		}

		$encryption = EncryptionService::get_instance();
		$token      = self::normalize( $encryption->decrypt( $stored ) );

		if ( '' !== $token ) {
			return $token;
		}

		return self::normalize( $stored );
	}

	/**
	 * Save the Cloudflare token in its own option, independent of the large settings form.
	 *
	 * @param string $raw_token Raw token or copied Cloudflare curl/header text.
	 * @return bool True when a readable token was saved.
	 */
	public static function save_standalone_option( string $raw_token ): bool {
		$token = self::normalize( $raw_token );
		if ( '' === $token ) {
			return false;
		}

		$encryption = EncryptionService::get_instance();
		$value      = $encryption->encrypt( $token );
		$value      = '' !== $value ? $value : $token;

		update_option( Settings::CF_TOKEN_KEY, $value, false );

		return '' !== self::from_standalone_option();
	}

	/**
	 * Read the standalone Cloudflare token option.
	 *
	 * @return string
	 */
	public static function from_standalone_option(): string {
		$stored = get_option( Settings::CF_TOKEN_KEY, '' );
		$stored = is_string( $stored ) ? $stored : '';

		if ( '' === $stored ) {
			return '';
		}

		$encryption = EncryptionService::get_instance();
		$token      = self::normalize( $encryption->decrypt( $stored ) );

		if ( '' !== $token ) {
			return $token;
		}

		return self::normalize( $stored );
	}

	/**
	 * Check whether the standalone option has any stored value.
	 *
	 * @return bool
	 */
	public static function has_standalone_value(): bool {
		$stored = get_option( Settings::CF_TOKEN_KEY, '' );

		return is_string( $stored ) && '' !== trim( $stored );
	}

	/**
	 * Delete the standalone Cloudflare token option.
	 */
	public static function delete_standalone_option(): void {
		delete_option( Settings::CF_TOKEN_KEY );
	}
}
