<?php
/**
 * Worker Deployer Service class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Services;

defined( 'ABSPATH' ) || exit;

/**
 * WorkerDeployer class - orchestrates Worker deployment.
 */
class WorkerDeployer {

	/**
	 * CloudflareAPI instance.
	 *
	 * @var CloudflareAPI
	 */
	private CloudflareAPI $api;

	/**
	 * Worker name.
	 *
	 * @var string
	 */
	private string $worker_name;

	/**
	 * Constructor.
	 *
	 * @param CloudflareAPI $api Cloudflare API instance.
	 */
	public function __construct( CloudflareAPI $api ) {
		$this->api         = $api;
		$this->worker_name = 'cfr2-image-transform';
	}

	/**
	 * Full deployment flow.
	 *
	 * @param array $config Configuration array.
	 * @return array Result array.
	 */
	public function deploy( array $config ): array {
		$steps = array();

		// Step 1: Verify token.
		$verify = $this->api->verify_token();
		if ( ! $verify['success'] ) {
			$error_msg = $verify['errors'][0]['message'] ?? __( 'Invalid API token', 'tp-media-offload-edge-cdn' );

			return array(
				'success' => false,
				'message' => sprintf(
					/* translators: %s: Cloudflare API error message */
					__( 'Cloudflare API token verification failed: %s', 'tp-media-offload-edge-cdn' ),
					$error_msg
				),
				'steps'   => $steps,
			);
		}
		$steps[] = array(
			'step'   => 'verify_token',
			'status' => 'success',
		);

		// Step 2: Get Worker script.
		$script = $this->get_worker_script();

		// Step 3: Upload script (creates Worker if not exists).
		$bindings = $this->get_bindings( $config );
		$upload   = $this->api->upload_version( $this->worker_name, $script, $bindings );

		if ( ! $upload['success'] ) {
			$error_msg = $upload['errors'][0]['message'] ?? 'Unknown error';
			$steps[]   = array(
				'step'   => 'upload_script',
				'status' => 'failed',
				'error'  => $error_msg,
			);
			return array(
				'success' => false,
				'message' => sprintf(
					/* translators: %s: error message */
					__( 'Failed to upload Worker script: %s', 'tp-media-offload-edge-cdn' ),
					$error_msg
				),
				'steps'   => $steps,
			);
		}
		$steps[] = array(
			'step'   => 'upload_script',
			'status' => 'success',
		);

		// Step 4: Enable subdomain (simple deployment).
		$deploy  = $this->api->deploy_worker( $this->worker_name );
		$steps[] = array(
			'step'   => 'deploy',
			'status' => $deploy['success'] ? 'success' : 'warning',
		);

		// Step 5: Validate/Create DNS record if custom domain provided.
		$warnings = array();
		if ( ! empty( $config['custom_domain'] ) ) {
			$dns_result = $this->api->validate_cdn_dns( $config['custom_domain'] );
			$steps[]    = array(
				'step'   => 'dns_validation',
				'status' => $dns_result['success'] ? 'success' : 'warning',
				'action' => $dns_result['action'] ?? null,
			);

			if ( ! empty( $dns_result['warnings'] ) ) {
				$warnings = array_merge( $warnings, $dns_result['warnings'] );
			}

			// Step 6: Remove old Workers Route if exists (to avoid conflict).
			if ( $dns_result['success'] && ! empty( $dns_result['zone_id'] ) ) {
				$parsed = wp_parse_url( $config['custom_domain'] );
				$host   = ! empty( $parsed['host'] ) ? $parsed['host'] : $config['custom_domain'];
				$host   = trim( $host, '/' );
				$pattern = "{$host}/*";

				$delete_route_result = $this->api->delete_route( $dns_result['zone_id'], $pattern );
				$steps[] = array(
					'step'   => 'delete_old_route',
					'status' => $delete_route_result['success'] ? 'success' : 'warning',
					'message' => $delete_route_result['success'] ? __( 'Old Workers Route removed', 'tp-media-offload-edge-cdn' ) : ( $delete_route_result['message'] ?? __( 'Route not found or already removed', 'tp-media-offload-edge-cdn' ) ),
				);
			}

			// Step 7: Configure Custom Domain (replaces Workers Route).
			if ( $dns_result['success'] ) {
				$custom_domain_result = $this->configure_custom_domain( $config['custom_domain'] );
				$steps[] = array(
					'step'   => 'configure_custom_domain',
					'status' => $custom_domain_result['success'] ? 'success' : 'warning',
					'domain' => $custom_domain_result['domain'] ?? null,
				);

				if ( ! $custom_domain_result['success'] ) {
					$warnings[] = $custom_domain_result['message'] ?? __( 'Failed to configure Custom Domain', 'tp-media-offload-edge-cdn' );
				}
			}
		}

		return array(
			'success'     => true,
			'message'     => __( 'Worker deployed successfully', 'tp-media-offload-edge-cdn' ),
			'worker_name' => $this->worker_name,
			'steps'       => $steps,
			'warnings'    => $warnings,
		);
	}

	/**
	 * Get Worker status.
	 *
	 * @return array Status array.
	 */
	public function get_status(): array {
		return $this->api->get_worker_status( $this->worker_name );
	}

	/**
	 * Remove Worker and associated Custom Domain.
	 *
	 * @return array Result array.
	 */
	public function undeploy(): array {
		$steps = array();

		// Step 1: Remove Custom Domains.
		$custom_domains = $this->api->get_custom_domains( $this->worker_name );
		if ( $custom_domains['success'] && ! empty( $custom_domains['result'] ) ) {
			foreach ( $custom_domains['result'] as $cd ) {
				$delete_result = $this->api->delete_custom_domain( $cd['id'] );
				$steps[] = array(
					'step'   => 'delete_custom_domain',
					'domain' => $cd['hostname'],
					'status' => $delete_result['success'] ? 'success' : 'warning',
				);
			}
		}

		// Step 2: Delete Worker.
		$delete_result = $this->api->delete_worker( $this->worker_name );
		$steps[] = array(
			'step'   => 'delete_worker',
			'status' => $delete_result['success'] ? 'success' : 'failed',
		);

		return array(
			'success' => $delete_result['success'],
			'steps'   => $steps,
		);
	}

	/**
	 * Generate Worker script from template.
	 *
	 * @return string Worker script.
	 */
	private function get_worker_script(): string {
		$template_path = \CFR2_PATH . 'src/Templates/worker-script.js';
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local bundled template file.
		$script = file_get_contents( $template_path );

		// Replace placeholders.
		$script = str_replace( '{{VERSION}}', \CFR2_VERSION, $script );

		return $script;
	}

	/**
	 * Get Worker environment bindings.
	 *
	 * @param array $config Configuration array.
	 * @return array Bindings array.
	 */
	private function get_bindings( array $config ): array {
		$bindings = array();

		// R2 bucket binding (direct access - faster, no public access needed).
		if ( ! empty( $config['r2_bucket'] ) ) {
			$bindings[] = array(
				'type'        => 'r2_bucket',
				'name'        => 'BUCKET',
				'bucket_name' => $config['r2_bucket'],
			);
		}

		// Image format setting (original, webp, avif).
		$bindings[] = array(
			'type' => 'plain_text',
			'name' => 'IMAGE_FORMAT',
			'text' => $config['image_format'] ?? 'webp',
		);

		// cf.image must fetch a URL that hits this Worker. Custom domains tied to R2 can answer
		// /_cfr2_origin/* with 404; Workers.dev always runs the script.
		$self_origin = $this->api->get_workers_dev_origin( $this->worker_name );
		if ( null !== $self_origin && '' !== $self_origin ) {
			$bindings[] = array(
				'type' => 'plain_text',
				'name' => 'WORKER_SELF_URL',
				'text' => $self_origin,
			);
		}

		return $bindings;
	}

	/**
	 * Configure Custom Domain for Worker (replaces Workers Route).
	 *
	 * @param string $domain Custom domain URL (e.g., https://photo.example.com).
	 * @return array Result array.
	 */
	private function configure_custom_domain( string $domain ): array {
		$parsed = wp_parse_url( $domain );
		$host   = ! empty( $parsed['host'] ) ? $parsed['host'] : $domain;
		$host   = trim( $host, '/' );

		// Check if Custom Domain already exists.
		$existing = $this->api->get_custom_domains( $this->worker_name );
		if ( $existing['success'] && ! empty( $existing['result'] ) ) {
			foreach ( $existing['result'] as $cd ) {
				if ( $cd['hostname'] === $host ) {
					return array(
						'success' => true,
						'domain'  => $host,
						'message' => __( 'Custom Domain already configured', 'tp-media-offload-edge-cdn' ),
					);
				}
			}
		}

		// Create Custom Domain.
		$result = $this->api->create_custom_domain( $this->worker_name, $host );

		if ( $result['success'] ) {
			return array(
				'success' => true,
				'domain'  => $host,
				'id'      => $result['result']['id'] ?? null,
			);
		}

		return array(
			'success' => false,
			'message' => $result['errors'][0]['message'] ?? __( 'Failed to configure Custom Domain', 'tp-media-offload-edge-cdn' ),
		);
	}
}
