<?php
/**
 * URL Rewriter Service class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Services;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Hooks\ExtensibilityHooks;
use Salahdev\NidaEdge\Interfaces\HookableInterface;
use Salahdev\NidaEdge\Constants\MetaKeys;

/**
 * URLRewriter class - handles URL transformation for CDN.
 */
class URLRewriter implements HookableInterface {

	/**
	 * Responsive breakpoints for srcset.
	 */
	private const BREAKPOINTS = array( 320, 640, 768, 1024, 1280, 1536 );

	/**
	 * Tracked attachment IDs per request to avoid duplicate counting.
	 *
	 * @var array<int, bool>
	 */
	private static array $tracked_transformations = array();

	/**
	 * Plugin settings.
	 *
	 * @var array
	 */
	private array $settings;

	/**
	 * CDN availability status.
	 *
	 * @var bool
	 */
	private bool $cdn_available;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->settings      = PluginSettings::get();
		$this->cdn_available = $this->check_cdn_availability();
	}

	/**
	 * Register hooks.
	 */
	public function register_hooks(): void {
		// Register if CDN enabled OR R2 public domain is set.
		$has_cdn    = ! empty( $this->settings['cdn_enabled'] ) && ! empty( $this->settings['cdn_url'] );
		$has_r2_pub = ! empty( $this->settings['r2_public_domain'] );

		if ( ! $has_cdn && ! $has_r2_pub ) {
			return;
		}

		add_filter( 'wp_get_attachment_url', array( $this, 'rewrite_attachment_url' ), 99, 2 );
		add_filter( 'wp_get_attachment_image_attributes', array( $this, 'add_lazy_loading' ), 10, 3 );

		// Thumbnail/list URLs: CDN transforms when Worker works; otherwise direct R2 public URLs per size (fixes admin when local files are deleted).
		if ( $has_cdn || $has_r2_pub ) {
			add_filter( 'wp_get_attachment_image_src', array( $this, 'rewrite_image_src' ), 99, 4 );
		}

		// Srcset/size transforms only when CDN Worker is enabled.
		if ( $has_cdn ) {
			add_filter( 'wp_calculate_image_srcset', array( $this, 'generate_srcset' ), 99, 5 );

			// Wrap images in <picture> element for AVIF/WebP support (WP 6.0+).
			add_filter( 'wp_content_img_tag', array( $this, 'wrap_with_picture_element' ), 10, 3 );
		}

		// Cache invalidation hooks.
		add_action( 'add_attachment_metadata', array( $this, 'invalidate_attachment_cache' ), 10, 2 );
		add_action( 'delete_attachment', array( $this, 'invalidate_attachment_cache' ), 10, 1 );
		add_action( 'edit_attachment', array( $this, 'invalidate_attachment_cache' ), 10, 1 );
	}

	/**
	 * Rewrite attachment URL to CDN or R2 public domain.
	 *
	 * @param string $url Attachment URL.
	 * @param int    $attachment_id Attachment ID.
	 * @return string Rewritten URL.
	 */
	public function rewrite_attachment_url( string $url, int $attachment_id ): string {
		// Check if offloaded.
		$is_offloaded = get_post_meta( $attachment_id, MetaKeys::OFFLOADED, true );
		if ( ! $is_offloaded ) {
			return $url;
		}

		// Get R2 key.
		$r2_key = get_post_meta( $attachment_id, MetaKeys::R2_KEY, true );
		if ( ! $r2_key ) {
			return $url;
		}

		$local_url = get_post_meta( $attachment_id, MetaKeys::LOCAL_URL, true );
		if ( ! empty( $this->settings['local_fallback_enabled'] ) && ! empty( $local_url ) ) {
			return $local_url;
		}

		// Priority 1: CDN with Worker (if enabled and available).
		$cdn_enabled = ! empty( $this->settings['cdn_enabled'] ) && ! empty( $this->settings['cdn_url'] );
		if ( $cdn_enabled && $this->cdn_available ) {
			// Track transformation for stats.
			$this->track_transformation( $attachment_id );

			$params = array(
				'quality' => $this->settings['quality'] ?? 85,
			);

			// Only add format if not 'original'.
			$image_format = $this->settings['image_format'] ?? 'webp';
			if ( 'original' !== $image_format ) {
				$params['format'] = $image_format;
			}

			return $this->build_cdn_url( $r2_key, $params );
		}

		// Priority 2: R2 public domain (no transforms, just direct URL).
		if ( ! empty( $this->settings['r2_public_domain'] ) ) {
			$r2_domain = rtrim( $this->settings['r2_public_domain'], '/' );
			return "{$r2_domain}/{$r2_key}";
		}

		// Fallback: stored local URL.
		if ( ! empty( $local_url ) ) {
			return $local_url;
		}

		return $url;
	}

	/**
	 * Track transformation asynchronously.
	 *
	 * @param int $attachment_id Attachment ID.
	 */
	private function track_transformation( int $attachment_id ): void {
		if ( isset( self::$tracked_transformations[ $attachment_id ] ) ) {
			return;
		}

		self::$tracked_transformations[ $attachment_id ] = true;
		add_action(
			'shutdown',
			static function (): void {
				StatsTracker::increment();
			}
		);
	}

	/**
	 * Rewrite image src with size.
	 *
	 * @param array|false  $image Image data or false.
	 * @param int          $attachment_id Attachment ID.
	 * @param string|int[] $size Requested size.
	 * @param bool         $icon Whether to use icon.
	 * @return array|false Modified image data.
	 */
	public function rewrite_image_src( $image, int $attachment_id, $size, bool $icon ) {
		if ( ! $image || $icon ) {
			return $image;
		}

		$is_offloaded = get_post_meta( $attachment_id, MetaKeys::OFFLOADED, true );
		if ( ! $is_offloaded ) {
			return $image;
		}

		$r2_key_main = (string) get_post_meta( $attachment_id, MetaKeys::R2_KEY, true );
		if ( '' === $r2_key_main ) {
			return $image;
		}

		$local_url = get_post_meta( $attachment_id, MetaKeys::LOCAL_URL, true );
		if ( ! empty( $this->settings['local_fallback_enabled'] ) && ! empty( $local_url ) ) {
			return $image;
		}

		$cdn_enabled = ! empty( $this->settings['cdn_enabled'] ) && ! empty( $this->settings['cdn_url'] );

		// Worker URL (resize from original object) when CDN is on and health check passes.
		if ( $cdn_enabled && $this->cdn_available ) {
			$width  = $image[1];
			$height = $image[2];

			$params = array(
				'width'   => $width,
				'height'  => $height,
				'quality' => $this->settings['quality'] ?? 85,
				'fit'     => 'cover',
			);

			$image_format = $this->settings['image_format'] ?? 'webp';
			if ( 'original' !== $image_format ) {
				$params['format'] = $image_format;
			}

			$image[0] = $this->build_cdn_url( $r2_key_main, $params );

			return $image;
		}

		// Direct public R2 URL for this derivative (required for media library thumbs when local copy is gone).
		if ( ! empty( $this->settings['r2_public_domain'] ) ) {
			$sized_key = $this->get_r2_key_for_intermediate_size( $attachment_id, $size, $r2_key_main );
			$r2_domain = rtrim( (string) $this->settings['r2_public_domain'], '/' );
			$image[0]  = "{$r2_domain}/{$sized_key}";

			return $image;
		}

		return $image;
	}

	/**
	 * R2 object key for a registered image size (or full).
	 *
	 * @param int          $attachment_id Attachment ID.
	 * @param string|int[] $size          Size name or [w,h].
	 * @param string       $main_key      Stored _cfr2_r2_key (full object).
	 * @return string
	 */
	private function get_r2_key_for_intermediate_size( int $attachment_id, $size, string $main_key ): string {
		if ( 'full' === $size ) {
			return $main_key;
		}

		$meta = wp_get_attachment_metadata( $attachment_id );
		if ( empty( $meta['file'] ) || ! is_string( $meta['file'] ) ) {
			return $main_key;
		}

		$path   = $meta['file'];
		$subdir = dirname( $path );
		if ( '.' === $subdir ) {
			$subdir = '';
		}

		if ( is_string( $size ) && ! empty( $meta['sizes'][ $size ]['file'] ) ) {
			$rel = ( '' !== $subdir ) ? $subdir . '/' . $meta['sizes'][ $size ]['file'] : $meta['sizes'][ $size ]['file'];
			return ExtensibilityHooks::prefix_uploads_directory( $rel );
		}

		if ( is_array( $size ) && isset( $size[0], $size[1] ) ) {
			$w = (int) $size[0];
			$h = (int) $size[1];
			foreach ( $meta['sizes'] ?? array() as $data ) {
				if ( ! is_array( $data ) || empty( $data['file'] ) ) {
					continue;
				}
				if ( (int) ( $data['width'] ?? 0 ) === $w && (int) ( $data['height'] ?? 0 ) === $h ) {
					$rel = ( '' !== $subdir ) ? $subdir . '/' . $data['file'] : $data['file'];
					return ExtensibilityHooks::prefix_uploads_directory( $rel );
				}
			}
		}

		return $main_key;
	}

	/**
	 * Generate responsive srcset with CDN URLs.
	 *
	 * @param array  $sources Srcset sources.
	 * @param array  $size_array Size array.
	 * @param string $image_src Image src.
	 * @param array  $image_meta Image metadata.
	 * @param int    $attachment_id Attachment ID.
	 * @return array Modified sources.
	 */
	public function generate_srcset( $sources, $size_array, $image_src, $image_meta, $attachment_id ): array {
		$is_offloaded = get_post_meta( $attachment_id, MetaKeys::OFFLOADED, true );
		if ( ! $is_offloaded || ! $this->cdn_available ) {
			return $sources;
		}

		$r2_key = get_post_meta( $attachment_id, MetaKeys::R2_KEY, true );
		if ( ! $r2_key ) {
			return $sources;
		}

		// Generate sources for each breakpoint.
		$new_sources    = array();
		$quality        = $this->settings['quality'] ?? 85;
		$original_width = $image_meta['width'] ?? 1920;
		$image_format   = $this->settings['image_format'] ?? 'webp';

		foreach ( self::BREAKPOINTS as $width ) {
			// Skip if larger than original.
			if ( $width > $original_width ) {
				continue;
			}

			$params = array(
				'width'   => $width,
				'quality' => $quality,
			);

			// Only add format if not 'original'.
			if ( 'original' !== $image_format ) {
				$params['format'] = $image_format;
			}

			$new_sources[ $width ] = array(
				'url'        => $this->build_cdn_url( $r2_key, $params ),
				'descriptor' => 'w',
				'value'      => $width,
			);
		}

		// Add original size if not in breakpoints.
		if ( ! isset( $new_sources[ $original_width ] ) ) {
			$params = array(
				'quality' => $quality,
			);

			// Only add format if not 'original'.
			if ( 'original' !== $image_format ) {
				$params['format'] = $image_format;
			}

			$new_sources[ $original_width ] = array(
				'url'        => $this->build_cdn_url( $r2_key, $params ),
				'descriptor' => 'w',
				'value'      => $original_width,
			);
		}

		return $new_sources;
	}

	/**
	 * Add lazy loading attribute.
	 *
	 * @param array        $attr Attributes.
	 * @param \WP_Post     $attachment Attachment post.
	 * @param string|int[] $size Size.
	 * @return array Modified attributes.
	 */
	public function add_lazy_loading( array $attr, \WP_Post $attachment, $size ): array {
		// Add loading="lazy" if not already set.
		if ( ! isset( $attr['loading'] ) ) {
			$attr['loading'] = 'lazy';
		}

		return $attr;
	}

	/**
	 * Wrap img tag with picture element for AVIF/WebP support.
	 *
	 * @param string $filtered_image Full img tag.
	 * @param string $context Context (the_content, etc).
	 * @param int    $attachment_id Attachment ID.
	 * @return string Modified HTML with picture element.
	 */
	public function wrap_with_picture_element( string $filtered_image, string $context, int $attachment_id ): string {
		// Skip if already wrapped in picture element (prevent double-wrapping).
		// We use a more robust check for existing <picture> tags.
		if ( preg_match( '/<picture/i', $filtered_image ) || str_contains( $filtered_image, 'data-cfr2-picture' ) ) {
			return $filtered_image;
		}

		// Skip if not offloaded or CDN not available.
		$is_offloaded = get_post_meta( $attachment_id, MetaKeys::OFFLOADED, true );
		if ( ! $is_offloaded || ! $this->cdn_available ) {
			return $filtered_image;
		}

		$r2_key = get_post_meta( $attachment_id, MetaKeys::R2_KEY, true );
		if ( ! $r2_key ) {
			return $filtered_image;
		}

		// Skip non-image formats.
		if ( ! preg_match( '/\.(jpe?g|png|gif)$/i', $r2_key ) ) {
			return $filtered_image;
		}

		// Get image metadata for original width.
		$image_meta     = wp_get_attachment_metadata( $attachment_id );
		$original_width = $image_meta['width'] ?? 1920;
		$quality        = $this->settings['quality'] ?? 85;
		$image_format   = $this->settings['image_format'] ?? 'webp';

		// If using original format, return without picture element wrapping.
		if ( 'original' === $image_format ) {
			return $filtered_image;
		}

		// Extract or calculate sizes attribute.
		$sizes = $this->get_sizes_attribute( $filtered_image, $original_width );

		// Build picture element with marker to prevent double-wrapping.
		$picture = '<picture data-cfr2-picture="1">';

		// AVIF source (if avif format selected).
		if ( 'avif' === $image_format ) {
			$avif_srcset = $this->build_format_srcset( $r2_key, 'avif', $original_width, $quality );
			if ( $avif_srcset ) {
				$picture .= sprintf(
					'<source type="image/avif" srcset="%s" sizes="%s">',
					esc_attr( $avif_srcset ),
					esc_attr( $sizes )
				);
			}
		}

		// WebP source (for both webp and avif formats - avif falls back to webp).
		$webp_srcset = $this->build_format_srcset( $r2_key, 'webp', $original_width, $quality );
		if ( $webp_srcset ) {
			$picture .= sprintf(
				'<source type="image/webp" srcset="%s" sizes="%s">',
				esc_attr( $webp_srcset ),
				esc_attr( $sizes )
			);
		}

		// Original img tag as fallback.
		$picture .= $filtered_image;
		$picture .= '</picture>';

		return $picture;
	}

	/**
	 * Build srcset for specific format.
	 *
	 * @param string $r2_key R2 object key.
	 * @param string $format Target format (avif, webp).
	 * @param int    $original_width Original image width.
	 * @param int    $quality Image quality.
	 * @return string Srcset string.
	 */
	private function build_format_srcset( string $r2_key, string $format, int $original_width, int $quality ): string {
		$srcset_parts = array();

		foreach ( self::BREAKPOINTS as $width ) {
			if ( $width > $original_width ) {
				continue;
			}

			$url            = $this->build_cdn_url(
				$r2_key,
				array(
					'width'   => $width,
					'quality' => $quality,
					'format'  => $format,
				)
			);
			$srcset_parts[] = "{$url} {$width}w";
		}

		// Add original size.
		if ( ! in_array( $original_width, self::BREAKPOINTS, true ) ) {
			$url            = $this->build_cdn_url(
				$r2_key,
				array(
					'quality' => $quality,
					'format'  => $format,
				)
			);
			$srcset_parts[] = "{$url} {$original_width}w";
		}

		return implode( ', ', $srcset_parts );
	}

	/**
	 * Get optimal sizes attribute.
	 *
	 * @param string $filtered_image Original img tag.
	 * @param int    $original_width Original image width.
	 * @return string Sizes attribute value.
	 */
	private function get_sizes_attribute( string $filtered_image, int $original_width ): string {
		// Extract existing sizes from img tag.
		$existing_sizes = '100vw';
		if ( preg_match( '/sizes=["\']([^"\']+)["\']/', $filtered_image, $matches ) ) {
			$existing_sizes = $matches[1];
		}

		// Return existing if smart sizes disabled.
		if ( empty( $this->settings['smart_sizes'] ) ) {
			return $existing_sizes;
		}

		// Get content max width from settings.
		$content_max_width = absint( $this->settings['content_max_width'] ?? 800 );

		// Calculate smart sizes based on content width.
		// Mobile: 100vw (full width).
		// Tablet: min(100vw, content_max_width).
		// Desktop: content_max_width (capped).
		$sizes_parts = array();

		// Mobile breakpoint (up to 640px viewport).
		$sizes_parts[] = '(max-width: 640px) 100vw';

		// Tablet breakpoint (641px to 1024px).
		if ( $content_max_width < 1024 ) {
			$sizes_parts[] = "(max-width: 1024px) min(100vw, {$content_max_width}px)";
		} else {
			$sizes_parts[] = '(max-width: 1024px) 100vw';
		}

		// Desktop: use content max width or original image width, whichever is smaller.
		$desktop_size  = min( $content_max_width, $original_width );
		$sizes_parts[] = "{$desktop_size}px";

		return implode( ', ', $sizes_parts );
	}

	/**
	 * Build CDN URL with transformation params.
	 *
	 * @param string $r2_key R2 object key.
	 * @param array  $params Transform params.
	 * @return string CDN URL.
	 */
	private function build_cdn_url( string $r2_key, array $params = array() ): string {
		$cdn_url = rtrim( $this->settings['cdn_url'], '/' );
		$url     = "{$cdn_url}/{$r2_key}";

		if ( ! empty( $params ) ) {
			$url .= '?' . http_build_query( $params );
		}

		return $url;
	}

	/**
	 * Check if CDN is available (cached check).
	 *
	 * @return bool True if available.
	 */
	private function check_cdn_availability(): bool {
		// Skip check if not configured.
		if ( empty( $this->settings['cdn_url'] ) ) {
			return false;
		}

		return self::is_cdn_url_available( (string) $this->settings['cdn_url'] );
	}

	/**
	 * Check whether a CDN URL is responding with this plugin's Worker health endpoint.
	 *
	 * @param string $cdn_url CDN URL.
	 * @return bool
	 */
	public static function is_cdn_url_available( string $cdn_url ): bool {
		$cdn_url = rtrim( $cdn_url, '/' );
		if ( '' === $cdn_url ) {
			return false;
		}

		// Check cache.
		$cache_key = self::get_availability_cache_key( $cdn_url );
		$cached    = get_transient( $cache_key );

		if ( false !== $cached ) {
			return 'yes' === $cached;
		}

		// Perform health check.
		$test_url = $cdn_url . '/health';
		$response = wp_remote_get(
			$test_url,
			array(
				'timeout'             => 5,
				'sslverify'           => true,
				'limit_response_size' => 2048,
			)
		);

		$response_code = ! is_wp_error( $response ) ? wp_remote_retrieve_response_code( $response ) : 0;
		$health_header = ! is_wp_error( $response ) ? (string) wp_remote_retrieve_header( $response, 'x-cfr2-health' ) : '';
		$body          = ! is_wp_error( $response ) ? strtolower( trim( wp_remote_retrieve_body( $response ) ) ) : '';
		$is_available  = $response_code >= 200 && $response_code < 400 && ( 'ok' === strtolower( $health_header ) || 'ok' === $body );

		// Cache for 15 minutes to reduce latency on page loads.
		set_transient( $cache_key, $is_available ? 'yes' : 'no', 900 );

		return $is_available;
	}

	/**
	 * Force CDN availability check (clear cache).
	 *
	 * @param string $cdn_url Optional CDN URL whose cache should be purged.
	 */
	public static function clear_availability_cache( string $cdn_url = '' ): void {
		delete_transient( 'cfr2_cdn_available' );

		if ( '' === $cdn_url ) {
			$settings = PluginSettings::get();
			$cdn_url  = (string) ( $settings['cdn_url'] ?? '' );
		}

		if ( '' !== $cdn_url ) {
			delete_transient( self::get_availability_cache_key( $cdn_url ) );
		}
	}

	/**
	 * Invalidate cache for a specific attachment.
	 *
	 * @param int   $attachment_id Attachment ID.
	 * @param array $metadata      Optional attachment metadata.
	 */
	public function invalidate_attachment_cache( int $attachment_id, array $metadata = array() ): void {
		// Clear WordPress object cache for this attachment.
		clean_post_cache( $attachment_id );

		// If CDN is enabled, clear CDN availability cache to force recheck.
		if ( ! empty( $this->settings['cdn_enabled'] ) && ! empty( $this->settings['cdn_url'] ) ) {
			$cdn_url = (string) $this->settings['cdn_url'];
			delete_transient( self::get_availability_cache_key( $cdn_url ) );
		}

		// Clear any transients related to this attachment.
		delete_transient( 'cfr2_attachment_' . $attachment_id . '_transformed' );
	}

	/**
	 * Get cache key for CDN availability.
	 *
	 * @param string $cdn_url CDN URL.
	 * @return string
	 */
	private static function get_availability_cache_key( string $cdn_url ): string {
		return 'cfr2_cdn_available_' . md5( rtrim( $cdn_url, '/' ) );
	}
}
