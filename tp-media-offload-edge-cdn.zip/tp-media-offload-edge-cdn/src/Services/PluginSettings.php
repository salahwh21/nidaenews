<?php
/**
 * Plugin Settings Service class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Services;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Constants\BatchConfig;
use Salahdev\NidaEdge\Constants\Settings;

/**
 * PluginSettings class - canonical settings schema and normalization.
 */
class PluginSettings {

	/**
	 * Get canonical settings defaults.
	 *
	 * @return array<string, mixed>
	 */
	public static function defaults(): array {
		return array(
			'r2_account_id'        => '',
			'r2_region'            => 'auto',
			'r2_endpoint'          => '',
			'r2_access_key_id'     => '',
			'r2_secret_access_key' => '',
			'r2_bucket'            => '',
			'r2_public_domain'     => '',
			'auto_offload'         => 0,
			'wp_handle_upload_offload' => 1,
			'batch_size'           => BatchConfig::DEFAULT_SIZE,
			'keep_local_files'     => 1,
			'sync_delete'          => 0,
			'cdn_enabled'          => 0,
			'local_fallback_enabled' => 0,
			'cdn_url'              => '',
			'quality'              => 85,
			'image_format'         => 'webp',
			'smart_sizes'          => 0,
			'content_max_width'    => 800,
			'cf_api_token'         => '',
			'worker_deployed'        => false,
			'worker_name'            => '',
			'worker_deployed_at'     => '',
			'rest_public_attachment' => 0,
			'allow_svg_offload'      => 1,
		);
	}

	/**
	 * Create settings option if missing.
	 *
	 * @return array<string, mixed>
	 */
	/**
	 * Get normalized settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function get(): array {
		return self::normalize( self::get_raw() );
	}

	/**
	 * Normalize and persist saved settings when needed.
	 *
	 * @return array<string, mixed>
	 */
	public static function migrate_if_needed(): array {
		if ( self::has_wp_config_settings() ) {
			return self::get();
		}

		if ( false === get_option( Settings::OPTION_KEY, false ) ) {
			return self::initialize();
		}

		$raw        = self::get_raw();
		$normalized = self::normalize( $raw );

		if ( $normalized !== $raw ) {
			update_option( Settings::OPTION_KEY, $normalized );
		}

		return $normalized;
	}

	/**
	 * Get raw option value as array.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_raw(): array {
		$settings = get_option( Settings::OPTION_KEY, array() );
		$settings = is_array( $settings ) ? $settings : array();
		$config   = self::get_wp_config_settings();

		// Only use wp-config settings if database settings are empty.
		// This allows users to override wp-config settings through the UI.
		if ( ! empty( $config ) && empty( $settings ) ) {
			return wp_parse_args( $config, self::defaults() );
		}

		return ! empty( $settings ) ? $settings : self::defaults();
	}

	/**
	 * Check if wp-config.php provided settings are active.
	 *
	 * @return bool True when ACOOFM_SETTINGS is present and valid.
	 */
	public static function has_wp_config_settings(): bool {
		return ! empty( self::get_wp_config_settings() );
	}

	/**
	 * Check if a specific canonical setting was supplied through wp-config.php.
	 *
	 * @param string $key Canonical setting key.
	 * @return bool
	 */
	public static function has_wp_config_setting( string $key ): bool {
		return array_key_exists( $key, self::get_wp_config_settings() );
	}

	/**
	 * Get settings supplied through wp-config.php.
	 *
	 * Supports:
	 * define( 'ACOOFM_SETTINGS', serialize( array( ... ) ) );
	 *
	 * @return array<string, mixed>
	 */
	private static function get_wp_config_settings(): array {
		if ( ! defined( 'ACOOFM_SETTINGS' ) ) {
			return array();
		}

		$config = ACOOFM_SETTINGS;

		if ( is_string( $config ) ) {
			$maybe_unserialized = maybe_unserialize( $config );
			$config             = is_array( $maybe_unserialized ) ? $maybe_unserialized : array();
		}

		if ( ! is_array( $config ) ) {
			return array();
		}

		return self::apply_wp_config_aliases( $config );
	}

	/**
	 * Normalize settings against canonical defaults and remove stale keys.
	 *
	 * @param array<string, mixed> $settings Raw settings.
	 * @return array<string, mixed>
	 */
	public static function normalize( array $settings ): array {
		$defaults = self::defaults();
		$legacy   = self::apply_legacy_aliases( $settings );
		$merged   = wp_parse_args( $legacy, $defaults );

		return array(
			'r2_account_id'        => sanitize_text_field( (string) $merged['r2_account_id'] ),
			'r2_region'            => self::normalize_region( (string) $merged['r2_region'] ),
			'r2_endpoint'          => self::normalize_url( (string) $merged['r2_endpoint'] ),
			'r2_access_key_id'     => sanitize_text_field( (string) $merged['r2_access_key_id'] ),
			'r2_secret_access_key' => (string) $merged['r2_secret_access_key'],
			'r2_bucket'            => sanitize_text_field( strtolower( (string) $merged['r2_bucket'] ) ),
			'r2_public_domain'     => self::normalize_url( (string) $merged['r2_public_domain'] ),
			'auto_offload'         => ! empty( $merged['auto_offload'] ) ? 1 : 0,
			'wp_handle_upload_offload' => ! empty( $merged['wp_handle_upload_offload'] ) ? 1 : 0,
			'batch_size'           => max( BatchConfig::MIN_SIZE, min( absint( $merged['batch_size'] ), BatchConfig::MAX_SIZE ) ),
			'keep_local_files'     => ! empty( $merged['keep_local_files'] ) ? 1 : 0,
			'sync_delete'          => ! empty( $merged['sync_delete'] ) ? 1 : 0,
			'cdn_enabled'          => ! empty( $merged['cdn_enabled'] ) ? 1 : 0,
			'local_fallback_enabled' => ! empty( $merged['local_fallback_enabled'] ) ? 1 : 0,
			'cdn_url'              => self::normalize_url( (string) $merged['cdn_url'] ),
			'quality'              => max( 1, min( absint( $merged['quality'] ), 100 ) ),
			'image_format'         => self::normalize_image_format( (string) $merged['image_format'] ),
			'smart_sizes'          => ! empty( $merged['smart_sizes'] ) ? 1 : 0,
			'content_max_width'    => max( 320, min( absint( $merged['content_max_width'] ), 1920 ) ),
			'cf_api_token'         => (string) $merged['cf_api_token'],
			'worker_deployed'        => ! empty( $merged['worker_deployed'] ),
			'worker_name'            => sanitize_text_field( (string) $merged['worker_name'] ),
			'worker_deployed_at'     => sanitize_text_field( (string) $merged['worker_deployed_at'] ),
			'rest_public_attachment' => ! empty( $merged['rest_public_attachment'] ) ? 1 : 0,
			'allow_svg_offload'      => ! empty( $merged['allow_svg_offload'] ) ? 1 : 0,
		);
	}

	/**
	 * Apply safe legacy aliases before canonical normalization.
	 *
	 * @param array<string, mixed> $settings Raw settings.
	 * @return array<string, mixed>
	 */
	private static function apply_legacy_aliases( array $settings ): array {
		if ( empty( $settings['cf_api_token'] ) && ! empty( $settings['api_key'] ) ) {
			$settings['cf_api_token'] = $settings['api_key'];
		}

		return $settings;
	}

	/**
	 * Normalize common wp-config.php aliases into the plugin schema.
	 *
	 * @param array<string, mixed> $settings Raw wp-config settings.
	 * @return array<string, mixed>
	 */
	private static function apply_wp_config_aliases( array $settings ): array {
		$aliases = array(
			'account_id'        => 'r2_account_id',
			'region'            => 'r2_region',
			'endpoint'          => 'r2_endpoint',
			'r2_endpoint_url'   => 'r2_endpoint',
			'access_key_id'     => 'r2_access_key_id',
			'secret_access_key' => 'r2_secret_access_key',
			'bucket'            => 'r2_bucket',
			'public_domain'     => 'r2_public_domain',
			'cdn_domain'        => 'cdn_url',
			'cloudflare_token'  => 'cf_api_token',
			'api_token'         => 'cf_api_token',
		);

		foreach ( $aliases as $alias => $canonical ) {
			if ( empty( $settings[ $canonical ] ) && isset( $settings[ $alias ] ) ) {
				$settings[ $canonical ] = $settings[ $alias ];
			}
		}

		// Preserve the user's CDN enable state.
		// Do not automatically treat the R2 public domain as a CDN route.

		return $settings;
	}

	/**
	 * Normalize URL-like settings.
	 *
	 * @param string $url Raw URL.
	 * @return string
	 */
	private static function normalize_url( string $url ): string {
		$url = trim( $url );
		if ( '' !== $url && ! preg_match( '#^https?://#i', $url ) ) {
			$url = 'https://' . $url;
		}

		return rtrim( esc_url_raw( $url ), '/' );
	}

	/**
	 * Normalize R2/S3 region, defaulting to Cloudflare's auto region.
	 *
	 * @param string $region Raw region.
	 * @return string
	 */
	private static function normalize_region( string $region ): string {
		$region = strtolower( sanitize_text_field( trim( $region ) ) );

		return '' !== $region ? $region : 'auto';
	}

	/**
	 * Normalize image format into supported set.
	 *
	 * @param string $format Raw image format.
	 * @return string
	 */
	private static function normalize_image_format( string $format ): string {
		$allowed_formats = array( 'original', 'webp', 'avif' );
		$format          = sanitize_text_field( $format );

		return in_array( $format, $allowed_formats, true ) ? $format : 'webp';
	}
}
