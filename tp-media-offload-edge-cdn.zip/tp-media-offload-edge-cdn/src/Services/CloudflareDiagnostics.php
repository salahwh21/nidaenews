<?php
/**
 * Cloudflare diagnostics service.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Services;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Constants\MetaKeys;
use Salahdev\NidaEdge\Traits\CredentialsHelperTrait;

/**
 * Runs safe read-only checks to identify the real Cloudflare/CDN blocker.
 */
class CloudflareDiagnostics {

	use CredentialsHelperTrait;

	/**
	 * Plugin settings.
	 *
	 * @var array<string, mixed>
	 */
	private array $settings;

	/**
	 * Diagnostic steps.
	 *
	 * @var array<int, array<string, mixed>>
	 */
	private array $steps = array();

	/**
	 * Constructor.
	 *
	 * @param array<string, mixed>|null $settings Settings override.
	 */
	public function __construct( ?array $settings = null ) {
		$this->settings = $settings ?? PluginSettings::get();
	}

	/**
	 * Run all diagnostics.
	 *
	 * @return array<string, mixed>
	 */
	public function run(): array {
		$credentials = self::get_r2_credentials( $this->settings );
		$api_token   = self::get_cf_api_token( $this->settings );
		$account_id  = (string) ( $this->settings['r2_account_id'] ?? '' );
		$bucket      = (string) ( $this->settings['r2_bucket'] ?? '' );
		$cdn_url     = (string) ( $this->settings['cdn_url'] ?? '' );
		$cdn_host    = $this->get_host_from_url( $cdn_url );

		$this->check_local_settings( $credentials, $api_token, $account_id, $bucket, $cdn_url, $cdn_host );

		if ( '' === $api_token || '' === $account_id ) {
			return $this->result();
		}

		$api = new CloudflareAPI( $api_token, $account_id );

		if ( ! $this->check_cloudflare_token( $api ) ) {
			return $this->result();
		}

		$this->check_r2_bucket( $credentials );

		$zone_id = '';
		if ( '' !== $cdn_host ) {
			$zone_id = $this->check_zone_and_dns( $api, $cdn_host );
		}

		$cdn_health_ok = false;
		if ( '' !== $cdn_host ) {
			$cdn_health_ok = $this->check_cdn_health( $cdn_url );
			$this->check_sample_transform( $cdn_url );
		}
		$this->check_worker_status( $api, $cdn_health_ok );

		return $this->result(
			array(
				'cdn_host' => $cdn_host,
				'zone_id'  => $zone_id,
			)
		);
	}

	/**
	 * Check local settings before remote API calls.
	 *
	 * @param array<string, mixed> $credentials R2 credentials.
	 * @param string               $api_token   Cloudflare API token.
	 * @param string               $account_id  Account ID.
	 * @param string               $bucket      Bucket name.
	 * @param string               $cdn_url     CDN URL.
	 * @param string               $cdn_host    CDN hostname.
	 */
	private function check_local_settings(
		array $credentials,
		string $api_token,
		string $account_id,
		string $bucket,
		string $cdn_url,
		string $cdn_host
	): void {
		if ( '' === $api_token ) {
			$raw_settings      = PluginSettings::get_raw();
			$stored_has_value = '' !== trim( (string) ( $raw_settings['cf_api_token'] ?? '' ) ) || CloudflareToken::has_standalone_value();
			$this->add_step(
				'token_local',
				'error',
				$stored_has_value
					? __( 'A Cloudflare API token value exists in the database, but the plugin cannot decrypt or recognize it.', 'tp-media-offload-edge-cdn' )
					: __( 'Cloudflare API token is not saved in the plugin settings.', 'tp-media-offload-edge-cdn' ),
				__( 'Plugin settings', 'tp-media-offload-edge-cdn' ),
				$stored_has_value
					? __( 'Use Reset Tools, paste the token again, and save. If it still fails, put cf_api_token in ACOOFM_SETTINGS inside wp-config.php.', 'tp-media-offload-edge-cdn' )
					: __( 'Paste the token and click Save Settings before running diagnostics or deploying the Worker.', 'tp-media-offload-edge-cdn' )
			);
		} else {
			$this->add_step(
				'token_local',
				'ok',
				__( 'Cloudflare API token is saved and readable locally.', 'tp-media-offload-edge-cdn' ),
				__( 'Plugin settings', 'tp-media-offload-edge-cdn' )
			);
		}

		if ( '' === $account_id ) {
			$this->add_step(
				'account_id',
				'error',
				__( 'Cloudflare Account ID is missing.', 'tp-media-offload-edge-cdn' ),
				__( 'Plugin settings', 'tp-media-offload-edge-cdn' )
			);
		}

		if ( '' === $bucket ) {
			$this->add_step(
				'bucket',
				'error',
				__( 'R2 bucket name is missing.', 'tp-media-offload-edge-cdn' ),
				__( 'Plugin settings', 'tp-media-offload-edge-cdn' )
			);
		}

		$r2_error = SettingsValidator::validate_r2_credentials( $credentials );
		if ( null !== $r2_error ) {
			$this->add_step(
				'r2_settings',
				'error',
				$r2_error,
				__( 'Plugin settings', 'tp-media-offload-edge-cdn' )
			);
		} else {
			$this->add_step(
				'r2_settings',
				'ok',
				__( 'R2 credentials are complete locally.', 'tp-media-offload-edge-cdn' ),
				__( 'Plugin settings', 'tp-media-offload-edge-cdn' )
			);
		}

		if ( '' === $cdn_url || '' === $cdn_host ) {
			$this->add_step(
				'cdn_url',
				'warning',
				__( 'CDN URL is missing or invalid, so Worker route checks cannot run.', 'tp-media-offload-edge-cdn' ),
				__( 'Plugin settings', 'tp-media-offload-edge-cdn' )
			);
		} else {
			$this->add_step(
				'cdn_url',
				'ok',
				sprintf(
					/* translators: %s: CDN hostname */
					__( 'CDN hostname parsed successfully: %s', 'tp-media-offload-edge-cdn' ),
					$cdn_host
				),
				__( 'Plugin settings', 'tp-media-offload-edge-cdn' )
			);
		}
	}

	/**
	 * Verify Cloudflare token.
	 *
	 * @param CloudflareAPI $api API client.
	 * @return bool
	 */
	private function check_cloudflare_token( CloudflareAPI $api ): bool {
		$verify = $api->verify_token();

		if ( ! empty( $verify['success'] ) ) {
			$status = $verify['result']['status'] ?? 'active';
			$this->add_step(
				'cf_token_verify',
				'ok',
				sprintf(
					/* translators: %s: token status */
					__( 'Cloudflare accepted the API token. Status: %s', 'tp-media-offload-edge-cdn' ),
					$status
				),
				__( 'Cloudflare API', 'tp-media-offload-edge-cdn' )
			);
			return true;
		}

		$message = $this->first_api_error( $verify );
		$this->add_step(
			'cf_token_verify',
			'error',
			sprintf(
				/* translators: %s: Cloudflare error */
				__( 'Cloudflare token verification failed: %s', 'tp-media-offload-edge-cdn' ),
				$message
			),
			$this->classify_remote_source( $message ),
			__( 'This is the first remote blocker. Confirm the token is raw, active, and not restricted to another IP/account.', 'tp-media-offload-edge-cdn' )
		);

		return false;
	}

	/**
	 * Test R2 bucket connection.
	 *
	 * @param array<string, mixed> $credentials R2 credentials.
	 */
	private function check_r2_bucket( array $credentials ): void {
		$error_message = SettingsValidator::validate_r2_credentials( $credentials );
		if ( null !== $error_message ) {
			return;
		}

		$r2     = new R2Client( $credentials );
		$result = $r2->test_connection();

		if ( ! empty( $result['success'] ) ) {
			$this->add_step(
				'r2_bucket_access',
				'ok',
				__( 'R2 bucket access succeeded.', 'tp-media-offload-edge-cdn' ),
				__( 'Cloudflare R2', 'tp-media-offload-edge-cdn' )
			);
			return;
		}

		$this->add_step(
			'r2_bucket_access',
			'error',
			(string) ( $result['message'] ?? __( 'R2 bucket access failed.', 'tp-media-offload-edge-cdn' ) ),
			__( 'Cloudflare R2', 'tp-media-offload-edge-cdn' ),
			__( 'Check the R2 Access Key, Secret Key, bucket name, endpoint, and bucket-scoped permissions.', 'tp-media-offload-edge-cdn' )
		);
	}

	/**
	 * Check zone and DNS record without creating records.
	 *
	 * @param CloudflareAPI $api      API client.
	 * @param string        $cdn_host CDN hostname.
	 * @return string Zone ID or empty string.
	 */
	private function check_zone_and_dns( CloudflareAPI $api, string $cdn_host ): string {
		$zone_id = $api->get_zone_id_for_host( $cdn_host );

		if ( ! $zone_id ) {
			$error = $api->get_last_error();
			$this->add_step(
				'zone_lookup',
				'error',
				'' !== $error
					? sprintf(
						/* translators: %s: Cloudflare API error */
						__( 'Could not read Cloudflare zones: %s', 'tp-media-offload-edge-cdn' ),
						$error
					)
					: sprintf(
						/* translators: %s: CDN hostname */
						__( 'No Cloudflare zone was found for %s.', 'tp-media-offload-edge-cdn' ),
						$cdn_host
					),
				__( 'Cloudflare Zone/DNS', 'tp-media-offload-edge-cdn' ),
				__( 'Make sure the root domain is in this Cloudflare account and the token has Zone Read permission.', 'tp-media-offload-edge-cdn' )
			);
			return '';
		}

		$this->add_step(
			'zone_lookup',
			'ok',
			sprintf(
				/* translators: %s: CDN hostname */
				__( 'Cloudflare zone found for %s.', 'tp-media-offload-edge-cdn' ),
				$cdn_host
			),
			__( 'Cloudflare Zone/DNS', 'tp-media-offload-edge-cdn' )
		);

		$record = $api->get_dns_record( $zone_id, $cdn_host, 'CNAME' );
		if ( ! $record ) {
			$record = $api->get_dns_record( $zone_id, $cdn_host, 'A' );
		}
		if ( ! $record ) {
			$record = $api->get_dns_record( $zone_id, $cdn_host, 'AAAA' );
		}

		if ( ! $record ) {
			$this->add_step(
				'dns_record',
				'warning',
				__( 'No DNS record exists for the CDN hostname yet.', 'tp-media-offload-edge-cdn' ),
				__( 'Cloudflare Zone/DNS', 'tp-media-offload-edge-cdn' ),
				__( 'Use Validate DNS or Deploy Worker to create a proxied record automatically.', 'tp-media-offload-edge-cdn' )
			);
			return $zone_id;
		}

		if ( empty( $record['proxied'] ) ) {
			$this->add_step(
				'dns_record',
				'error',
				__( 'DNS record exists but Cloudflare proxy is disabled.', 'tp-media-offload-edge-cdn' ),
				__( 'Cloudflare Zone/DNS', 'tp-media-offload-edge-cdn' ),
				__( 'Enable the orange cloud proxy. Worker routes do not run on DNS-only records.', 'tp-media-offload-edge-cdn' )
			);
			return $zone_id;
		}

		$this->add_step(
			'dns_record',
			'ok',
			__( 'DNS record exists and Cloudflare proxy is enabled.', 'tp-media-offload-edge-cdn' ),
			__( 'Cloudflare Zone/DNS', 'tp-media-offload-edge-cdn' )
		);

		return $zone_id;
	}

	/**
	 * Check Worker script status.
	 *
	 * @param CloudflareAPI $api           API client.
	 * @param bool          $cdn_health_ok Whether the Worker health route responded correctly.
	 */
	private function check_worker_status( CloudflareAPI $api, bool $cdn_health_ok = false ): void {
		$deployer = new WorkerDeployer( $api );
		$status   = $deployer->get_status();

		if ( ! empty( $status['success'] ) ) {
			$this->add_step(
				'worker_status',
				'ok',
				__( 'Worker script exists in Cloudflare.', 'tp-media-offload-edge-cdn' ),
				__( 'Cloudflare Workers', 'tp-media-offload-edge-cdn' )
			);
			return;
		}

		$message = $this->first_api_error( $status );
		if ( $cdn_health_ok ) {
			$this->add_step(
				'worker_status',
				'ok',
				sprintf(
					/* translators: %s: status message */
					__( 'Worker route is responding; Cloudflare API status check was inconclusive: %s', 'tp-media-offload-edge-cdn' ),
					$message
				),
				__( 'Worker runtime', 'tp-media-offload-edge-cdn' )
			);
			return;
		}

		$this->add_step(
			'worker_status',
			'warning',
			sprintf(
				/* translators: %s: status message */
				__( 'Worker is not confirmed as deployed: %s', 'tp-media-offload-edge-cdn' ),
				$message
			),
			__( 'Cloudflare Workers', 'tp-media-offload-edge-cdn' ),
			__( 'This is expected before the first successful Deploy Worker action.', 'tp-media-offload-edge-cdn' )
		);
	}

	/**
	 * Check CDN health endpoint.
	 *
	 * @param string $cdn_url CDN URL.
	 * @return bool True when health endpoint responded with ok.
	 */
	private function check_cdn_health( string $cdn_url ): bool {
		if ( '' === $cdn_url ) {
			return false;
		}

		$url      = rtrim( $cdn_url, '/' ) . '/health';
		$response = wp_remote_get(
			$url,
			array(
				'timeout'             => 15,
				'redirection'         => 2,
				'limit_response_size' => 4096,
			)
		);

		if ( is_wp_error( $response ) ) {
			$this->add_step(
				'cdn_health',
				'error',
				sprintf(
					/* translators: %s: network error */
					__( 'CDN health check could not connect: %s', 'tp-media-offload-edge-cdn' ),
					$response->get_error_message()
				),
				__( 'Server network/DNS', 'tp-media-offload-edge-cdn' ),
				__( 'The WordPress server could not reach the CDN URL. Check DNS propagation, SSL, or outbound HTTPS access.', 'tp-media-offload-edge-cdn' )
			);
			return false;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = trim( wp_remote_retrieve_body( $response ) );

		if ( 200 === $code && 'ok' === strtolower( $body ) ) {
			$this->add_step(
				'cdn_health',
				'ok',
				__( 'CDN health endpoint responded correctly.', 'tp-media-offload-edge-cdn' ),
				__( 'Worker runtime', 'tp-media-offload-edge-cdn' )
			);
			return true;
		}

		$this->add_step(
			'cdn_health',
			'error',
			sprintf(
				/* translators: %d: HTTP status */
				__( 'CDN health endpoint returned HTTP %d instead of 200.', 'tp-media-offload-edge-cdn' ),
				(int) $code
			),
			__( 'Worker route/CDN', 'tp-media-offload-edge-cdn' ),
			__( 'The Worker route is not active yet, DNS is not proxied, or the Worker is returning an error.', 'tp-media-offload-edge-cdn' )
		);
		return false;
	}

	/**
	 * Check a real transformed image when an offloaded attachment exists.
	 *
	 * @param string $cdn_url CDN URL.
	 */
	private function check_sample_transform( string $cdn_url ): void {
		if ( '' === $cdn_url ) {
			return;
		}

		$r2_key = $this->get_sample_r2_key();
		if ( '' === $r2_key ) {
			$this->add_step(
				'sample_transform',
				'warning',
				__( 'No offloaded media item was found for a live image transformation test.', 'tp-media-offload-edge-cdn' ),
				__( 'WordPress media', 'tp-media-offload-edge-cdn' ),
				__( 'Upload a new image or run bulk offload, then run diagnostics again.', 'tp-media-offload-edge-cdn' )
			);
			return;
		}

		$url      = rtrim( $cdn_url, '/' ) . '/' . ltrim( $r2_key, '/' ) . '?format=webp&quality=75';
		$response = wp_remote_get(
			$url,
			array(
				'timeout'             => 20,
				'redirection'         => 2,
				'limit_response_size' => 65536,
			)
		);

		if ( is_wp_error( $response ) ) {
			$this->add_step(
				'sample_transform',
				'error',
				sprintf(
					/* translators: %s: network error */
					__( 'Sample image request failed: %s', 'tp-media-offload-edge-cdn' ),
					$response->get_error_message()
				),
				__( 'Worker runtime', 'tp-media-offload-edge-cdn' )
			);
			return;
		}

		$code                = wp_remote_retrieve_response_code( $response );
		$content_type_header = wp_remote_retrieve_header( $response, 'content-type' );
		$content_type        = is_array( $content_type_header ) ? implode( ', ', $content_type_header ) : (string) $content_type_header;
		$transform_header    = (string) wp_remote_retrieve_header( $response, 'x-cfr2-transform' );
		$transform_error     = (string) wp_remote_retrieve_header( $response, 'x-cfr2-transform-error' );

		if ( 200 === $code && 'fallback' === strtolower( $transform_header ) ) {
			$this->add_step(
				'sample_transform',
				'error',
				sprintf(
					/* translators: %s: Worker transform error */
					__( 'Worker served the original image because transformation failed: %s', 'tp-media-offload-edge-cdn' ),
					'' !== $transform_error ? $transform_error : __( 'Unknown error', 'tp-media-offload-edge-cdn' )
				),
				__( 'Worker image optimization', 'tp-media-offload-edge-cdn' ),
				__( 'Check that Cloudflare Image Transformations is available for this zone and that the Worker was redeployed after changing the plugin version.', 'tp-media-offload-edge-cdn' )
			);
			return;
		}

		if ( 200 === $code && false !== stripos( $content_type, 'image/' ) ) {
			$this->add_step(
				'sample_transform',
				false !== stripos( $content_type, 'image/webp' ) ? 'ok' : 'warning',
				sprintf(
					/* translators: %s: response content type */
					__( 'Sample image responded with Content-Type: %s', 'tp-media-offload-edge-cdn' ),
					$content_type
				),
				__( 'Worker image optimization', 'tp-media-offload-edge-cdn' ),
				false !== stripos( $content_type, 'image/webp' )
					? ''
					: __( 'The image is reachable, but WebP conversion was not confirmed. If this persists, the Worker transform path needs adjustment.', 'tp-media-offload-edge-cdn' )
			);
			return;
		}

		$this->add_step(
			'sample_transform',
			'error',
			sprintf(
				/* translators: %d: HTTP status */
				__( 'Sample image returned HTTP %d.', 'tp-media-offload-edge-cdn' ),
				(int) $code
			),
			__( 'Worker/R2 delivery', 'tp-media-offload-edge-cdn' ),
			__( 'The Worker route is active but could not serve this R2 object. Check the R2 binding and object key.', 'tp-media-offload-edge-cdn' )
		);
	}

	/**
	 * Get one offloaded R2 key for live diagnostics.
	 *
	 * @return string
	 */
	private function get_sample_r2_key(): string {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Read-only diagnostics.
		$key = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT r2.meta_value
				FROM {$wpdb->postmeta} r2
				INNER JOIN {$wpdb->postmeta} offloaded
					ON offloaded.post_id = r2.post_id
					AND offloaded.meta_key = %s
					AND offloaded.meta_value = '1'
				WHERE r2.meta_key = %s
					AND r2.meta_value <> ''
				LIMIT 1",
				MetaKeys::OFFLOADED,
				MetaKeys::R2_KEY
			)
		);

		return is_string( $key ) ? $key : '';
	}

	/**
	 * Add a diagnostic step.
	 *
	 * @param string $id      Step ID.
	 * @param string $status  ok|warning|error.
	 * @param string $message Message.
	 * @param string $source  Source label.
	 * @param string $advice  Optional advice.
	 */
	private function add_step( string $id, string $status, string $message, string $source, string $advice = '' ): void {
		$this->steps[] = array(
			'id'      => $id,
			'status'  => $status,
			'message' => $message,
			'source'  => $source,
			'advice'  => $advice,
		);
	}

	/**
	 * Build final result.
	 *
	 * @param array<string, mixed> $extra Extra data.
	 * @return array<string, mixed>
	 */
	private function result( array $extra = array() ): array {
		$primary = null;
		foreach ( $this->steps as $step ) {
			if ( 'error' === $step['status'] ) {
				$primary = $step;
				break;
			}
		}

		if ( null === $primary ) {
			foreach ( $this->steps as $step ) {
				if ( 'warning' === $step['status'] ) {
					$primary = $step;
					break;
				}
			}
		}

		return array_merge(
			array(
				'success'         => null === $primary || 'error' !== $primary['status'],
				'primary_blocker' => $primary,
				'steps'           => $this->steps,
			),
			$extra
		);
	}

	/**
	 * Get hostname from URL.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	private function get_host_from_url( string $url ): string {
		$parts = wp_parse_url( $url );

		return ! empty( $parts['host'] ) ? strtolower( (string) $parts['host'] ) : '';
	}

	/**
	 * Get first Cloudflare API error message.
	 *
	 * @param array<string, mixed> $response API response.
	 * @return string
	 */
	private function first_api_error( array $response ): string {
		return (string) ( $response['errors'][0]['message'] ?? __( 'Unknown Cloudflare API error', 'tp-media-offload-edge-cdn' ) );
	}

	/**
	 * Classify remote error source.
	 *
	 * @param string $message Error message.
	 * @return string
	 */
	private function classify_remote_source( string $message ): string {
		$lower = strtolower( $message );
		if (
			false !== strpos( $lower, 'could not resolve' )
			|| false !== strpos( $lower, 'timed out' )
			|| false !== strpos( $lower, 'ssl' )
			|| false !== strpos( $lower, 'curl' )
		) {
			return __( 'Server network', 'tp-media-offload-edge-cdn' );
		}

		if ( false !== strpos( $lower, 'authorization' ) || false !== strpos( $lower, 'token' ) || false !== strpos( $lower, 'headers' ) ) {
			return __( 'Cloudflare authentication', 'tp-media-offload-edge-cdn' );
		}

		return __( 'Cloudflare API', 'tp-media-offload-edge-cdn' );
	}
}
