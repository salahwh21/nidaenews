<?php
/**
 * Media Upload Hooks class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Hooks;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Constants\MetaKeys;
use Salahdev\NidaEdge\Constants\TransientKeys;
use Salahdev\NidaEdge\Interfaces\HookableInterface;
use Salahdev\NidaEdge\Services\BulkOperationLogger;
use Salahdev\NidaEdge\Services\OffloadService;
use Salahdev\NidaEdge\Services\PluginSettings;
use Salahdev\NidaEdge\Services\R2Client;
use Salahdev\NidaEdge\Services\QueueProcessor;
use Salahdev\NidaEdge\Services\SettingsValidator;
use Salahdev\NidaEdge\Traits\CredentialsHelperTrait;

/**
 * MediaUploadHooks class - handles media upload and deletion hooks.
 */
class MediaUploadHooks implements HookableInterface {

	use CredentialsHelperTrait;

	/**
	 * Register hooks.
	 */
	public function register_hooks(): void {
		// Only register auto-offload hook if enabled (avoid overhead when disabled).
		$settings = PluginSettings::get();
		if ( ! empty( $settings['auto_offload'] ) ) {
			if ( ! empty( $settings['wp_handle_upload_offload'] ) ) {
				add_filter( 'wp_handle_upload', array( $this, 'on_wp_handle_upload' ), 20, 2 );
			}

			// Use wp_generate_attachment_metadata filter instead of add_attachment action
			// This ensures thumbnails are already generated before offloading.
			add_filter( 'wp_generate_attachment_metadata', array( $this, 'on_attachment_metadata_generated' ), 20, 2 );
		}

		// Use priority 5 to run before WordPress deletes metadata (default priority 10).
		add_action( 'delete_attachment', array( $this, 'on_attachment_deleted' ), 5 );
		add_action( 'cfr2_process_queue', array( QueueProcessor::class, 'process' ) );
	}

	/**
	 * Handle attachment metadata generated (after thumbnails created).
	 *
	 * @param array $metadata      Attachment metadata.
	 * @param int   $attachment_id Attachment ID.
	 * @return array Unmodified metadata.
	 */
	public function on_attachment_metadata_generated( array $metadata, int $attachment_id ): array {
		$this->process_auto_offload( $attachment_id );
		return $metadata;
	}

	/**
	 * Upload the original image as soon as WordPress accepts it.
	 *
	 * The attachment ID does not exist at this point, so metadata is finalized later
	 * in wp_generate_attachment_metadata.
	 *
	 * @param array<string, mixed> $upload  Upload data.
	 * @param string              $context Upload context.
	 * @return array<string, mixed> Unmodified upload data.
	 */
	public function on_wp_handle_upload( array $upload, string $context ): array {
		if ( empty( $upload['file'] ) || empty( $upload['type'] ) ) {
			return $upload;
		}

		$allowed_types = ExtensibilityHooks::get_allowed_mime_types();
		if ( ! in_array( $upload['type'], $allowed_types, true ) ) {
			return $upload;
		}

		$file_path = (string) $upload['file'];
		if ( ! file_exists( $file_path ) ) {
			return $upload;
		}

		$settings      = PluginSettings::get();
		$credentials   = self::get_r2_credentials( $settings );
		$error_message = SettingsValidator::validate_r2_credentials( $credentials );
		if ( null !== $error_message ) {
			error_log( '[CFR2 R2] wp_handle_upload skipped: ' . $error_message );
			return $upload;
		}

		$upload_dir = wp_upload_dir();
		$r2_key     = str_replace( wp_normalize_path( $upload_dir['basedir'] ) . '/', '', wp_normalize_path( $file_path ) );
		$r2_key     = ExtensibilityHooks::prefix_uploads_directory( $r2_key );

		$r2     = new R2Client( $credentials );
		$result = $r2->upload_file( $file_path, $r2_key );

		if ( ! empty( $result['success'] ) ) {
			set_transient( self::get_pending_upload_transient_key( $file_path ), $result, HOUR_IN_SECONDS );
		} else {
			error_log( '[CFR2 R2] wp_handle_upload failed: ' . ( $result['message'] ?? 'Unknown R2 API error' ) );
		}

		return $upload;
	}

	/**
	 * Process auto-offload for attachment.
	 *
	 * @param int $attachment_id Attachment ID.
	 */
	private function process_auto_offload( int $attachment_id ): void {
		// Get settings (auto_offload already checked in register_hooks).
		$settings = PluginSettings::get();

		$credentials   = self::get_r2_credentials( $settings );
		$error_message = SettingsValidator::validate_r2_credentials( $credentials );
		if ( null !== $error_message ) {
			BulkOperationLogger::log( $attachment_id, 'error', $error_message );
			return;
		}

		$r2      = new R2Client( $credentials );
		$offload = new OffloadService( $r2 );

		// Offload immediately.
		$result = $offload->offload( $attachment_id );

		// Log the result.
		if ( $result['success'] ) {
			$thumb_info = '';
			if ( ! empty( $result['thumbnails']['total'] ) ) {
				$thumb_info = sprintf(
					' (+%d/%d thumbnails)',
					$result['thumbnails']['success'],
					$result['thumbnails']['total']
				);
			}
			BulkOperationLogger::log( $attachment_id, 'success', 'Offloaded to R2' . $thumb_info );
		} else {
			BulkOperationLogger::log( $attachment_id, 'error', $result['message'] ?? 'Unknown error' );
		}
	}

	/**
	 * Build transient key for an original file uploaded during wp_handle_upload.
	 *
	 * @param string $file_path Local file path.
	 * @return string
	 */
	private static function get_pending_upload_transient_key( string $file_path ): string {
		return 'cfr2_pending_upload_' . md5( wp_normalize_path( $file_path ) );
	}

	/**
	 * Handle attachment deleted.
	 * If sync_delete is enabled, delete from R2. Otherwise, just clean up local DB.
	 *
	 * @param int $attachment_id Attachment ID.
	 */
	public function on_attachment_deleted( int $attachment_id ): void {
		$settings = PluginSettings::get();
		$r2_key   = $this->get_attachment_r2_key( $attachment_id );

		// If sync_delete is enabled, delete from R2.
		if ( ! empty( $settings['sync_delete'] ) ) {
			if ( '' !== $r2_key ) {
				$this->delete_from_r2( $attachment_id, $r2_key );
			} else {
				BulkOperationLogger::log(
					$attachment_id,
					'error',
					__( 'Sync delete skipped because no R2 object key was found for this attachment.', 'tp-media-offload-edge-cdn' )
				);
			}
		}

		// Always clean up local database entries.
		$this->cleanup_attachment_data( $attachment_id );
	}

	/**
	 * Read the attachment R2 key from post meta, then fall back to the status table.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return string
	 */
	private function get_attachment_r2_key( int $attachment_id ): string {
		$r2_key = get_post_meta( $attachment_id, MetaKeys::R2_KEY, true );
		if ( is_string( $r2_key ) && '' !== trim( $r2_key ) ) {
			return trim( $r2_key );
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Fallback during attachment deletion.
		$table_key = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT r2_key FROM {$wpdb->prefix}cfr2_offload_status WHERE attachment_id = %d LIMIT 1",
				$attachment_id
			)
		);

		return is_string( $table_key ) ? trim( $table_key ) : '';
	}

	/**
	 * Delete attachment files from R2 (main file + thumbnails).
	 *
	 * @param int    $attachment_id Attachment ID.
	 * @param string $r2_key        Main file R2 key.
	 */
	private function delete_from_r2( int $attachment_id, string $r2_key ): void {
		$credentials = self::get_r2_credentials();
		if ( empty( $credentials['secret_access_key'] ) ) {
			BulkOperationLogger::log( $attachment_id, 'error', 'R2 credentials not configured for sync delete' );
			return;
		}

		$r2            = new R2Client( $credentials );
		$deleted_count = 0;

		// Delete main file.
		$result = $r2->delete_file( $r2_key );
		$failed = array();
		if ( $result['success'] ) {
			++$deleted_count;
		} else {
			$failed[] = sprintf(
				/* translators: %s: R2 API error */
				__( 'Main file delete failed: %s', 'tp-media-offload-edge-cdn' ),
				$result['message'] ?? __( 'Unknown error', 'tp-media-offload-edge-cdn' )
			);
		}

		// Delete thumbnails from R2.
		$thumbnails = get_post_meta( $attachment_id, MetaKeys::THUMBNAILS, true );
		if ( ! empty( $thumbnails ) && is_array( $thumbnails ) ) {
			foreach ( $thumbnails as $size => $thumb_data ) {
				// Thumbnails are stored as array with 'r2_key' and 'url'.
				$thumb_key = is_array( $thumb_data ) ? ( $thumb_data['r2_key'] ?? '' ) : $thumb_data;
				if ( ! empty( $thumb_key ) ) {
					$thumb_result = $r2->delete_file( $thumb_key );
					if ( $thumb_result['success'] ) {
						++$deleted_count;
					} else {
						$failed[] = sprintf(
							/* translators: 1: thumbnail size, 2: R2 API error */
							__( 'Thumbnail %1$s delete failed: %2$s', 'tp-media-offload-edge-cdn' ),
							(string) $size,
							$thumb_result['message'] ?? __( 'Unknown error', 'tp-media-offload-edge-cdn' )
						);
					}
				}
			}
		}

		if ( ! empty( $failed ) ) {
			BulkOperationLogger::log(
				$attachment_id,
				'error',
				implode( ' | ', $failed )
			);
			return;
		}

		BulkOperationLogger::log(
			$attachment_id,
			'success',
			sprintf(
				/* translators: %d: number of files deleted from R2 */
				__( 'Deleted %d file(s) from R2', 'tp-media-offload-edge-cdn' ),
				$deleted_count
			)
		);
	}

	/**
	 * Clean up attachment data from database.
	 *
	 * @param int $attachment_id Attachment ID.
	 */
	private function cleanup_attachment_data( int $attachment_id ): void {
		global $wpdb;

		// Delete from offload_status table.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom status table cleanup.
		$wpdb->delete(
			$wpdb->prefix . 'cfr2_offload_status',
			array( 'attachment_id' => $attachment_id ),
			array( '%d' )
		);

		// Delete from queue table (any pending operations).
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom queue table cleanup.
		$wpdb->delete(
			$wpdb->prefix . 'cfr2_offload_queue',
			array( 'attachment_id' => $attachment_id ),
			array( '%d' )
		);

		// Clear dashboard stats cache.
		delete_transient( TransientKeys::DASHBOARD_STATS );
	}
}
