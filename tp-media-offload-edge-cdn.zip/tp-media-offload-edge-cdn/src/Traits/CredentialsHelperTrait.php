<?php
/**
 * Credentials Helper Trait.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Traits;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Services\EncryptionService;
use Salahdev\NidaEdge\Services\CloudflareToken;
use Salahdev\NidaEdge\Services\PluginSettings;

/**
 * Provides shared R2 credentials retrieval logic.
 */
trait CredentialsHelperTrait {

	/**
	 * Get R2 credentials from settings.
	 *
	 * @param array|null $settings Optional settings array.
	 * @return array R2 credentials array.
	 */
	protected static function get_r2_credentials( ?array $settings = null ): array {
		if ( null === $settings ) {
			$settings = PluginSettings::get();
		}

		$encryption = EncryptionService::get_instance();
		$secret     = $settings['r2_secret_access_key'] ?? '';

		if ( ! PluginSettings::has_wp_config_setting( 'r2_secret_access_key' ) ) {
			$secret = $encryption->decrypt( (string) $secret );
		}

		return array(
			'account_id'        => $settings['r2_account_id'] ?? '',
			'region'            => $settings['r2_region'] ?? 'auto',
			'endpoint'          => $settings['r2_endpoint'] ?? '',
			'access_key_id'     => $settings['r2_access_key_id'] ?? '',
			'secret_access_key' => (string) $secret,
			'bucket'            => $settings['r2_bucket'] ?? '',
		);
	}

	/**
	 * Get decrypted Cloudflare API token.
	 *
	 * @param array|null $settings Optional settings array.
	 * @return string Decrypted API token or empty string.
	 */
	protected static function get_cf_api_token( ?array $settings = null ): string {
		if ( null === $settings ) {
			$settings = PluginSettings::get();
		}

		return CloudflareToken::from_settings( $settings );
	}

	/**
	 * Normalize Cloudflare API token for HTTP Authorization headers.
	 *
	 * @param string $token Raw token.
	 * @return string
	 */
	private static function normalize_cf_api_token( string $token ): string {
		return CloudflareToken::normalize( $token );
	}
}
