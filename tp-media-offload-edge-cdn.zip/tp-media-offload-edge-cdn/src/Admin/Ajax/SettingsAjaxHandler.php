<?php
/**
 * Settings AJAX Handler class.
 *
 * Handles AJAX requests for settings operations.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Admin\Ajax;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Constants\NonceActions;
use Salahdev\NidaEdge\Constants\RateLimit;
use Salahdev\NidaEdge\Constants\Settings;
use Salahdev\NidaEdge\Constants\BatchConfig;
use Salahdev\NidaEdge\Constants\TransientKeys;
use Salahdev\NidaEdge\Services\EncryptionService;
use Salahdev\NidaEdge\Services\PluginSettings;
use Salahdev\NidaEdge\Services\R2Client;
use Salahdev\NidaEdge\Services\SettingsValidator;
use Salahdev\NidaEdge\Services\CloudflareAPI;
use Salahdev\NidaEdge\Services\CloudflareToken;
use Salahdev\NidaEdge\Services\URLRewriter;
use Salahdev\NidaEdge\Services\WorkerDeployer;

/**
 * SettingsAjaxHandler class - handles settings-related AJAX requests.
 */
class SettingsAjaxHandler {

	/**
	 * Register AJAX hooks.
	 */
	public function register_hooks(): void {
		add_action( 'wp_ajax_cfr2_save_settings', array( $this, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_cfr2_save_cf_token', array( $this, 'ajax_save_cf_token' ) );
		add_action( 'wp_ajax_cfr2_test_r2', array( $this, 'ajax_test_r2_connection' ) );
		add_action( 'wp_ajax_cfr2_validate_cdn_dns', array( $this, 'ajax_validate_cdn_dns' ) );
		add_action( 'wp_ajax_cfr2_enable_dns_proxy', array( $this, 'ajax_enable_dns_proxy' ) );
	}

	/**
	 * Verify settings nonce.
	 *
	 * @param string $field Nonce request field name.
	 * @return bool
	 */
	private function verify_settings_nonce( string $field = 'cfr2_nonce' ): bool {
		if ( ! check_ajax_referer( NonceActions::SETTINGS, $field, false ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Security check failed.', 'tp-media-offload-edge-cdn' ) ),
				403
			);
			return false;
		}

		return true;
	}

	/**
	 * Check current user capability for settings actions.
	 *
	 * @return bool
	 */
	private function check_settings_permissions(): bool {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Permission denied.', 'tp-media-offload-edge-cdn' ) ),
				403
			);
			return false;
		}

		return true;
	}

	/**
	 * Handle AJAX settings save.
	 */
	public function ajax_save_settings(): void {
		if ( ! $this->verify_settings_nonce() || ! $this->check_settings_permissions() ) {
			return;
		}

		// Rate limiting - prevent spam/DoS.
		$user_id    = get_current_user_id();
		$rate_key   = TransientKeys::RATE_PREFIX . $user_id;
		$save_count = get_transient( $rate_key );

		if ( false !== $save_count && (int) $save_count >= RateLimit::MAX_SAVES ) {
			wp_send_json_error(
				array( 'message' => __( 'Too many requests. Please try again later.', 'tp-media-offload-edge-cdn' ) ),
				429
			);
		}

		// Increment rate limit counter.
		set_transient( $rate_key, ( $save_count ? (int) $save_count + 1 : 1 ), RateLimit::WINDOW_SEC );

		// Get and sanitize form data.
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$input = array(
			'r2_account_id'        => sanitize_text_field( wp_unslash( $_POST['r2_account_id'] ?? '' ) ),
			'r2_region'            => sanitize_text_field( wp_unslash( $_POST['r2_region'] ?? 'auto' ) ),
			'r2_endpoint'          => esc_url_raw( wp_unslash( $_POST['r2_endpoint'] ?? '' ) ),
			'r2_access_key_id'     => sanitize_text_field( wp_unslash( $_POST['r2_access_key_id'] ?? '' ) ),
			'r2_secret_access_key' => sanitize_text_field( wp_unslash( $_POST['r2_secret_access_key'] ?? '' ) ),
			'r2_bucket'            => sanitize_text_field( wp_unslash( $_POST['r2_bucket'] ?? '' ) ),
			'r2_public_domain'     => esc_url_raw( wp_unslash( $_POST['r2_public_domain'] ?? '' ) ),
			'auto_offload'         => ! empty( $_POST['auto_offload'] ) ? 1 : 0,
			'batch_size'           => absint( $_POST['batch_size'] ?? BatchConfig::DEFAULT_SIZE ),
			'keep_local_files'     => ! empty( $_POST['keep_local_files'] ) ? 1 : 0,
			'sync_delete'          => ! empty( $_POST['sync_delete'] ) ? 1 : 0,
			'cdn_enabled'          => ! empty( $_POST['cdn_enabled'] ) ? 1 : 0,
			'local_fallback_enabled' => ! empty( $_POST['local_fallback_enabled'] ) ? 1 : 0,
			'cdn_url'              => esc_url_raw( wp_unslash( $_POST['cdn_url'] ?? '' ) ),
			'quality'              => absint( $_POST['quality'] ?? 85 ),
			'image_format'         => sanitize_text_field( wp_unslash( $_POST['image_format'] ?? 'webp' ) ),
			'smart_sizes'          => ! empty( $_POST['smart_sizes'] ) ? 1 : 0,
			'content_max_width'    => absint( $_POST['content_max_width'] ?? 800 ),
			'cf_api_token'           => (string) wp_unslash( $_POST['cf_api_token'] ?? '' ),
			'rest_public_attachment' => ! empty( $_POST['rest_public_attachment'] ) ? 1 : 0,
			'allow_svg_offload'      => ! empty( $_POST['allow_svg_offload'] ) ? 1 : 0,
		);
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$existing = PluginSettings::get();

		$raw_cf_token = trim( (string) $input['cf_api_token'] );
		if ( '' !== $raw_cf_token && '********' !== $raw_cf_token && '' === CloudflareToken::normalize( $raw_cf_token ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Cloudflare API token was not saved because it could not be recognized. Paste the raw token, the Authorization Bearer header, or the Cloudflare curl verify command.', 'tp-media-offload-edge-cdn' ),
				),
				400
			);
		}

		// Sanitize settings.
		$sanitized = $this->sanitize_settings( $input );

		// Update option.
		$updated = update_option( Settings::OPTION_KEY, $sanitized );

		if ( $existing['cdn_url'] !== $sanitized['cdn_url'] || $existing['cdn_enabled'] !== $sanitized['cdn_enabled'] ) {
			URLRewriter::clear_availability_cache( (string) $existing['cdn_url'] );
			URLRewriter::clear_availability_cache( (string) $sanitized['cdn_url'] );
		}

		if ( false === $updated ) {
			// Check if genuinely unchanged (use strict comparison).
			$current = get_option( Settings::OPTION_KEY );

			if ( false !== $current && $current === $sanitized ) {
				wp_send_json_success(
					array( 'message' => __( 'No changes detected.', 'tp-media-offload-edge-cdn' ) )
				);
			}

			wp_send_json_error(
				array( 'message' => __( 'Failed to save settings. Please try again.', 'tp-media-offload-edge-cdn' ) ),
				500
			);
		}

		$redeploy_warning = '';
		if ( ! empty( $existing['worker_deployed'] ) && ( $existing['image_format'] ?? 'webp' ) !== ( $sanitized['image_format'] ?? 'webp' ) ) {
			$redeploy_warning = $this->maybe_redeploy_worker_for_image_format( $sanitized );
		}

		wp_send_json_success(
			array(
				'message' => __( 'Settings saved.', 'tp-media-offload-edge-cdn' ) . ( '' !== $redeploy_warning ? ' ' . $redeploy_warning : '' ),
			)
		);
	}

	/**
	 * Redeploy Worker when image format changes so runtime bindings stay in sync.
	 *
	 * @param array<string, mixed> $settings Sanitized settings.
	 * @return string Optional warning for UI.
	 */
	private function maybe_redeploy_worker_for_image_format( array $settings ): string {
		$error_message = SettingsValidator::validate_cloudflare_settings( $settings, true );
		if ( null !== $error_message ) {
			return '';
		}

		$api_token = CloudflareToken::from_settings( $settings );
		if ( '' === $api_token ) {
			return '';
		}

		$api      = new CloudflareAPI( $api_token, (string) $settings['r2_account_id'] );
		$deployer = new WorkerDeployer( $api );

		$result = $deployer->deploy(
			array(
				'r2_bucket'     => (string) $settings['r2_bucket'],
				'custom_domain' => (string) ( $settings['cdn_url'] ?? '' ),
				'image_format'  => (string) ( $settings['image_format'] ?? 'webp' ),
			)
		);

		if ( ! empty( $result['success'] ) ) {
			$settings['worker_deployed']    = true;
			$settings['worker_name']        = (string) ( $result['worker_name'] ?? 'cfr2-image-transform' );
			$settings['worker_deployed_at'] = current_time( 'mysql' );
			update_option( Settings::OPTION_KEY, $settings );
			URLRewriter::clear_availability_cache( (string) ( $settings['cdn_url'] ?? '' ) );

			return '';
		}

		return __( 'Worker format update needs redeploy. Open CDN tab and click Deploy Worker.', 'tp-media-offload-edge-cdn' );
	}

	/**
	 * Save Cloudflare API token through an isolated endpoint.
	 */
	public function ajax_save_cf_token(): void {
		if ( ! $this->verify_settings_nonce( 'nonce' ) || ! $this->check_settings_permissions() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$raw_token = isset( $_POST['cloudflare_token_value'] ) ? (string) wp_unslash( $_POST['cloudflare_token_value'] ) : '';

		if ( '' === trim( $raw_token ) || '********' === trim( $raw_token ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Paste a new Cloudflare API token before saving.', 'tp-media-offload-edge-cdn' ) ),
				400
			);
		}

		if ( '' === CloudflareToken::normalize( $raw_token ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Cloudflare API token was not saved because it could not be recognized. Paste the raw token, the Authorization Bearer header, or the Cloudflare curl verify command.', 'tp-media-offload-edge-cdn' ) ),
				400
			);
		}

		if ( ! CloudflareToken::save_standalone_option( $raw_token ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Cloudflare API token could not be saved in the standalone token store. Use the wp-config.php fallback shown below.', 'tp-media-offload-edge-cdn' ) ),
				500
			);
		}

		$settings                 = get_option( Settings::OPTION_KEY, array() );
		$settings                 = is_array( $settings ) ? $settings : array();
		$settings['cf_api_token'] = 'stored_separately';
		update_option( Settings::OPTION_KEY, $settings, false );

		wp_send_json_success(
			array( 'message' => __( 'Cloudflare API token saved and can be read by the plugin.', 'tp-media-offload-edge-cdn' ) )
		);
	}

	/**
	 * Sanitize settings.
	 *
	 * @param array $input Input data.
	 * @return array Sanitized data.
	 */
	public function sanitize_settings( array $input ): array {
		$sanitized = array();

		// R2 Credentials - sanitize and encrypt.
		$sanitized['r2_account_id']    = preg_replace( '/[^a-zA-Z0-9]/', '', $input['r2_account_id'] ?? '' );
		$sanitized['r2_region']        = $this->sanitize_region_field( $input['r2_region'] ?? 'auto' );
		$sanitized['r2_endpoint']      = $this->sanitize_url_field( $input['r2_endpoint'] ?? '' );
		$sanitized['r2_access_key_id'] = sanitize_text_field( $input['r2_access_key_id'] ?? '' );

		// R2 Secret Access Key - only encrypt if not placeholder.
		$secret = $input['r2_secret_access_key'] ?? '';
		if ( ! empty( $secret ) && '********' !== $secret ) {
			$encryption                        = EncryptionService::get_instance();
			$sanitized['r2_secret_access_key'] = $encryption->encrypt( $secret );
		} else {
			// Keep existing value.
			$existing                          = PluginSettings::get();
			$sanitized['r2_secret_access_key'] = $existing['r2_secret_access_key'] ?? '';
		}

		// R2 Bucket - lowercase alphanumeric + hyphens only.
		$sanitized['r2_bucket'] = preg_replace( '/[^a-z0-9\-]/', '', strtolower( $input['r2_bucket'] ?? '' ) );

		// R2 Public Domain - custom domain for public access.
		$sanitized['r2_public_domain'] = esc_url_raw( $input['r2_public_domain'] ?? '' );

		// Offload settings.
		$sanitized['auto_offload']     = ! empty( $input['auto_offload'] ) ? 1 : 0;
		$batch_size                    = absint( $input['batch_size'] ?? BatchConfig::DEFAULT_SIZE );
		$sanitized['batch_size']       = max( BatchConfig::MIN_SIZE, min( $batch_size, BatchConfig::MAX_SIZE ) );
		$sanitized['keep_local_files'] = ! empty( $input['keep_local_files'] ) ? 1 : 0;
		$sanitized['sync_delete']      = ! empty( $input['sync_delete'] ) ? 1 : 0;

		// CDN settings.
		$sanitized['cdn_enabled']            = ! empty( $input['cdn_enabled'] ) ? 1 : 0;
		$sanitized['local_fallback_enabled'] = ! empty( $input['local_fallback_enabled'] ) ? 1 : 0;
		$sanitized['cdn_url']                = $this->sanitize_url_field( $input['cdn_url'] ?? '' );

		// Quality: 1-100.
		$quality              = absint( $input['quality'] ?? 85 );
		$sanitized['quality'] = max( 1, min( $quality, 100 ) );

		// Image format: original, webp, or avif.
		$allowed_formats           = array( 'original', 'webp', 'avif' );
		$image_format              = $input['image_format'] ?? 'webp';
		$sanitized['image_format'] = in_array( $image_format, $allowed_formats, true ) ? $image_format : 'webp';

		// Smart sizes settings.
		$sanitized['smart_sizes']       = ! empty( $input['smart_sizes'] ) ? 1 : 0;
		$content_max_width              = absint( $input['content_max_width'] ?? 800 );
		$sanitized['content_max_width'] = max( 320, min( $content_max_width, 1920 ) );

		// Cloudflare API Token - only encrypt if not placeholder.
		$cf_token = $this->normalize_cloudflare_token( (string) ( $input['cf_api_token'] ?? '' ) );
		if ( ! empty( $cf_token ) && '********' !== $cf_token ) {
			CloudflareToken::save_standalone_option( $cf_token );
			$encryption                = EncryptionService::get_instance();
			$encrypted_token           = $encryption->encrypt( $cf_token );
			$sanitized['cf_api_token'] = '' !== CloudflareToken::from_standalone_option() ? 'stored_separately' : ( '' !== $encrypted_token ? $encrypted_token : $cf_token );
		} else {
			// Keep existing value.
			$existing                  = PluginSettings::get();
			$sanitized['cf_api_token'] = $existing['cf_api_token'] ?? '';
		}

		// Worker deployment internal fields (preserve).
		$existing                        = PluginSettings::get();
		$sanitized['worker_deployed']    = $existing['worker_deployed'] ?? false;
		$sanitized['worker_name']        = $existing['worker_name'] ?? '';
		$sanitized['worker_deployed_at'] = $existing['worker_deployed_at'] ?? '';

		$sanitized['rest_public_attachment'] = ! empty( $input['rest_public_attachment'] ) ? 1 : 0;
		$sanitized['allow_svg_offload']      = ! empty( $input['allow_svg_offload'] ) ? 1 : 0;

		return $sanitized;
	}

	/**
	 * Sanitize URL field - removes trailing slash and validates.
	 *
	 * @param string $url URL to sanitize.
	 * @return string Sanitized URL.
	 */
	private function sanitize_url_field( string $url ): string {
		$url = trim( $url );
		if ( '' !== $url && ! preg_match( '#^https?://#i', $url ) ) {
			$url = 'https://' . $url;
		}

		$url = esc_url_raw( $url );
		return rtrim( $url, '/' );
	}

	/**
	 * Sanitize R2/S3 region.
	 *
	 * @param string $region Raw region.
	 * @return string
	 */
	private function sanitize_region_field( string $region ): string {
		$region = strtolower( sanitize_text_field( trim( $region ) ) );

		return '' !== $region ? $region : 'auto';
	}

	/**
	 * Normalize Cloudflare API token before encryption or request use.
	 *
	 * @param string $token Raw token.
	 * @return string
	 */
	private function normalize_cloudflare_token( string $token ): string {
		return CloudflareToken::normalize( $token );
	}

	/**
	 * Test R2 connection via AJAX.
	 */
	public function ajax_test_r2_connection(): void {
		if ( ! $this->verify_settings_nonce() || ! $this->check_settings_permissions() ) {
			return;
		}

		// Rate limiting - 5 attempts per minute.
		$user_id  = get_current_user_id();
		$rate_key = TransientKeys::R2_TEST_PREFIX . $user_id;
		$count    = get_transient( $rate_key );

		if ( false !== $count && (int) $count >= 5 ) {
			wp_send_json_error(
				array( 'message' => __( 'Too many attempts. Wait 60 seconds.', 'tp-media-offload-edge-cdn' ) ),
				429
			);
		}
		set_transient( $rate_key, ( $count ? (int) $count + 1 : 1 ), 60 );

		// Get credentials from form values (for testing before save).
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$account_id    = sanitize_text_field( wp_unslash( $_POST['r2_account_id'] ?? '' ) );
		$region        = sanitize_text_field( wp_unslash( $_POST['r2_region'] ?? 'auto' ) );
		$endpoint      = $this->sanitize_url_field( (string) wp_unslash( $_POST['r2_endpoint'] ?? '' ) );
		$access_key_id = sanitize_text_field( wp_unslash( $_POST['r2_access_key_id'] ?? '' ) );
		$secret_key    = sanitize_text_field( wp_unslash( $_POST['r2_secret_access_key'] ?? '' ) );
		$bucket        = sanitize_text_field( wp_unslash( $_POST['r2_bucket'] ?? '' ) );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		// If secret is placeholder, get from saved settings.
		if ( '********' === $secret_key || empty( $secret_key ) ) {
			$settings   = PluginSettings::get();
			$secret_key = $this->get_r2_secret_access_key( $settings );
		}

		$credentials = array(
			'account_id'        => $account_id,
			'region'            => $region,
			'endpoint'          => $endpoint,
			'access_key_id'     => $access_key_id,
			'secret_access_key' => $secret_key,
			'bucket'            => $bucket,
		);

		$error_message = SettingsValidator::validate_r2_credentials( $credentials );
		if ( null !== $error_message ) {
			wp_send_json_error( array( 'message' => $error_message ) );
		}

		// Test connection.
		$r2     = new R2Client( $credentials );
		$result = $r2->test_connection();

		if ( $result['success'] ) {
			wp_send_json_success(
				array( 'message' => __( 'Connection successful!', 'tp-media-offload-edge-cdn' ) )
			);
		} else {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}
	}

	/**
	 * AJAX handler for validate CDN DNS.
	 */
	public function ajax_validate_cdn_dns(): void {
		if ( ! $this->verify_settings_nonce( 'nonce' ) || ! $this->check_settings_permissions() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$cdn_url = isset( $_POST['cdn_url'] ) ? esc_url_raw( wp_unslash( $_POST['cdn_url'] ) ) : '';

		if ( empty( $cdn_url ) ) {
			wp_send_json_error( array( 'message' => __( 'CDN URL is required.', 'tp-media-offload-edge-cdn' ) ) );
		}

		$settings      = PluginSettings::get();
		$error_message = SettingsValidator::validate_cloudflare_settings( $settings );

		if ( null !== $error_message ) {
			wp_send_json_error( array( 'message' => $error_message ) );
		}

		$api_token = $this->get_cloudflare_api_token( $settings );
		if ( '' === $api_token ) {
			wp_send_json_error( array( 'message' => __( 'Cloudflare API token is missing or could not be decrypted. Paste the raw token again and save settings.', 'tp-media-offload-edge-cdn' ) ) );
		}

		$api    = new CloudflareAPI( $api_token, $settings['r2_account_id'] );
		$result = $api->validate_cdn_dns( $cdn_url );

		if ( $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}

	/**
	 * AJAX handler for enable DNS proxy.
	 */
	public function ajax_enable_dns_proxy(): void {
		if ( ! $this->verify_settings_nonce( 'nonce' ) || ! $this->check_settings_permissions() ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$zone_id   = isset( $_POST['zone_id'] ) ? sanitize_text_field( wp_unslash( $_POST['zone_id'] ) ) : '';
		$record_id = isset( $_POST['record_id'] ) ? sanitize_text_field( wp_unslash( $_POST['record_id'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( empty( $zone_id ) || empty( $record_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Missing zone or record ID.', 'tp-media-offload-edge-cdn' ) ) );
		}

		$settings      = PluginSettings::get();
		$error_message = SettingsValidator::validate_cloudflare_settings( $settings );

		if ( null !== $error_message ) {
			wp_send_json_error( array( 'message' => $error_message ) );
		}

		$api_token = $this->get_cloudflare_api_token( $settings );
		if ( '' === $api_token ) {
			wp_send_json_error( array( 'message' => __( 'Cloudflare API token is missing or could not be decrypted. Paste the raw token again and save settings.', 'tp-media-offload-edge-cdn' ) ) );
		}

		$api    = new CloudflareAPI( $api_token, $settings['r2_account_id'] ?? '' );
		$result = $api->enable_dns_proxy( $zone_id, $record_id );

		if ( $result['success'] ) {
			wp_send_json_success( array( 'message' => __( 'Proxy enabled successfully!', 'tp-media-offload-edge-cdn' ) ) );
		} else {
			wp_send_json_error( array( 'message' => $result['errors'][0]['message'] ?? __( 'Failed to enable proxy.', 'tp-media-offload-edge-cdn' ) ) );
		}
	}

	/**
	 * Get the R2 secret key from saved or wp-config settings.
	 *
	 * @param array<string, mixed> $settings Plugin settings.
	 * @return string
	 */
	private function get_r2_secret_access_key( array $settings ): string {
		if ( PluginSettings::has_wp_config_setting( 'r2_secret_access_key' ) ) {
			return (string) ( $settings['r2_secret_access_key'] ?? '' );
		}

		$encryption = EncryptionService::get_instance();
		return $encryption->decrypt( (string) ( $settings['r2_secret_access_key'] ?? '' ) );
	}

	/**
	 * Get the Cloudflare API token from saved or wp-config settings.
	 *
	 * @param array<string, mixed> $settings Plugin settings.
	 * @return string
	 */
	private function get_cloudflare_api_token( array $settings ): string {
		return CloudflareToken::from_settings( $settings );
	}
}
