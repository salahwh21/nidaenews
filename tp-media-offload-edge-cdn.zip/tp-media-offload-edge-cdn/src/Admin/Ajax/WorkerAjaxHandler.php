<?php
/**
 * Worker AJAX Handler class.
 *
 * Handles AJAX requests for Cloudflare Worker operations.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Admin\Ajax;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Constants\NonceActions;
use Salahdev\NidaEdge\Constants\Settings;
use Salahdev\NidaEdge\Services\CloudflareToken;
use Salahdev\NidaEdge\Services\CloudflareDiagnostics;
use Salahdev\NidaEdge\Services\PluginSettings;
use Salahdev\NidaEdge\Services\SettingsValidator;
use Salahdev\NidaEdge\Services\CloudflareAPI;
use Salahdev\NidaEdge\Services\URLRewriter;
use Salahdev\NidaEdge\Services\WorkerDeployer;

/**
 * WorkerAjaxHandler class - handles Worker-related AJAX requests.
 */
class WorkerAjaxHandler {

	/**
	 * Register AJAX hooks.
	 */
	public function register_hooks(): void {
		add_action( 'wp_ajax_cfr2_deploy_worker', array( $this, 'ajax_deploy_worker' ) );
		add_action( 'wp_ajax_cfr2_remove_worker', array( $this, 'ajax_remove_worker' ) );
		add_action( 'wp_ajax_cfr2_worker_status', array( $this, 'ajax_worker_status' ) );
		add_action( 'wp_ajax_cfr2_diagnose_cloudflare', array( $this, 'ajax_diagnose_cloudflare' ) );
	}

	/**
	 * Verify nonce for worker operations.
	 *
	 * @return bool True if valid, sends error response otherwise.
	 */
	private function verify_worker_nonce(): bool {
		if ( ! check_ajax_referer( NonceActions::WORKER, 'nonce', false ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Security check failed.', 'tp-media-offload-edge-cdn' ) ),
				403
			);
			return false;
		}

		return true;
	}

	/**
	 * Check user permissions.
	 *
	 * @return bool True if authorized, sends error response otherwise.
	 */
	private function check_permissions(): bool {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'tp-media-offload-edge-cdn' ) ), 403 );
			return false;
		}
		return true;
	}

	/**
	 * AJAX handler for deploy worker.
	 */
	public function ajax_deploy_worker(): void {
		if ( ! $this->verify_worker_nonce() || ! $this->check_permissions() ) {
			return;
		}

		$settings      = PluginSettings::get();
		$error_message = SettingsValidator::validate_cloudflare_settings( $settings, true );

		if ( null !== $error_message ) {
			wp_send_json_error( array( 'message' => $error_message ) );
		}

		$api_token = $this->get_cloudflare_api_token( $settings );
		if ( '' === $api_token ) {
			wp_send_json_error( array( 'message' => __( 'Cloudflare API token is missing or could not be decrypted. Paste the raw token again and save settings.', 'tp-media-offload-edge-cdn' ) ) );
		}

		// Initialize services.
		$api      = new CloudflareAPI( $api_token, $settings['r2_account_id'] );
		$deployer = new WorkerDeployer( $api );

		// Deploy with R2 bucket binding (direct access).
		$result = $deployer->deploy(
			array(
				'r2_bucket'     => $settings['r2_bucket'],
				'custom_domain' => $settings['cdn_url'] ?? '',
				'image_format'  => $settings['image_format'] ?? 'webp',
			)
		);

		if ( $result['success'] ) {
			// Save deployment info.
			$settings['worker_deployed']    = true;
			$settings['worker_name']        = $result['worker_name'];
			$settings['worker_deployed_at'] = current_time( 'mysql' );
			update_option( Settings::OPTION_KEY, $settings );
			URLRewriter::clear_availability_cache( (string) $settings['cdn_url'] );

			wp_send_json_success(
				array(
					'message'  => __( 'Worker deployed successfully!', 'tp-media-offload-edge-cdn' ),
					'steps'    => $result['steps'],
					'warnings' => $result['warnings'] ?? array(),
				)
			);
		} else {
			wp_send_json_error(
				array(
					'message'  => $result['message'],
					'steps'    => $result['steps'],
					'warnings' => $result['warnings'] ?? array(),
				)
			);
		}
	}

	/**
	 * AJAX handler for remove worker.
	 */
	public function ajax_remove_worker(): void {
		if ( ! $this->verify_worker_nonce() || ! $this->check_permissions() ) {
			return;
		}

		$settings      = PluginSettings::get();
		$error_message = SettingsValidator::validate_cloudflare_settings( $settings );

		if ( null !== $error_message ) {
			wp_send_json_error( array( 'message' => $error_message ) );
		}

		$api_token = $this->get_cloudflare_api_token( $settings );
		if ( '' === $api_token ) {
			wp_send_json_error( array( 'message' => __( 'Cloudflare API token is missing or could not be decrypted. Paste the raw token again and save settings.', 'tp-media-offload-edge-cdn' ) ) );
		}

		$api      = new CloudflareAPI( $api_token, $settings['r2_account_id'] ?? '' );
		$deployer = new WorkerDeployer( $api );

		$result = $deployer->undeploy();

		if ( $result['success'] ) {
			$settings['worker_deployed']    = false;
			$settings['worker_name']        = '';
			$settings['worker_deployed_at'] = '';
			update_option( Settings::OPTION_KEY, $settings );
			URLRewriter::clear_availability_cache( (string) $settings['cdn_url'] );

			wp_send_json_success( array( 'message' => __( 'Worker removed.', 'tp-media-offload-edge-cdn' ) ) );
		} else {
			wp_send_json_error( array( 'message' => $result['errors'][0]['message'] ?? 'Unknown error' ) );
		}
	}

	/**
	 * AJAX handler for worker status.
	 */
	public function ajax_worker_status(): void {
		if ( ! $this->verify_worker_nonce() || ! $this->check_permissions() ) {
			return;
		}

		$settings = PluginSettings::get();

		if ( empty( $settings['worker_deployed'] ) ) {
			if ( ! empty( $settings['cdn_url'] ) && URLRewriter::is_cdn_url_available( (string) $settings['cdn_url'] ) ) {
				$settings['worker_deployed']    = true;
				$settings['worker_name']        = $settings['worker_name'] ?: 'cfr2-image-transform';
				$settings['worker_deployed_at'] = $settings['worker_deployed_at'] ?: current_time( 'mysql' );
				update_option( Settings::OPTION_KEY, $settings );

				wp_send_json_success(
					array(
						'deployed'    => true,
						'worker_name' => $settings['worker_name'],
						'deployed_at' => $settings['worker_deployed_at'],
						'status'      => array(
							'success' => true,
							'message' => __( 'Worker route is responding.', 'tp-media-offload-edge-cdn' ),
						),
					)
				);
				return;
			}

			wp_send_json_success( array( 'deployed' => false ) );
			return;
		}

		$error_message = SettingsValidator::validate_cloudflare_settings( $settings );
		if ( null !== $error_message ) {
			wp_send_json_error( array( 'message' => $error_message ) );
		}

		$api_token = $this->get_cloudflare_api_token( $settings );
		if ( '' === $api_token ) {
			wp_send_json_error( array( 'message' => __( 'Cloudflare API token is missing or could not be decrypted. Paste the raw token again and save settings.', 'tp-media-offload-edge-cdn' ) ) );
		}

		$api      = new CloudflareAPI( $api_token, $settings['r2_account_id'] ?? '' );
		$deployer = new WorkerDeployer( $api );

		$status = $deployer->get_status();

		wp_send_json_success(
			array(
				'deployed'    => true,
				'worker_name' => $settings['worker_name'] ?? '',
				'deployed_at' => $settings['worker_deployed_at'] ?? '',
				'status'      => $status,
			)
		);
	}

	/**
	 * AJAX handler for read-only Cloudflare diagnostics.
	 */
	public function ajax_diagnose_cloudflare(): void {
		if ( ! $this->verify_worker_nonce() || ! $this->check_permissions() ) {
			return;
		}

		$diagnostics = new CloudflareDiagnostics( PluginSettings::get() );
		wp_send_json_success( $diagnostics->run() );
	}

	/**
	 * Get the Cloudflare API token from saved or wp-config settings.
	 *
	 * @param array<string, mixed> $settings Plugin settings.
	 * @return string
	 */
	private function get_cloudflare_api_token( array $settings ): string {
		return CloudflareToken::from_settings( $settings );
	}

	/**
	 * Normalize Cloudflare API token.
	 *
	 * @param string $token Raw token.
	 * @return string
	 */
	private function normalize_cloudflare_token( string $token ): string {
		return CloudflareToken::normalize( $token );
	}
}
