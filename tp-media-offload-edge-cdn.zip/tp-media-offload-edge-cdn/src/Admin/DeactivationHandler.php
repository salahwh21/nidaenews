<?php
/**
 * Deactivation Handler class.
 *
 * Adds confirmation dialog when deactivating the plugin.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Admin;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Constants\Settings;
use Salahdev\NidaEdge\Database\Schema;
use Salahdev\NidaEdge\Interfaces\HookableInterface;
use Salahdev\NidaEdge\Services\CloudflareToken;
use Salahdev\NidaEdge\Services\PluginSettings;

/**
 * DeactivationHandler class - handles deactivation with cleanup option.
 */
class DeactivationHandler implements HookableInterface {

	/**
	 * Register hooks.
	 */
	public function register_hooks(): void {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_deactivation_dialog_script' ) );
		add_action( 'wp_ajax_cfr2_cleanup_data', array( $this, 'ajax_cleanup_data' ) );
		add_action( 'wp_ajax_cfr2_reset_settings', array( $this, 'ajax_reset_settings' ) );
	}

	/**
	 * Enqueue deactivation dialog JavaScript.
	 *
	 * @param string $hook Current admin hook suffix.
	 */
	public function enqueue_deactivation_dialog_script( string $hook ): void {
		if ( 'plugins.php' !== $hook ) {
			return;
		}

		$config = array(
			'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
			'pluginFile'     => \CFR2_BASENAME,
			'cleanupNonce'   => wp_create_nonce( 'cfr2_cleanup_nonce' ),
			'confirmMessage' => __(
				"Do you want to delete all plugin data?\n\n- Click OK to delete all settings, database tables, and media metadata\n- Click Cancel to keep data (you can reinstall later)\n\nNote: Files on R2 storage will not be deleted.",
				'tp-media-offload-edge-cdn'
			),
		);

		$script  = "jQuery(function($) {\n";
		$script .= "\tconst config = " . wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . ";\n";
		$script .= "\tconst pluginRow = $('tr[data-plugin=\"' + config.pluginFile + '\"]');\n";
		$script .= "\tconst deactivateLink = pluginRow.find('.deactivate a');\n";
		$script .= "\tconst originalHref = deactivateLink.attr('href');\n";
		$script .= "\n";
		$script .= "\tif (!deactivateLink.length || !originalHref) {\n";
		$script .= "\t\treturn;\n";
		$script .= "\t}\n";
		$script .= "\n";
		$script .= "\tdeactivateLink.on('click', function(event) {\n";
		$script .= "\t\tevent.preventDefault();\n";
		$script .= "\n";
		$script .= "\t\tif (!window.confirm(config.confirmMessage)) {\n";
		$script .= "\t\t\twindow.location.href = originalHref;\n";
		$script .= "\t\t\treturn;\n";
		$script .= "\t\t}\n";
		$script .= "\n";
		$script .= "\t\t$.ajax({\n";
		$script .= "\t\t\turl: config.ajaxUrl,\n";
		$script .= "\t\t\ttype: 'POST',\n";
		$script .= "\t\t\tdata: {\n";
		$script .= "\t\t\t\taction: 'cfr2_cleanup_data',\n";
		$script .= "\t\t\t\tnonce: config.cleanupNonce\n";
		$script .= "\t\t\t}\n";
		$script .= "\t\t}).always(function() {\n";
		$script .= "\t\t\twindow.location.href = originalHref;\n";
		$script .= "\t\t});\n";
		$script .= "\t});\n";
		$script .= '});';

		wp_enqueue_script( 'jquery' );
		wp_add_inline_script( 'jquery', $script, 'after' );
	}

	/**
	 * AJAX handler to cleanup all plugin data.
	 */
	public function ajax_cleanup_data(): void {
		check_ajax_referer( 'cfr2_cleanup_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Permission denied.', 'tp-media-offload-edge-cdn' ) ),
				403
			);
		}

		global $wpdb;

		// 1. Securely wipe sensitive data.
		$settings = get_option( Settings::OPTION_KEY, array() );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}
		if ( ! empty( $settings['r2_secret_access_key'] ) ) {
			$settings['r2_secret_access_key'] = str_repeat( '0', strlen( $settings['r2_secret_access_key'] ) );
		}
		if ( ! empty( $settings['cf_api_token'] ) ) {
			$settings['cf_api_token'] = str_repeat( '0', strlen( $settings['cf_api_token'] ) );
		}
		update_option( Settings::OPTION_KEY, $settings );

		// 2. Remove plugin options.
		delete_option( Settings::OPTION_KEY );
		CloudflareToken::delete_standalone_option();
		delete_option( 'cfr2_db_version' );
		delete_option( 'cfr2_bulk_operation_logs' );

		// 3. Drop custom database tables.
		Schema::drop_tables();

		// 4. Remove all post meta.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE %s",
				'_cfr2_%'
			)
		);

		// 5. Clean up transients.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				$wpdb->esc_like( '_transient_cfr2_' ) . '%',
				$wpdb->esc_like( '_transient_timeout_cfr2_' ) . '%'
			)
		);

		// 6. Clear scheduled cron events.
		wp_clear_scheduled_hook( 'cfr2_process_queue' );
		wp_clear_scheduled_hook( 'cfr2_cleanup_stats' );

		wp_send_json_success(
			array( 'message' => __( 'Data cleaned.', 'tp-media-offload-edge-cdn' ) )
		);
	}

	/**
	 * AJAX handler to reset saved settings and local caches without deleting media metadata.
	 */
	public function ajax_reset_settings(): void {
		check_ajax_referer( 'cfr2_reset_settings_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Permission denied.', 'tp-media-offload-edge-cdn' ) ),
				403
			);
		}

		global $wpdb;

		$settings = get_option( Settings::OPTION_KEY, array() );
		if ( is_array( $settings ) ) {
			if ( ! empty( $settings['r2_secret_access_key'] ) ) {
				$settings['r2_secret_access_key'] = str_repeat( '0', strlen( (string) $settings['r2_secret_access_key'] ) );
			}
			if ( ! empty( $settings['cf_api_token'] ) ) {
				$settings['cf_api_token'] = str_repeat( '0', strlen( (string) $settings['cf_api_token'] ) );
			}
			update_option( Settings::OPTION_KEY, $settings );
		}

		delete_option( Settings::OPTION_KEY );
		CloudflareToken::delete_standalone_option();
		delete_option( 'cfr2_bulk_operation_logs' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options}
				WHERE option_name LIKE %s
				OR option_name LIKE %s
				OR option_name LIKE %s
				OR option_name LIKE %s",
				$wpdb->esc_like( '_transient_cfr2_' ) . '%',
				$wpdb->esc_like( '_transient_timeout_cfr2_' ) . '%',
				$wpdb->esc_like( '_site_transient_cfr2_' ) . '%',
				$wpdb->esc_like( '_site_transient_timeout_cfr2_' ) . '%'
			)
		);

		wp_clear_scheduled_hook( 'cfr2_process_queue' );
		wp_clear_scheduled_hook( 'cfr2_cleanup_stats' );
		PluginSettings::migrate_if_needed();

		wp_send_json_success(
			array(
				'message' => __( 'Saved settings and cached data were reset. Re-enter your credentials and save settings.', 'tp-media-offload-edge-cdn' ),
			)
		);
	}
}
