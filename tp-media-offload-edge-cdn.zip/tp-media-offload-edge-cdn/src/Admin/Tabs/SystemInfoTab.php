<?php
/**
 * System Info Tab class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Admin\Tabs;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Services\CloudflareToken;
use Salahdev\NidaEdge\Services\PluginSettings;
use Salahdev\NidaEdge\Services\R2Client;
use Salahdev\NidaEdge\Services\URLRewriter;

/**
 * SystemInfoTab class - renders system information and debug data.
 */
class SystemInfoTab {

	/**
	 * REST API and hardening options (saved with main settings form).
	 *
	 * @param array $settings Plugin settings.
	 */
	private static function render_security_options( array $settings ): void {
		?>
		<div class="settings-section cfr2-security-options">
			<h3><?php esc_html_e( 'REST API & security', 'tp-media-offload-edge-cdn' ); ?></h3>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Public attachment endpoint', 'tp-media-offload-edge-cdn' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="rest_public_attachment" value="1" <?php checked( ! empty( $settings['rest_public_attachment'] ) ); ?> />
							<?php esc_html_e( 'Allow unauthenticated GET /wp-json/cfr2/v1/attachment/{id}. Response omits storage URLs for visitors; enable only if a headless or public app needs offload status.', 'tp-media-offload-edge-cdn' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'SVG offload', 'tp-media-offload-edge-cdn' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="allow_svg_offload" value="1" <?php checked( ! empty( $settings['allow_svg_offload'] ) ); ?> />
							<?php esc_html_e( 'Allow SVG in the offload MIME allow-list. Turn off if you do not need SVG in the media library (reduces script-in-SVG risk).', 'tp-media-offload-edge-cdn' ); ?>
						</label>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Render the system info tab.
	 */
	public static function render(): void {
		$settings = PluginSettings::get();
		?>
		<div class="cloudflare-r2-offload-cdn-tab-content" id="tab-system-info">
			<h2><?php esc_html_e( 'System Information', 'tp-media-offload-edge-cdn' ); ?></h2>
			<p class="description"><?php esc_html_e( 'System status and debug information for troubleshooting.', 'tp-media-offload-edge-cdn' ); ?></p>

			<?php self::render_security_options( $settings ); ?>
			<?php self::render_system_status( $settings ); ?>
			<?php self::render_debug_info( $settings ); ?>
			<?php self::render_reset_tools(); ?>
		</div>
		<?php
	}

	/**
	 * Render system status section.
	 *
	 * @param array $settings Plugin settings.
	 */
	private static function render_system_status( array $settings ): void {
		$statuses = self::get_system_statuses( $settings );
		?>
		<div class="settings-section cfr2-system-status">
			<h3><?php esc_html_e( 'System Status', 'tp-media-offload-edge-cdn' ); ?></h3>
			<table class="widefat cfr2-status-table">
				<tbody>
					<?php foreach ( $statuses as $status ) : ?>
						<tr>
							<td class="cfr2-status-label"><?php echo esc_html( $status['label'] ); ?></td>
							<td class="cfr2-status-value">
								<?php if ( 'ok' === $status['status'] ) : ?>
									<span class="cfr2-status-ok"><span class="dashicons dashicons-yes-alt"></span> <?php echo esc_html( $status['value'] ); ?></span>
								<?php elseif ( 'warning' === $status['status'] ) : ?>
									<span class="cfr2-status-warning"><span class="dashicons dashicons-warning"></span> <?php echo esc_html( $status['value'] ); ?></span>
								<?php elseif ( 'error' === $status['status'] ) : ?>
									<span class="cfr2-status-error"><span class="dashicons dashicons-dismiss"></span> <?php echo esc_html( $status['value'] ); ?></span>
								<?php else : ?>
									<span class="cfr2-status-info"><?php echo esc_html( $status['value'] ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Get system statuses.
	 *
	 * @param array $settings Plugin settings.
	 * @return array Status items.
	 */
	private static function get_system_statuses( array $settings ): array {
		$statuses = array();

		// Plugin version.
		$statuses[] = array(
			'label'  => __( 'Plugin Version', 'tp-media-offload-edge-cdn' ),
			'value'  => \CFR2_VERSION,
			'status' => 'info',
		);

		// PHP version.
		$php_version = PHP_VERSION;
		$php_min     = '8.0';
		$php_status  = version_compare( $php_version, $php_min, '>=' ) ? 'ok' : 'error';
		$statuses[]  = array(
			'label'  => __( 'PHP Version', 'tp-media-offload-edge-cdn' ),
			'value'  => $php_version . ( 'error' === $php_status ? " (min: {$php_min})" : '' ),
			'status' => $php_status,
		);

		// WordPress version.
		$wp_version = get_bloginfo( 'version' );
		$wp_min     = '6.0';
		$wp_status  = version_compare( $wp_version, $wp_min, '>=' ) ? 'ok' : 'warning';
		$statuses[] = array(
			'label'  => __( 'WordPress Version', 'tp-media-offload-edge-cdn' ),
			'value'  => $wp_version,
			'status' => $wp_status,
		);

		// R2 Connection.
		$r2_location_configured = ! empty( $settings['r2_account_id'] ) || ! empty( $settings['r2_endpoint'] );
		$r2_configured          = $r2_location_configured && ! empty( $settings['r2_bucket'] ) && ! empty( $settings['r2_secret_access_key'] );
		$statuses[]    = array(
			'label'  => __( 'R2 Credentials', 'tp-media-offload-edge-cdn' ),
			'value'  => $r2_configured ? __( 'Configured', 'tp-media-offload-edge-cdn' ) : __( 'Not configured', 'tp-media-offload-edge-cdn' ),
			'status' => $r2_configured ? 'ok' : 'warning',
		);

		// Cloudflare API Token.
		$cf_configured = '' !== self::get_cloudflare_api_token_for_status( $settings );
		$statuses[]    = array(
			'label'  => __( 'Cloudflare API Token', 'tp-media-offload-edge-cdn' ),
			'value'  => $cf_configured ? __( 'Configured', 'tp-media-offload-edge-cdn' ) : __( 'Not configured', 'tp-media-offload-edge-cdn' ),
			'status' => $cf_configured ? 'ok' : 'warning',
		);

		// Worker Status.
		$worker_deployed     = ! empty( $settings['worker_deployed'] );
		$worker_route_active = ! $worker_deployed && ! empty( $settings['cdn_url'] ) && URLRewriter::is_cdn_url_available( (string) $settings['cdn_url'] );
		$statuses[]      = array(
			'label'  => __( 'Worker Status', 'tp-media-offload-edge-cdn' ),
			'value'  => $worker_deployed ? __( 'Deployed', 'tp-media-offload-edge-cdn' ) : ( $worker_route_active ? __( 'Route responding', 'tp-media-offload-edge-cdn' ) : __( 'Not deployed', 'tp-media-offload-edge-cdn' ) ),
			'status' => $worker_deployed || $worker_route_active ? 'ok' : 'warning',
		);

		// CDN Status.
		$cdn_enabled = ! empty( $settings['cdn_enabled'] ) && ! empty( $settings['cdn_url'] );
		$statuses[]  = array(
			'label'  => __( 'CDN Status', 'tp-media-offload-edge-cdn' ),
			'value'  => $cdn_enabled ? __( 'Enabled', 'tp-media-offload-edge-cdn' ) : __( 'Disabled', 'tp-media-offload-edge-cdn' ),
			'status' => $cdn_enabled ? 'ok' : 'info',
		);

		// cURL extension.
		$curl_enabled = function_exists( 'curl_version' );
		$statuses[]   = array(
			'label'  => __( 'cURL Extension', 'tp-media-offload-edge-cdn' ),
			'value'  => $curl_enabled ? __( 'Enabled', 'tp-media-offload-edge-cdn' ) : __( 'Not available', 'tp-media-offload-edge-cdn' ),
			'status' => $curl_enabled ? 'ok' : 'error',
		);

		// OpenSSL extension.
		$openssl_enabled = extension_loaded( 'openssl' );
		$statuses[]      = array(
			'label'  => __( 'OpenSSL Extension', 'tp-media-offload-edge-cdn' ),
			'value'  => $openssl_enabled ? __( 'Enabled', 'tp-media-offload-edge-cdn' ) : __( 'Not available', 'tp-media-offload-edge-cdn' ),
			'status' => $openssl_enabled ? 'ok' : 'error',
		);

		// Memory limit.
		$memory_limit  = ini_get( 'memory_limit' );
		$memory_bytes  = wp_convert_hr_to_bytes( $memory_limit );
		$memory_min    = 128 * 1024 * 1024; // 128MB.
		$memory_status = $memory_bytes >= $memory_min ? 'ok' : 'warning';
		$statuses[]    = array(
			'label'  => __( 'PHP Memory Limit', 'tp-media-offload-edge-cdn' ),
			'value'  => $memory_limit,
			'status' => $memory_status,
		);

		// Max execution time.
		$max_execution = ini_get( 'max_execution_time' );
		$exec_status   = ( 0 === (int) $max_execution || (int) $max_execution >= 60 ) ? 'ok' : 'warning';
		$statuses[]    = array(
			'label'  => __( 'Max Execution Time', 'tp-media-offload-edge-cdn' ),
			'value'  => 0 === (int) $max_execution ? __( 'Unlimited', 'tp-media-offload-edge-cdn' ) : $max_execution . 's',
			'status' => $exec_status,
		);

		return $statuses;
	}

	/**
	 * Get Cloudflare token only for configured/not configured status.
	 *
	 * @param array<string, mixed> $settings Plugin settings.
	 * @return string
	 */
	private static function get_cloudflare_api_token_for_status( array $settings ): string {
		return CloudflareToken::from_settings( $settings );
	}

	/**
	 * Render debug information section.
	 *
	 * @param array $settings Plugin settings.
	 */
	private static function render_debug_info( array $settings ): void {
		$debug_info = self::get_debug_info( $settings );
		?>
		<div class="settings-section cfr2-debug-info">
			<h3><?php esc_html_e( 'Debug Information', 'tp-media-offload-edge-cdn' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Copy this information when requesting support.', 'tp-media-offload-edge-cdn' ); ?></p>
			<textarea id="cfr2-debug-textarea" class="cfr2-debug-textarea" readonly rows="20"><?php echo esc_textarea( $debug_info ); ?></textarea>
			<p>
				<button type="button" class="button" onclick="navigator.clipboard.writeText(document.getElementById('cfr2-debug-textarea').value); this.textContent='Copied!';">
					<?php esc_html_e( 'Copy to Clipboard', 'tp-media-offload-edge-cdn' ); ?>
				</button>
			</p>
		</div>
		<?php
	}

	/**
	 * Render reset tools for clearing stale saved settings.
	 */
	private static function render_reset_tools(): void {
		$config = array(
			'resetNonce'    => wp_create_nonce( 'cfr2_reset_settings_nonce' ),
			'cleanupNonce'  => wp_create_nonce( 'cfr2_cleanup_nonce' ),
			'resetConfirm'  => __( 'Reset saved settings and cached data? This will remove stored credentials and CDN/R2 settings from the database. Files on R2 and media library items will not be deleted.', 'tp-media-offload-edge-cdn' ),
			'cleanupConfirm' => __( 'Delete all plugin data from the database? This removes settings, plugin tables, queue/status records, and media metadata. Files on R2 and WordPress media files will not be deleted.', 'tp-media-offload-edge-cdn' ),
			'resetSuccess'  => __( 'Reset completed. The page will reload now.', 'tp-media-offload-edge-cdn' ),
			'cleanupSuccess' => __( 'All plugin data was deleted. The page will reload now.', 'tp-media-offload-edge-cdn' ),
			'error'         => __( 'Reset failed. Please try again.', 'tp-media-offload-edge-cdn' ),
		);
		?>
		<div class="settings-section cfr2-reset-tools">
			<h3><?php esc_html_e( 'Reset Tools', 'tp-media-offload-edge-cdn' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Use this when an old token, endpoint, or cached setting is stuck in the database. wp-config.php constants will still override database settings.', 'tp-media-offload-edge-cdn' ); ?></p>
			<p>
				<button type="button" class="button" id="cfr2-reset-settings">
					<?php esc_html_e( 'Reset Saved Settings and Cache', 'tp-media-offload-edge-cdn' ); ?>
				</button>
			</p>
			<p class="description"><?php esc_html_e( 'Delete stored plugin settings, tables, queues, status records, and attachment metadata. Files on R2 are not deleted.', 'tp-media-offload-edge-cdn' ); ?></p>
			<p>
				<button type="button" class="button cfr2-danger-button" id="cfr2-cleanup-data">
					<?php esc_html_e( 'Delete All Plugin Data', 'tp-media-offload-edge-cdn' ); ?>
				</button>
			</p>
		</div>
		<script>
			jQuery(function($) {
				const config = <?php echo wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?>;
				$('#cfr2-reset-settings').on('click', function() {
					if (!window.confirm(config.resetConfirm)) {
						return;
					}

					const $button = $(this);
					$button.prop('disabled', true);

					$.post(ajaxurl, {
						action: 'cfr2_reset_settings',
						nonce: config.resetNonce
					}).done(function(response) {
						if (response && response.success) {
							window.alert(response.data && response.data.message ? response.data.message : config.resetSuccess);
							window.location.reload();
							return;
						}

						window.alert(response && response.data && response.data.message ? response.data.message : config.error);
						$button.prop('disabled', false);
					}).fail(function() {
						window.alert(config.error);
						$button.prop('disabled', false);
					});
				});

				$('#cfr2-cleanup-data').on('click', function() {
					if (!window.confirm(config.cleanupConfirm)) {
						return;
					}

					const $button = $(this);
					$button.prop('disabled', true);

					$.post(ajaxurl, {
						action: 'cfr2_cleanup_data',
						nonce: config.cleanupNonce
					}).done(function(response) {
						if (response && response.success) {
							window.alert(response.data && response.data.message ? response.data.message : config.cleanupSuccess);
							window.location.reload();
							return;
						}

						window.alert(response && response.data && response.data.message ? response.data.message : config.error);
						$button.prop('disabled', false);
					}).fail(function() {
						window.alert(config.error);
						$button.prop('disabled', false);
					});
				});
			});
		</script>
		<?php
	}

	/**
	 * Get debug information as text.
	 *
	 * @param array $settings Plugin settings.
	 * @return string Debug info text.
	 */
	private static function get_debug_info( array $settings ): string {
		global $wpdb;

		$lines = array();

		$lines[] = '### NidaEdge - Debug Info ###';
		$lines[] = '';

		// Plugin Info.
		$lines[] = '## Plugin';
		$lines[] = 'Version: ' . \CFR2_VERSION;
		$lines[] = '';

		// WordPress Info.
		$lines[] = '## WordPress';
		$lines[] = 'Version: ' . get_bloginfo( 'version' );
		$lines[] = 'Multisite: ' . ( is_multisite() ? 'Yes' : 'No' );
		$lines[] = 'Site URL: ' . get_site_url();
		$lines[] = 'Home URL: ' . get_home_url();
		$lines[] = 'Language: ' . get_locale();
		$lines[] = 'Timezone: ' . wp_timezone_string();
		$lines[] = '';

		// Server Info.
		$lines[] = '## Server';
		$lines[] = 'PHP Version: ' . PHP_VERSION;
		$lines[] = 'MySQL Version: ' . $wpdb->db_version();
		$lines[] = 'Web Server: ' . ( isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : 'Unknown' );
		$lines[] = 'Memory Limit: ' . ini_get( 'memory_limit' );
		$lines[] = 'Max Execution Time: ' . ini_get( 'max_execution_time' ) . 's';
		$lines[] = 'Max Upload Size: ' . size_format( wp_max_upload_size() );
		$lines[] = 'Post Max Size: ' . ini_get( 'post_max_size' );
		$lines[] = '';

		// PHP Extensions.
		$lines[] = '## PHP Extensions';
		// Note: gd/imagick not needed - image processing done by Cloudflare Workers.
		$extensions = array( 'curl', 'openssl', 'json', 'mbstring' );
		foreach ( $extensions as $ext ) {
			$lines[] = $ext . ': ' . ( extension_loaded( $ext ) ? 'Enabled' : 'Disabled' );
		}
		$lines[] = '';

		// Plugin Settings (sanitized).
		$lines[] = '## Plugin Settings';
		$lines[] = 'R2 Account ID: ' . ( ! empty( $settings['r2_account_id'] ) ? substr( $settings['r2_account_id'], 0, 8 ) . '...' : 'Not set' );
		$lines[] = 'R2 Region: ' . ( $settings['r2_region'] ?? 'auto' );
		$lines[] = 'R2 Endpoint: ' . ( ! empty( $settings['r2_endpoint'] ) ? $settings['r2_endpoint'] : 'Default Cloudflare R2 endpoint' );
		$lines[] = 'R2 Bucket: ' . ( $settings['r2_bucket'] ?? 'Not set' );
		$lines[] = 'R2 Credentials: ' . ( ! empty( $settings['r2_secret_access_key'] ) ? 'Configured' : 'Not configured' );
		$lines[] = 'CF API Token: ' . ( '' !== self::get_cloudflare_api_token_for_status( $settings ) ? 'Configured' : 'Not configured' );
		$lines[] = 'Auto Offload: ' . ( ! empty( $settings['auto_offload'] ) ? 'Enabled' : 'Disabled' );
		$lines[] = 'Batch Size: ' . ( $settings['batch_size'] ?? 25 );
		$lines[] = 'Keep Local Files: ' . ( ! empty( $settings['keep_local_files'] ) ? 'Yes' : 'No' );
		$lines[] = 'CDN Enabled: ' . ( ! empty( $settings['cdn_enabled'] ) ? 'Yes' : 'No' );
		$lines[] = 'CDN URL: ' . ( $settings['cdn_url'] ?? 'Not set' );
		$lines[] = 'Quality: ' . ( $settings['quality'] ?? 85 );
		$lines[] = 'Image Format: ' . ( $settings['image_format'] ?? 'webp' );
		$lines[] = 'Smart Sizes: ' . ( ! empty( $settings['smart_sizes'] ) ? 'Yes' : 'No' );
		$lines[] = 'Worker Deployed: ' . ( ! empty( $settings['worker_deployed'] ) ? 'Yes' : 'No' );
		$lines[] = 'Worker Name: ' . ( $settings['worker_name'] ?? 'Not set' );
		$lines[] = 'REST public attachment: ' . ( ! empty( $settings['rest_public_attachment'] ) ? 'Yes' : 'No' );
		$lines[] = 'SVG offload allowed: ' . ( ! empty( $settings['allow_svg_offload'] ) ? 'Yes' : 'No' );
		$lines[] = '';

		// Media Stats.
		$lines[]           = '## Media Statistics';
		$total_attachments = wp_count_posts( 'attachment' );
		$total_count       = $total_attachments->inherit ?? 0;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Debug info aggregation.
		$offloaded_count = $wpdb->get_var(
			"SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = '_cfr2_offloaded' AND meta_value = '1'"
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom queue table.
		$pending_count = $wpdb->get_var(
			"SELECT COUNT(DISTINCT attachment_id) FROM {$wpdb->prefix}cfr2_offload_queue WHERE status IN ('pending', 'processing')"
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom queue table.
		$failed_count = $wpdb->get_var(
			"SELECT COUNT(DISTINCT attachment_id) FROM {$wpdb->prefix}cfr2_offload_queue WHERE status = 'failed'"
		);

		$lines[] = 'Total Media: ' . $total_count;
		$lines[] = 'Offloaded: ' . $offloaded_count;
		$lines[] = 'Pending: ' . $pending_count;
		$lines[] = 'Failed (24h): ' . $failed_count;
		$lines[] = 'Local: ' . ( $total_count - $offloaded_count - $pending_count );
		$lines[] = '';

		// Database Tables.
		$lines[] = '## Database Tables';
		$tables  = array(
			$wpdb->prefix . 'cfr2_offload_status',
			$wpdb->prefix . 'cfr2_offload_queue',
			$wpdb->prefix . 'cfr2_stats',
		);
		foreach ( $tables as $table ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Schema check.
			$exists  = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
			$lines[] = basename( $table ) . ': ' . ( $exists ? 'Exists' : 'Missing' );
		}
		$lines[] = '';

		// Active Theme.
		$lines[]      = '## Active Theme';
		$theme        = wp_get_theme();
		$lines[]      = 'Name: ' . $theme->get( 'Name' );
		$lines[]      = 'Version: ' . $theme->get( 'Version' );
		$parent_theme = $theme->parent();
		if ( $parent_theme ) {
			$lines[] = 'Parent Theme: ' . $parent_theme->get( 'Name' ) . ' ' . $parent_theme->get( 'Version' );
		}
		$lines[] = '';

		// Active Plugins.
		$lines[]        = '## Active Plugins';
		$active_plugins = get_option( 'active_plugins', array() );
		foreach ( $active_plugins as $plugin ) {
			$plugin_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin );
			$lines[]     = $plugin_data['Name'] . ' ' . $plugin_data['Version'];
		}
		$lines[] = '';

		$lines[] = '### End Debug Info ###';

		return implode( "\n", $lines );
	}
}
