<?php
/**
 * CDN Tab class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Admin\Tabs;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Services\CloudflareToken;
use Salahdev\NidaEdge\Services\URLRewriter;

/**
 * CdnTab class - renders CDN configuration and Worker deployment.
 */
class CdnTab {

	/**
	 * Render the CDN tab.
	 *
	 * @param array $settings Current settings.
	 */
	public static function render( array $settings ): void {
		$worker_deployed     = ! empty( $settings['worker_deployed'] );
		$worker_route_active = ! $worker_deployed && ! empty( $settings['cdn_url'] ) && URLRewriter::is_cdn_url_available( (string) $settings['cdn_url'] );
		?>
		<div class="cloudflare-r2-offload-cdn-tab-content" id="tab-cdn">
			<h2><?php esc_html_e( 'CDN Configuration', 'tp-media-offload-edge-cdn' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Configure CDN URL rewriting and image optimization settings.', 'tp-media-offload-edge-cdn' ); ?></p>
			<p class="description cfr2-build-marker">
				<?php
				printf(
					esc_html__( 'Token fix build: %s', 'tp-media-offload-edge-cdn' ),
					esc_html( \CFR2_VERSION )
				);
				?>
			</p>

			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="cdn_enabled"><?php esc_html_e( 'Enable CDN (Auto Avif/WebP & Optimization)', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<input type="hidden" name="cdn_enabled" value="0" />
						<label class="cloudflare-r2-offload-cdn-toggle">
							<input type="checkbox" id="cdn_enabled" name="cdn_enabled" value="1"
								<?php checked( 1, $settings['cdn_enabled'] ?? 0 ); ?> />
							<span class="cloudflare-r2-offload-cdn-toggle-slider"></span>
						</label>
						<p class="description"><?php esc_html_e( 'Replace media URLs with CDN URLs for optimized delivery.', 'tp-media-offload-edge-cdn' ); ?></p>
					</td>
				</tr>
			</table>

			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="cf_api_token"><?php esc_html_e( 'Cloudflare API Token', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<?php
						$token_value = '' !== CloudflareToken::from_settings( $settings ) ? '********' : '';
						?>
						<input type="password" id="cf_api_token" name="cf_api_token"
							value="<?php echo esc_attr( $token_value ); ?>"
							class="regular-text" autocomplete="new-password" />
						<button type="button" id="cfr2-save-cloudflare-token" class="button button-secondary">
							<?php esc_html_e( 'Save Token Only', 'tp-media-offload-edge-cdn' ); ?>
						</button>
						<span id="cfr2-save-cloudflare-token-result" style="margin-left: 10px;"></span>
						<p class="description"><?php esc_html_e( 'Required permissions: Workers Scripts Edit, Workers R2 Storage Edit, Zone Read, DNS Edit, Workers Routes Edit, Cache Purge', 'tp-media-offload-edge-cdn' ); ?></p>
						<p class="description"><?php esc_html_e( 'Paste the raw token only. If you paste an Authorization Bearer header or Cloudflare curl verify command, the plugin will extract the token automatically.', 'tp-media-offload-edge-cdn' ); ?></p>
						<p class="description"><?php esc_html_e( 'If the main Save Settings button does not keep the token, use Save Token Only. This stores the token in a separate option and the plugin will read it first.', 'tp-media-offload-edge-cdn' ); ?></p>
						<p class="description"><?php esc_html_e( 'Create at: Cloudflare Dashboard → My Profile → API Tokens', 'tp-media-offload-edge-cdn' ); ?></p>
						<details class="cfr2-setup-guide">
							<summary><?php esc_html_e( 'wp-config.php fallback', 'tp-media-offload-edge-cdn' ); ?></summary>
							<div class="cfr2-setup-guide-content">
								<p><?php esc_html_e( 'If your host or security plugin blocks saving API tokens from wp-admin, add cf_api_token to ACOOFM_SETTINGS in wp-config.php.', 'tp-media-offload-edge-cdn' ); ?></p>
								<pre><code>define( 'ACOOFM_SETTINGS', serialize( array(
	'cf_api_token' =&gt; 'PASTE_TOKEN_HERE',
) ) );</code></pre>
							</div>
						</details>
					</td>
				</tr>
			</table>

			<div class="cdn-fields" <?php echo empty( $settings['cdn_enabled'] ) ? 'style="display:none;"' : ''; ?>>
				<table class="form-table">
					<tr>
						<th scope="row">
							<label for="local_fallback_enabled"><?php esc_html_e( 'Local Emergency Fallback', 'tp-media-offload-edge-cdn' ); ?></label>
						</th>
						<td>
							<input type="hidden" name="local_fallback_enabled" value="0" />
							<label class="cloudflare-r2-offload-cdn-toggle">
								<input type="checkbox" id="local_fallback_enabled" name="local_fallback_enabled" value="1"
									<?php checked( 1, $settings['local_fallback_enabled'] ?? 0 ); ?> />
								<span class="cloudflare-r2-offload-cdn-toggle-slider"></span>
							</label>
							<p class="description"><?php esc_html_e( 'Serve local WordPress media URLs instead of CDN/R2 URLs. Use this as an emergency switch if the Worker or R2 delivery is unavailable.', 'tp-media-offload-edge-cdn' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="cdn_url"><?php esc_html_e( 'CDN URL', 'tp-media-offload-edge-cdn' ); ?></label>
						</th>
						<td>
							<div class="cfr2-cdn-url-row">
								<input type="url" id="cdn_url" name="cdn_url"
									value="<?php echo esc_url( $settings['cdn_url'] ?? '' ); ?>"
									class="regular-text" placeholder="https://cdn.example.com" />
								<button type="button" id="validate-cdn-dns" class="button">
									<?php esc_html_e( 'Validate DNS', 'tp-media-offload-edge-cdn' ); ?>
								</button>
							</div>
							<div id="cdn-dns-status" class="cfr2-dns-status" style="display:none;"></div>
							<p class="description"><?php esc_html_e( 'Your custom domain pointing to the Worker. Uses Cloudflare Custom Domain (no Workers Route, no R2 public domain needed). DNS record will be created automatically if not exists.', 'tp-media-offload-edge-cdn' ); ?></p>

							<details class="cfr2-setup-guide">
								<summary><?php esc_html_e( 'How does automatic DNS setup work?', 'tp-media-offload-edge-cdn' ); ?></summary>
								<div class="cfr2-setup-guide-content">
									<p><strong><?php esc_html_e( 'Automatic Setup (Recommended)', 'tp-media-offload-edge-cdn' ); ?></strong></p>
									<ol>
										<li><?php esc_html_e( 'Enter your desired CDN URL (e.g., https://cdn.yourdomain.com)', 'tp-media-offload-edge-cdn' ); ?></li>
										<li><?php esc_html_e( 'Click "Validate DNS" to check or create a proxied DNS record automatically', 'tp-media-offload-edge-cdn' ); ?></li>
										<li><?php esc_html_e( 'Click "Deploy Worker" to upload the Worker, bind the R2 bucket, and configure Custom Domain', 'tp-media-offload-edge-cdn' ); ?></li>
									</ol>

									<div class="cfr2-notice cfr2-notice-info">
										<strong><?php esc_html_e( 'What happens when you deploy:', 'tp-media-offload-edge-cdn' ); ?></strong>
										<ul style="margin: 8px 0 0 16px;">
											<li><?php esc_html_e( 'Old Workers Route (if exists) → Automatically removed to avoid conflicts', 'tp-media-offload-edge-cdn' ); ?></li>
											<li><?php esc_html_e( 'Custom Domain → Created and linked to Worker (handles DNS automatically)', 'tp-media-offload-edge-cdn' ); ?></li>
											<li><?php esc_html_e( 'R2 Public Access → Not required (Worker uses R2 binding for direct access)', 'tp-media-offload-edge-cdn' ); ?></li>
										</ul>
									</div>

									<div class="cfr2-notice cfr2-notice-warning">
										<strong><?php esc_html_e( 'Important:', 'tp-media-offload-edge-cdn' ); ?></strong>
										<?php esc_html_e( 'Do NOT create a DNS record pointing to R2 public domain (pub-xxx.r2.dev). Custom Domain handles everything automatically.', 'tp-media-offload-edge-cdn' ); ?>
									</div>

									<p style="margin-top: 16px;"><strong><?php esc_html_e( 'Requirements:', 'tp-media-offload-edge-cdn' ); ?></strong></p>
									<ul>
										<li><?php esc_html_e( 'Domain must be in your Cloudflare account', 'tp-media-offload-edge-cdn' ); ?></li>
										<li><?php esc_html_e( 'API Token with Workers Scripts, Workers R2 Storage, Zone Read, DNS Edit, Workers Routes Edit, and Cache Purge permissions', 'tp-media-offload-edge-cdn' ); ?></li>
										<li><?php esc_html_e( 'Zone Resources must include your domain', 'tp-media-offload-edge-cdn' ); ?></li>
									</ul>
								</div>
							</details>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="quality"><?php esc_html_e( 'Image Quality', 'tp-media-offload-edge-cdn' ); ?></label>
						</th>
						<td>
							<input type="range" id="quality" name="quality"
								min="1" max="100" value="<?php echo esc_attr( $settings['quality'] ?? 85 ); ?>" />
							<span id="quality-value"><?php echo esc_html( $settings['quality'] ?? 85 ); ?></span>
							<p class="description"><?php esc_html_e( '1-100. Higher = better quality, larger files. Default: 85', 'tp-media-offload-edge-cdn' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label><?php esc_html_e( 'Image Format', 'tp-media-offload-edge-cdn' ); ?></label>
						</th>
						<td>
							<?php $image_format = $settings['image_format'] ?? 'webp'; ?>
							<fieldset>
								<label style="display: block; margin-bottom: 12px;">
									<input type="radio" name="image_format" value="original" <?php checked( 'original', $image_format ); ?> />
									<strong><?php esc_html_e( 'Original', 'tp-media-offload-edge-cdn' ); ?></strong>
									<span class="description" style="display: block; margin-left: 24px; color: #666;">
										<?php esc_html_e( 'Keep original format (JPEG, PNG, GIF). No conversion, maximum compatibility. Larger file sizes.', 'tp-media-offload-edge-cdn' ); ?>
									</span>
								</label>
								<label style="display: block; margin-bottom: 12px;">
									<input type="radio" name="image_format" value="webp" <?php checked( 'webp', $image_format ); ?> />
									<strong><?php esc_html_e( 'WebP (Recommended)', 'tp-media-offload-edge-cdn' ); ?></strong>
									<span class="description" style="display: block; margin-left: 24px; color: #666;">
										<?php esc_html_e( '25-35% smaller than JPEG. Supported by 97%+ browsers. Best balance of compression and compatibility.', 'tp-media-offload-edge-cdn' ); ?>
									</span>
								</label>
								<label style="display: block; margin-bottom: 0;">
									<input type="radio" name="image_format" value="avif" <?php checked( 'avif', $image_format ); ?> />
									<strong><?php esc_html_e( 'AVIF', 'tp-media-offload-edge-cdn' ); ?></strong>
									<span class="description" style="display: block; margin-left: 24px; color: #666;">
										<?php esc_html_e( '50% smaller than JPEG. Best compression. Supported by 93%+ browsers. Falls back to WebP for older browsers.', 'tp-media-offload-edge-cdn' ); ?>
									</span>
								</label>
							</fieldset>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="smart_sizes"><?php esc_html_e( 'Smart Sizes', 'tp-media-offload-edge-cdn' ); ?></label>
						</th>
						<td>
							<input type="hidden" name="smart_sizes" value="0" />
							<label class="cloudflare-r2-offload-cdn-toggle">
								<input type="checkbox" id="smart_sizes" name="smart_sizes" value="1"
									<?php checked( 1, $settings['smart_sizes'] ?? 0 ); ?> />
								<span class="cloudflare-r2-offload-cdn-toggle-slider"></span>
							</label>
							<p class="description"><?php esc_html_e( 'Calculate optimal sizes attribute based on content width. Reduces bandwidth on mobile but increases Cloudflare Transformations cost.', 'tp-media-offload-edge-cdn' ); ?></p>
						</td>
					</tr>
					<tr class="smart-sizes-options" <?php echo empty( $settings['smart_sizes'] ) ? 'style="display:none;"' : ''; ?>>
						<th scope="row">
							<label for="content_max_width"><?php esc_html_e( 'Content Max Width', 'tp-media-offload-edge-cdn' ); ?></label>
						</th>
						<td>
							<input type="number" id="content_max_width" name="content_max_width"
								value="<?php echo esc_attr( $settings['content_max_width'] ?? 800 ); ?>"
								min="320" max="1920" step="10" class="small-text" /> px
							<p class="description"><?php esc_html_e( 'Maximum content area width in your theme. Used to calculate optimal image sizes.', 'tp-media-offload-edge-cdn' ); ?></p>
						</td>
					</tr>
				</table>

				<h3><?php esc_html_e( 'Worker Deployment', 'tp-media-offload-edge-cdn' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Deploy Cloudflare Worker for image transformation.', 'tp-media-offload-edge-cdn' ); ?></p>

				<table class="form-table">
					<tr>
						<th scope="row"><?php esc_html_e( 'Worker Status', 'tp-media-offload-edge-cdn' ); ?></th>
						<td>
							<div id="worker-status" class="cfr2-worker-status">
								<?php
								if ( $worker_deployed ) {
									echo '<span style="color: green;">✓ ' . esc_html__( 'Deployed', 'tp-media-offload-edge-cdn' ) . '</span>';
									if ( ! empty( $settings['worker_deployed_at'] ) ) {
										echo ' <span class="description">(' . esc_html( $settings['worker_deployed_at'] ) . ')</span>';
									}
								} elseif ( $worker_route_active ) {
									echo '<span style="color: green;">✓ ' . esc_html__( 'Route responding', 'tp-media-offload-edge-cdn' ) . '</span>';
									echo ' <span class="description">(' . esc_html__( 'local status will sync on the next deploy/status check', 'tp-media-offload-edge-cdn' ) . ')</span>';
								} else {
									echo '<span style="color: #999;">○ ' . esc_html__( 'Not deployed', 'tp-media-offload-edge-cdn' ) . '</span>';
								}
								?>
							</div>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Actions', 'tp-media-offload-edge-cdn' ); ?></th>
						<td>
							<button type="button" id="deploy-worker" class="button button-primary">
								<?php esc_html_e( 'Deploy Worker', 'tp-media-offload-edge-cdn' ); ?>
							</button>
							<button type="button" id="remove-worker" class="button button-secondary" <?php echo ! $worker_deployed && ! $worker_route_active ? 'style="display:none;"' : ''; ?>>
								<?php esc_html_e( 'Remove Worker', 'tp-media-offload-edge-cdn' ); ?>
							</button>
							<span id="worker-deploy-result" style="margin-left: 10px;"></span>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Cloudflare Diagnostics', 'tp-media-offload-edge-cdn' ); ?></th>
						<td>
							<button type="button" id="cfr2-run-cloudflare-diagnostics" class="button button-secondary">
								<?php esc_html_e( 'Run Diagnostics', 'tp-media-offload-edge-cdn' ); ?>
							</button>
							<p class="description"><?php esc_html_e( 'Runs safe read-only checks and shows whether the blocker is in the plugin, the server, Cloudflare API, DNS, Worker, or R2.', 'tp-media-offload-edge-cdn' ); ?></p>
							<div id="cfr2-cloudflare-diagnostics-result" class="cfr2-diagnostics-result" style="display:none;"></div>
						</td>
					</tr>
				</table>
			</div>
		</div>
		<?php
		$diagnostic_strings = array(
			'running'        => __( 'Running diagnostics...', 'tp-media-offload-edge-cdn' ),
			'runDiagnostics' => __( 'Run Diagnostics', 'tp-media-offload-edge-cdn' ),
			'requestFailed'  => __( 'Diagnostics request failed.', 'tp-media-offload-edge-cdn' ),
			'primaryBlocker' => __( 'Main blocker', 'tp-media-offload-edge-cdn' ),
			'noBlocker'      => __( 'No critical blocker found. Review warnings if any.', 'tp-media-offload-edge-cdn' ),
			'source'         => __( 'Source', 'tp-media-offload-edge-cdn' ),
			'advice'         => __( 'Advice', 'tp-media-offload-edge-cdn' ),
			'ok'             => __( 'OK', 'tp-media-offload-edge-cdn' ),
			'warning'        => __( 'Warning', 'tp-media-offload-edge-cdn' ),
			'error'          => __( 'Error', 'tp-media-offload-edge-cdn' ),
			'saveTokenOnly'  => __( 'Save Token Only', 'tp-media-offload-edge-cdn' ),
			'savingToken'    => __( 'Saving token...', 'tp-media-offload-edge-cdn' ),
			'pasteToken'     => __( 'Paste a new Cloudflare API token before saving.', 'tp-media-offload-edge-cdn' ),
		);
		?>
		<script>
			jQuery(function($) {
				const cfr2DiagnosticStrings = <?php echo wp_json_encode( $diagnostic_strings ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON encoded for inline JS. ?>;
				const escapeHtml = function(value) {
					return $('<div>').text(value || '').html();
				};
				const renderStep = function(step) {
					const status = step.status || 'warning';
					const label = cfr2DiagnosticStrings[status] || status;
					const advice = step.advice ? '<p class="cfr2-diagnostic-advice"><strong>' + escapeHtml(cfr2DiagnosticStrings.advice) + ':</strong> ' + escapeHtml(step.advice) + '</p>' : '';
					return '<li class="cfr2-diagnostic-step cfr2-diagnostic-' + escapeHtml(status) + '">' +
						'<div class="cfr2-diagnostic-step-head">' +
							'<span class="cfr2-diagnostic-badge">' + escapeHtml(label) + '</span>' +
							'<span class="cfr2-diagnostic-source">' + escapeHtml(cfr2DiagnosticStrings.source) + ': ' + escapeHtml(step.source) + '</span>' +
						'</div>' +
						'<p class="cfr2-diagnostic-message">' + escapeHtml(step.message) + '</p>' +
						advice +
					'</li>';
				};

				$('#cfr2-run-cloudflare-diagnostics').on('click', function(e) {
					e.preventDefault();

					const $button = $(this);
					const $result = $('#cfr2-cloudflare-diagnostics-result');

					if ($button.hasClass('is-loading')) {
						return;
					}

					$button.addClass('is-loading').prop('disabled', true).text(cfr2DiagnosticStrings.running);
					$result.show().html('<div class="cfr2-diagnostic-loading"><span class="spinner is-active" style="float:none;margin:0 5px;"></span>' + escapeHtml(cfr2DiagnosticStrings.running) + '</div>');

					$.ajax({
						url: cfr2Admin.ajaxUrl,
						type: 'POST',
						data: {
							action: 'cfr2_diagnose_cloudflare',
							nonce: $('#cfr2_nonce').val()
						},
						success: function(response) {
							if (!response.success || !response.data) {
								$result.html('<div class="cfr2-diagnostic-summary cfr2-diagnostic-error">' + escapeHtml(cfr2DiagnosticStrings.requestFailed) + '</div>');
								return;
							}

							const data = response.data;
							const blocker = data.primary_blocker;
							let html = '';

							if (blocker) {
								html += '<div class="cfr2-diagnostic-summary cfr2-diagnostic-' + escapeHtml(blocker.status) + '">' +
									'<strong>' + escapeHtml(cfr2DiagnosticStrings.primaryBlocker) + ':</strong> ' + escapeHtml(blocker.message) +
									'<br><span>' + escapeHtml(cfr2DiagnosticStrings.source) + ': ' + escapeHtml(blocker.source) + '</span>' +
								'</div>';
							} else {
								html += '<div class="cfr2-diagnostic-summary cfr2-diagnostic-ok">' + escapeHtml(cfr2DiagnosticStrings.noBlocker) + '</div>';
							}

							html += '<ol class="cfr2-diagnostic-steps">';
							(data.steps || []).forEach(function(step) {
								html += renderStep(step);
							});
							html += '</ol>';

							$result.html(html);
						},
						error: function() {
							$result.html('<div class="cfr2-diagnostic-summary cfr2-diagnostic-error">' + escapeHtml(cfr2DiagnosticStrings.requestFailed) + '</div>');
						},
						complete: function() {
							$button.removeClass('is-loading').prop('disabled', false).text(cfr2DiagnosticStrings.runDiagnostics);
						}
					});
				});

				$('#cfr2-save-cloudflare-token').on('click', function(e) {
					e.preventDefault();

					const $button = $(this);
					const $result = $('#cfr2-save-cloudflare-token-result');
					const token = $('#cf_api_token').val();

					if (!token || token === '********') {
						$result.html('<span style="color:#dc3232;">' + escapeHtml(cfr2DiagnosticStrings.pasteToken) + '</span>');
						return;
					}

					if ($button.hasClass('is-loading')) {
						return;
					}

					$button.addClass('is-loading').prop('disabled', true).text(cfr2DiagnosticStrings.savingToken);
					$result.html('<span class="spinner is-active" style="float:none;margin:0 5px;"></span>');

					$.ajax({
						url: cfr2Admin.ajaxUrl,
						type: 'POST',
						data: {
							action: 'cfr2_save_cf_token',
							nonce: $('#cfr2_nonce').val(),
							cloudflare_token_value: token
						},
						success: function(response) {
							if (response.success) {
								$('#cf_api_token').val('********');
								$result.html('<span style="color:#46b450;">' + escapeHtml(response.data.message) + '</span>');
								return;
							}

							$result.html('<span style="color:#dc3232;">' + escapeHtml(response.data && response.data.message ? response.data.message : cfr2DiagnosticStrings.requestFailed) + '</span>');
						},
						error: function() {
							$result.html('<span style="color:#dc3232;">' + escapeHtml(cfr2DiagnosticStrings.requestFailed) + '</span>');
						},
						complete: function() {
							$button.removeClass('is-loading').prop('disabled', false).text(cfr2DiagnosticStrings.saveTokenOnly);
						}
					});
				});
			});
		</script>
		<?php
	}
}
