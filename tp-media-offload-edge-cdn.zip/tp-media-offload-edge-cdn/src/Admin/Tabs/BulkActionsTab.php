<?php
/**
 * Bulk Actions Tab class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Admin\Tabs;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Constants\QueueStatus;

/**
 * BulkActionsTab class - renders the bulk actions tab content.
 */
class BulkActionsTab {

	/**
	 * Render the bulk actions tab.
	 */
	public static function render(): void {
		// Get stats from cached source.
		$stats = DashboardTab::get_cached_stats();

		$total_count         = $stats['total'];
		$offloaded_count     = $stats['offloaded'];
		$pending_count       = $stats['pending'];
		$local_count         = $stats['local'];
		$disk_saveable_count = $stats['disk_saveable'] ?? 0;

		// Get failed count from cache (5-minute transient) to avoid slow DB query on page load.
		// Falls back to 0 if cache expires, refreshed on each retry/cancel action.
		$failed_count = self::get_cached_failed_count();
		?>
		<div class="cloudflare-r2-offload-cdn-tab-content" id="tab-bulk-actions">
			<h2><?php esc_html_e( 'Bulk Actions', 'tp-media-offload-edge-cdn' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Manage bulk offload operations and monitor progress.', 'tp-media-offload-edge-cdn' ); ?></p>

			<?php self::render_quick_stats( $total_count, $offloaded_count, $pending_count, $local_count ); ?>
			<?php self::render_bulk_actions( $failed_count, $offloaded_count, $local_count, $disk_saveable_count ); ?>
			<?php self::render_progress_section(); ?>
			<?php self::render_activity_log(); ?>
			<?php self::render_error_summary(); ?>
		</div>

		<!-- Deferred activity log loading to avoid page hang -->
		<script>
			(function() {
				window.addEventListener('load', function() {
					if (typeof cfr2DeferLoadActivityLog === 'function') {
						cfr2DeferLoadActivityLog();
					}
				});
			})();
		</script>
		<?php
	}

	/**
	 * Render quick stats section.
	 *
	 * @param int $total_count     Total media count.
	 * @param int $offloaded_count Offloaded count.
	 * @param int $pending_count   Pending count.
	 * @param int $local_count     Local count.
	 */
	private static function render_quick_stats( int $total_count, int $offloaded_count, int $pending_count, int $local_count ): void {
		?>
		<div class="settings-section cfr2-quick-stats">
			<h3><?php esc_html_e( 'Quick Stats', 'tp-media-offload-edge-cdn' ); ?></h3>

			<div class="cfr2-stats-row">
				<div class="cfr2-stat">
					<span class="cfr2-stat-value"><?php echo esc_html( number_format_i18n( $total_count ) ); ?></span>
					<span class="cfr2-stat-label"><?php esc_html_e( 'Total Media', 'tp-media-offload-edge-cdn' ); ?></span>
				</div>
				<div class="cfr2-stat">
					<span class="cfr2-stat-value"><?php echo esc_html( number_format_i18n( $offloaded_count ) ); ?></span>
					<span class="cfr2-stat-label"><?php esc_html_e( 'Offloaded', 'tp-media-offload-edge-cdn' ); ?></span>
				</div>
				<div class="cfr2-stat <?php echo $pending_count > 0 ? 'cfr2-stat-clickable' : ''; ?>" <?php echo $pending_count > 0 ? 'id="cfr2-pending-stat"' : ''; ?>>
					<span class="cfr2-stat-value"><?php echo esc_html( number_format_i18n( $pending_count ) ); ?></span>
					<span class="cfr2-stat-label">
						<?php esc_html_e( 'Pending', 'tp-media-offload-edge-cdn' ); ?>
						<?php if ( $pending_count > 0 ) : ?>
							<span class="dashicons dashicons-visibility" style="font-size: 14px; vertical-align: middle;"></span>
						<?php endif; ?>
					</span>
				</div>
				<div class="cfr2-stat">
					<span class="cfr2-stat-value"><?php echo esc_html( number_format_i18n( $local_count ) ); ?></span>
					<span class="cfr2-stat-label"><?php esc_html_e( 'Local', 'tp-media-offload-edge-cdn' ); ?></span>
				</div>
			</div>
		</div>
		<?php
		self::render_pending_items_section();
	}

	/**
	 * Render pending items section (hidden by default).
	 */
	private static function render_pending_items_section(): void {
		?>
		<div id="cfr2-pending-section" class="settings-section" style="display: none;">
			<div class="cfr2-section-header">
				<h3><?php esc_html_e( 'Pending Queue', 'tp-media-offload-edge-cdn' ); ?></h3>
				<div>
					<button type="button" id="cfr2-clear-pending" class="button button-secondary button-small" style="color: #d63638;">
						<?php esc_html_e( 'Clear All', 'tp-media-offload-edge-cdn' ); ?>
					</button>
					<button type="button" id="cfr2-close-pending" class="button button-small">
						<?php esc_html_e( 'Close', 'tp-media-offload-edge-cdn' ); ?>
					</button>
				</div>
			</div>
			<div id="cfr2-pending-list" class="cfr2-pending-list">
				<p class="cfr2-loading"><?php esc_html_e( 'Loading...', 'tp-media-offload-edge-cdn' ); ?></p>
			</div>
		</div>
		<?php
	}

	/**
	 * Render bulk actions section.
	 *
	 * @param int $failed_count       Failed items count.
	 * @param int $offloaded_count    Offloaded items count.
	 * @param int $local_count        Local items count.
	 * @param int $disk_saveable_count Offloaded files with local copies that can be deleted.
	 */
	private static function render_bulk_actions( int $failed_count, int $offloaded_count, int $local_count, int $disk_saveable_count = 0 ): void {
		?>
		<div class="settings-section cfr2-bulk-actions-section">
			<h3><?php esc_html_e( 'Bulk Actions', 'tp-media-offload-edge-cdn' ); ?></h3>

			<div class="cfr2-bulk-actions">
				<?php if ( $local_count > 0 ) : ?>
					<button type="button" id="cfr2-bulk-offload-all" class="button button-primary">
						<?php
						/* translators: %d: number of local items */
						echo esc_html( sprintf( __( 'Offload All (%d)', 'tp-media-offload-edge-cdn' ), $local_count ) );
						?>
					</button>
				<?php endif; ?>
				<?php if ( $offloaded_count > 0 ) : ?>
					<button type="button" id="cfr2-bulk-restore-all" class="button">
						<?php
						/* translators: %d: number of offloaded items */
						echo esc_html( sprintf( __( 'Restore All (%d)', 'tp-media-offload-edge-cdn' ), $offloaded_count ) );
						?>
					</button>
				<?php endif; ?>
				<?php if ( $failed_count > 0 ) : ?>
					<button type="button" id="cfr2-retry-all-failed" class="button">
						<?php
						/* translators: %d: number of failed items */
						echo esc_html( sprintf( __( 'Retry Failed (%d)', 'tp-media-offload-edge-cdn' ), $failed_count ) );
						?>
					</button>
				<?php endif; ?>
				<?php if ( $disk_saveable_count > 0 ) : ?>
					<button type="button" id="cfr2-bulk-delete-local" class="button button-secondary" style="color: #d63638;">
						<?php
						/* translators: %d: number of items with local copies */
						echo esc_html( sprintf( __( 'Free Disk Space (%d)', 'tp-media-offload-edge-cdn' ), $disk_saveable_count ) );
						?>
					</button>
				<?php endif; ?>
				<?php if ( $offloaded_count > 0 ) : ?>
					<button type="button" id="cfr2-migrate-r2-keys" class="button button-secondary">
						<?php esc_html_e( 'Migrate Legacy R2 Keys', 'tp-media-offload-edge-cdn' ); ?>
					</button>
				<?php endif; ?>
				<button type="button" id="cfr2-cancel-bulk" class="button button-secondary" style="display:none;">
					<?php esc_html_e( 'Cancel', 'tp-media-offload-edge-cdn' ); ?>
				</button>
			</div>
			<p class="description" style="margin-top: 8px;">
				<?php esc_html_e( 'Use migration once after upgrades if old offloaded items still return 404 from Worker transforms.', 'tp-media-offload-edge-cdn' ); ?>
			</p>
		</div>
		<?php
	}

	/**
	 * Render progress section.
	 */
	private static function render_progress_section(): void {
		?>
		<div id="cfr2-bulk-progress-section" style="display:none;">
			<div class="settings-section cfr2-progress-section">
				<h3><?php esc_html_e( 'Progress', 'tp-media-offload-edge-cdn' ); ?></h3>

				<div class="cfr2-progress-bar-container">
					<div class="cfr2-progress-bar">
						<div class="cfr2-progress-fill" style="width: 0%;"></div>
					</div>
					<span class="cfr2-progress-percentage">0%</span>
				</div>

				<div class="cfr2-progress-details">
					<p class="cfr2-current-item">
						<strong><?php esc_html_e( 'Current:', 'tp-media-offload-edge-cdn' ); ?></strong>
						<span id="cfr2-current-file"></span>
					</p>
					<p class="cfr2-progress-text"></p>
					<p class="cfr2-elapsed-time">
						<strong><?php esc_html_e( 'Elapsed Time:', 'tp-media-offload-edge-cdn' ); ?></strong>
						<span id="cfr2-elapsed"></span>
					</p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render activity log section (terminal style).
	 */
	private static function render_activity_log(): void {
		?>
		<div class="settings-section cfr2-terminal-section">
			<div class="cfr2-section-header">
				<h3><?php esc_html_e( 'Process Log', 'tp-media-offload-edge-cdn' ); ?></h3>
				<button type="button" id="cfr2-clear-log" class="button button-small">
					<?php esc_html_e( 'Clear', 'tp-media-offload-edge-cdn' ); ?>
				</button>
			</div>

			<div class="cfr2-terminal" id="cfr2-terminal">
				<div class="cfr2-terminal-header">
					<span class="cfr2-terminal-dot red"></span>
					<span class="cfr2-terminal-dot yellow"></span>
					<span class="cfr2-terminal-dot green"></span>
					<span class="cfr2-terminal-title"><?php esc_html_e( 'R2 Offload Terminal', 'tp-media-offload-edge-cdn' ); ?></span>
				</div>
				<div class="cfr2-terminal-body" id="cfr2-terminal-output">
					<div class="cfr2-terminal-line cfr2-terminal-info">
						<span class="cfr2-terminal-prompt">$</span>
						<span><?php esc_html_e( 'Ready. Click "Offload All Media" to start.', 'tp-media-offload-edge-cdn' ); ?></span>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render error summary section.
	 */
	private static function render_error_summary(): void {
		?>
		<div id="cfr2-error-summary-section" style="display:none;">
			<div class="settings-section cfr2-error-summary-section">
				<div class="cfr2-section-header">
					<h3><?php esc_html_e( 'Failed Items', 'tp-media-offload-edge-cdn' ); ?></h3>
					<button type="button" id="cfr2-retry-all" class="button button-primary button-small">
						<?php esc_html_e( 'Retry All', 'tp-media-offload-edge-cdn' ); ?>
					</button>
				</div>

				<div class="cfr2-error-summary" id="cfr2-error-list"></div>
			</div>
		</div>
		<?php
	}

	/**
	 * Get failed count from cache or compute once.
	 * Reduces page load time by caching the count instead of fresh DB query.
	 *
	 * @return int Failed items count (24-hour window).
	 */
	private static function get_cached_failed_count(): int {
		$transient_key = 'cfr2_failed_count_cache';
		$cached        = get_transient( $transient_key );

		// Return cached value if available.
		if ( false !== $cached && is_numeric( $cached ) ) {
			return (int) $cached;
		}

		// Compute and cache for 5 minutes.
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom queue table.
		$failed_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT attachment_id)
				 FROM {$wpdb->prefix}cfr2_offload_queue
				 WHERE status = %s
				 AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)",
				QueueStatus::FAILED
			)
		);

		set_transient( $transient_key, $failed_count, 5 * MINUTE_IN_SECONDS );

		return $failed_count;
	}

	/**
	 * Clear failed count cache (call after retry/cancel operations).
	 */
	public static function clear_failed_count_cache(): void {
		delete_transient( 'cfr2_failed_count_cache' );
	}
}

