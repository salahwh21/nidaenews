<?php
/**
 * Offload Tab class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Admin\Tabs;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Services\PluginSettings;

/**
 * OffloadTab class - renders offload behavior settings.
 */
class OffloadTab {

	/**
	 * Render the offload tab.
	 *
	 * @param array $settings Current settings.
	 */
	public static function render( array $settings ): void {
		?>
		<div class="cloudflare-r2-offload-cdn-tab-content" id="tab-offload">
			<h2><?php esc_html_e( 'Offload Settings', 'tp-media-offload-edge-cdn' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Configure how media files are offloaded to R2 storage.', 'tp-media-offload-edge-cdn' ); ?></p>

			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="auto_offload"><?php esc_html_e( 'Auto-Offload on Upload', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<input type="hidden" name="auto_offload" value="0" />
						<label class="cloudflare-r2-offload-cdn-toggle">
							<input type="checkbox" id="auto_offload" name="auto_offload" value="1"
								<?php checked( 1, $settings['auto_offload'] ?? 0 ); ?> />
							<span class="cloudflare-r2-offload-cdn-toggle-slider"></span>
						</label>
						<p class="description"><?php esc_html_e( 'Automatically offload media files to R2 when uploaded.', 'tp-media-offload-edge-cdn' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="batch_size"><?php esc_html_e( 'Batch Size', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<select id="batch_size" name="batch_size" class="regular-text">
							<option value="1" <?php selected( 1, $settings['batch_size'] ?? 1 ); ?>>
								<?php esc_html_e( '1 file per batch', 'tp-media-offload-edge-cdn' ); ?>
							</option>
							<option value="3" <?php selected( 3, $settings['batch_size'] ?? 1 ); ?>>
								<?php esc_html_e( '3 files per batch', 'tp-media-offload-edge-cdn' ); ?>
							</option>
							<option value="5" <?php selected( 5, $settings['batch_size'] ?? 1 ); ?>>
								<?php esc_html_e( '5 files per batch', 'tp-media-offload-edge-cdn' ); ?>
							</option>
							<option value="10" <?php selected( 10, $settings['batch_size'] ?? 1 ); ?>>
								<?php esc_html_e( '10 files per batch', 'tp-media-offload-edge-cdn' ); ?>
							</option>
						</select>
						<p class="description"><?php esc_html_e( 'Number of files to process in each background batch. Use 1 on shared hosting to avoid memory errors.', 'tp-media-offload-edge-cdn' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="keep_local_files"><?php esc_html_e( 'Keep Local Files', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<input type="hidden" name="keep_local_files" value="0" />
						<label class="cloudflare-r2-offload-cdn-toggle">
							<input type="checkbox" id="keep_local_files" name="keep_local_files" value="1"
								<?php checked( 1, $settings['keep_local_files'] ?? 1 ); ?> />
							<span class="cloudflare-r2-offload-cdn-toggle-slider"></span>
						</label>
						<p class="description"><?php esc_html_e( 'Keep local copies of files after offloading to R2. Disable to save disk space (files will be served from R2/CDN).', 'tp-media-offload-edge-cdn' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="sync_delete"><?php esc_html_e( 'Sync Delete', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<input type="hidden" name="sync_delete" value="0" />
						<label class="cloudflare-r2-offload-cdn-toggle">
							<input type="checkbox" id="sync_delete" name="sync_delete" value="1"
								<?php checked( 1, $settings['sync_delete'] ?? 0 ); ?> />
							<span class="cloudflare-r2-offload-cdn-toggle-slider"></span>
						</label>
						<p class="description"><?php esc_html_e( 'When deleting media from WordPress, also delete from R2 storage. Disable to keep R2 copies as backup.', 'tp-media-offload-edge-cdn' ); ?></p>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}
}
