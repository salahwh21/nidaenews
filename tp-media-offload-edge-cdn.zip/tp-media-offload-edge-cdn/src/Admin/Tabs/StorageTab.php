<?php
/**
 * Storage Tab class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Admin\Tabs;

defined( 'ABSPATH' ) || exit;

/**
 * StorageTab class - renders R2 storage credentials and connection test.
 */
class StorageTab {

	/**
	 * Render the storage tab.
	 *
	 * @param array $settings Current settings.
	 */
	public static function render( array $settings ): void {
		?>
		<div class="cloudflare-r2-offload-cdn-tab-content" id="tab-storage">
			<h2><?php esc_html_e( 'R2 Storage Configuration', 'tp-media-offload-edge-cdn' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Configure your Cloudflare R2 storage credentials. Get these from Cloudflare Dashboard > R2 > Manage R2 API Tokens.', 'tp-media-offload-edge-cdn' ); ?></p>

			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="r2_account_id"><?php esc_html_e( 'Account ID', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<input type="text" id="r2_account_id" name="r2_account_id"
							value="<?php echo esc_attr( $settings['r2_account_id'] ?? '' ); ?>"
							class="regular-text" autocomplete="off" />
						<p class="description"><?php esc_html_e( 'Your Cloudflare account ID (alphanumeric).', 'tp-media-offload-edge-cdn' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="r2_region"><?php esc_html_e( 'Region', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<input type="text" id="r2_region" name="r2_region"
							value="<?php echo esc_attr( $settings['r2_region'] ?? 'auto' ); ?>"
							class="regular-text" placeholder="auto" autocomplete="off" />
						<p class="description"><?php esc_html_e( 'Use "auto" for Cloudflare R2. Change only for compatible S3 providers that require a specific region.', 'tp-media-offload-edge-cdn' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="r2_endpoint"><?php esc_html_e( 'S3 Endpoint', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<input type="url" id="r2_endpoint" name="r2_endpoint"
							value="<?php echo esc_url( $settings['r2_endpoint'] ?? '' ); ?>"
							class="regular-text" placeholder="https://account-id.r2.cloudflarestorage.com" autocomplete="off" />
						<p class="description"><?php esc_html_e( 'Optional. Leave empty to build the Cloudflare R2 endpoint from Account ID. Do not include the bucket name at the end.', 'tp-media-offload-edge-cdn' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="r2_access_key_id"><?php esc_html_e( 'Access Key ID', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<input type="text" id="r2_access_key_id" name="r2_access_key_id"
							value="<?php echo esc_attr( $settings['r2_access_key_id'] ?? '' ); ?>"
							class="regular-text" autocomplete="off" />
						<p class="description"><?php esc_html_e( 'R2 Access Key ID from API token.', 'tp-media-offload-edge-cdn' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="r2_secret_access_key"><?php esc_html_e( 'Secret Access Key', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<?php
						$secret_value = ! empty( $settings['r2_secret_access_key'] ) ? '********' : '';
						?>
						<input type="password" id="r2_secret_access_key" name="r2_secret_access_key"
							value="<?php echo esc_attr( $secret_value ); ?>"
							class="regular-text" autocomplete="new-password" />
						<p class="description"><?php esc_html_e( 'R2 Secret Access Key (encrypted in database). Leave blank to keep existing value.', 'tp-media-offload-edge-cdn' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="r2_bucket"><?php esc_html_e( 'Bucket Name', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<input type="text" id="r2_bucket" name="r2_bucket"
							value="<?php echo esc_attr( $settings['r2_bucket'] ?? '' ); ?>"
							class="regular-text" />
						<p class="description"><?php esc_html_e( 'R2 bucket name (lowercase alphanumeric and hyphens only).', 'tp-media-offload-edge-cdn' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="r2_public_domain"><?php esc_html_e( 'Public Domain', 'tp-media-offload-edge-cdn' ); ?></label>
					</th>
					<td>
						<input type="url" id="r2_public_domain" name="r2_public_domain"
							value="<?php echo esc_url( $settings['r2_public_domain'] ?? '' ); ?>"
							class="regular-text" placeholder="https://pub-xxx.r2.dev" />
						<p class="description">
							<?php esc_html_e( 'Optional public URL for direct R2 delivery. The Worker uses an R2 binding, so public bucket access is not required for image optimization.', 'tp-media-offload-edge-cdn' ); ?>
							<br>
							<?php esc_html_e( 'Use R2.dev subdomain (e.g., https://pub-xxx.r2.dev) or custom domain.', 'tp-media-offload-edge-cdn' ); ?>
							<br>
							<?php esc_html_e( 'To enable public access, follow the "Public buckets" section in Cloudflare R2 documentation.', 'tp-media-offload-edge-cdn' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Connection Test', 'tp-media-offload-edge-cdn' ); ?></th>
					<td>
						<button type="button" id="test-r2-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'tp-media-offload-edge-cdn' ); ?>
						</button>
						<span id="r2-connection-result" style="margin-left: 10px;"></span>
						<p class="description"><?php esc_html_e( 'Verify R2 credentials by testing connection.', 'tp-media-offload-edge-cdn' ); ?></p>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}
}
