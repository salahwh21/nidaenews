<?php
/**
 * REST API Helper class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Integrations;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Services\PluginSettings;
use Salahdev\NidaEdge\Traits\CredentialsHelperTrait;

/**
 * RestApiHelper class - helper methods for REST API.
 */
class RestApiHelper {

	use CredentialsHelperTrait;

	/**
	 * Validate attachment ID parameter.
	 *
	 * @param mixed $param Parameter value.
	 * @return bool True if valid.
	 */
	public static function validate_attachment_id( $param ): bool {
		return is_numeric( $param ) && $param > 0;
	}

	/**
	 * Verify attachment exists and is valid.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return \WP_Post|false Attachment post or false.
	 */
	public static function verify_attachment( int $attachment_id ) {
		$attachment = get_post( $attachment_id );
		if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
			return false;
		}
		return $attachment;
	}

	/**
	 * Get R2 credentials from settings.
	 *
	 * @return array R2 credentials.
	 */
	public static function get_credentials(): array {
		return self::get_r2_credentials();
	}

	/**
	 * Check read permission.
	 *
	 * @return bool True if has permission.
	 */
	public static function check_read_permission(): bool {
		return current_user_can( 'upload_files' );
	}

	/**
	 * Check permission for /stats (sensitive aggregates).
	 *
	 * Default: manage_options. Override with filter cfr2_rest_stats_capability.
	 *
	 * @return bool
	 */
	public static function check_stats_permission(): bool {
		/**
		 * Capability required for GET /cfr2/v1/stats.
		 *
		 * @param string $capability Default manage_options.
		 */
		$capability = apply_filters( 'cfr2_rest_stats_capability', 'manage_options' );

		return is_string( $capability ) && '' !== $capability && current_user_can( $capability );
	}

	/**
	 * Check attachment endpoint permission.
	 *
	 * Anonymous access when filter cfr2_rest_public_attachment_endpoint is true
	 * or when setting rest_public_attachment is enabled (see System Info tab).
	 *
	 * @return bool True if has permission.
	 */
	public static function check_attachment_permission(): bool {
		if ( (bool) apply_filters( 'cfr2_rest_public_attachment_endpoint', false ) ) {
			return true;
		}

		$settings = PluginSettings::get();
		if ( ! empty( $settings['rest_public_attachment'] ) ) {
			return true;
		}

		return self::check_read_permission();
	}

	/**
	 * When the attachment endpoint is public, omit storage URLs for users without upload_files.
	 *
	 * @return bool
	 */
	public static function should_redact_attachment_rest_payload(): bool {
		return ! current_user_can( 'upload_files' );
	}

	/**
	 * Check write permission.
	 *
	 * @return bool True if has permission.
	 */
	public static function check_write_permission(): bool {
		return current_user_can( 'upload_files' );
	}

	/**
	 * Check admin permission.
	 *
	 * @return bool True if has permission.
	 */
	public static function check_admin_permission(): bool {
		return current_user_can( 'manage_options' );
	}
}
