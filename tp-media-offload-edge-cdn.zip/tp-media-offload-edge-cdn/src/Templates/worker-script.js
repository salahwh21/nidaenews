/**
 * CloudFlare R2 CDN Worker
 * Auto-deployed by WordPress plugin
 * Version: {{VERSION}}
 *
 * Uses R2 binding for direct bucket access (faster, no public access needed).
 * Enhanced with smart caching and performance optimizations.
 */
export default {
	async fetch(request, env) {
		const url = new URL(request.url);

		if (url.pathname === '/health') {
			return new Response('ok', {
				status: 200,
				headers: {
					'Cache-Control': 'no-store',
					'X-CFR2-Health': 'ok',
				},
			});
		}

		if (url.pathname.startsWith('/_cfr2_origin/')) {
			const originKey = decodeURIComponent(url.pathname.replace('/_cfr2_origin/', ''));
			return fetchOriginalByKey(env, originKey);
		}

		// Remove leading slash for R2 key
		const key = url.pathname.slice(1);

		if (!key) {
			return new Response('Not Found', { status: 404 });
		}

		try {
			// Get object directly from R2 bucket with legacy key fallback.
			const object = await getObjectWithFallback(env, key);

			if (!object) {
				return new Response('Not Found', { status: 404 });
			}

			// Determine content type
			const contentType = object.httpMetadata?.contentType || getMimeType(key);

			// Build response headers with enhanced caching
			const headers = new Headers();
			headers.set('Content-Type', contentType);
			headers.set('Cache-Control', 'public, max-age=31536000, immutable, stale-while-revalidate=86400');
			headers.set('ETag', object.httpEtag);
			headers.set('X-CFR2-Source', 'r2-binding');
			headers.set('X-Content-Type-Options', 'nosniff');

			// Handle conditional requests
			const ifNoneMatch = request.headers.get('If-None-Match');
			if (ifNoneMatch === object.httpEtag) {
				return new Response(null, { status: 304, headers });
			}

			// Check if image transformation is requested
			const isImage = /\.(jpg|jpeg|png|gif|webp|avif)$/i.test(key);
			const hasTransformParams = url.searchParams.has('width') || url.searchParams.has('height') ||
				url.searchParams.has('quality') || url.searchParams.has('format') ||
				url.searchParams.has('w') || url.searchParams.has('h') ||
				url.searchParams.has('q') || url.searchParams.has('f');

			if (isImage && hasTransformParams) {
				// For image transformation, use cf.image with origin fetch
				// This requires constructing a URL to the same object
				return handleImageTransform(request, env, key, url, headers);
			}

			// Return object directly
			return new Response(object.body, { headers });

		} catch (error) {
			return new Response(`Error: ${error.message}`, { 
				status: 500,
				headers: {
					'X-CFR2-Error': error.message,
				}
			});
		}
	}
};

/**
 * Handle image transformation using cf.image with enhanced caching
 */
async function handleImageTransform(request, env, key, url, baseHeaders) {
	if (request.method !== 'GET') {
		return fetchOriginalFromBucket(env, key, baseHeaders);
	}

	const cache = caches.default;
	const cacheUrl = new URL(url.toString());
	cacheUrl.searchParams.set('__cfr2_worker_version', '{{VERSION}}');
	const cacheKey = new Request(cacheUrl.toString(), { method: 'GET', headers: request.headers });
	const cached = await cache.match(cacheKey);

	if (cached) {
		const headers = new Headers(cached.headers);
		headers.set('X-CFR2-Cache', 'HIT');
		headers.set('Age', Math.floor((Date.now() - new Date(cached.headers.get('Date') || 0).getTime()) / 1000).toString());
		return new Response(cached.body, {
			status: cached.status,
			statusText: cached.statusText,
			headers,
		});
	}

	const options = { cf: { image: {} } };

	// Width
	const width = url.searchParams.get('width') || url.searchParams.get('w');
	if (width) {
		options.cf.image.width = parseInt(width, 10);
	}

	// Height
	const height = url.searchParams.get('height') || url.searchParams.get('h');
	if (height) {
		options.cf.image.height = parseInt(height, 10);
	}

	// Quality (1-100)
	const quality = url.searchParams.get('quality') || url.searchParams.get('q');
	if (quality) {
		options.cf.image.quality = Math.min(100, Math.max(1, parseInt(quality, 10)));
	}

	// Fit mode
	const fit = url.searchParams.get('fit');
	if (fit && ['scale-down', 'contain', 'cover', 'crop', 'pad'].includes(fit)) {
		options.cf.image.fit = fit;
	}

	// Format negotiation based on IMAGE_FORMAT setting (original, webp, avif)
	const imageFormat = env.IMAGE_FORMAT || 'webp';
	const format = url.searchParams.get('format') || url.searchParams.get('f');
	if ((format === 'auto' || !format) && imageFormat !== 'original') {
		const accept = request.headers.get('Accept') || '';
		if (imageFormat === 'avif' && /image\/avif/.test(accept)) {
			options.cf.image.format = 'avif';
		} else if (/image\/webp/.test(accept)) {
			options.cf.image.format = 'webp';
		}
	} else if (format && ['webp', 'avif', 'json'].includes(format)) {
		options.cf.image.format = format;
	}

	// cf.image needs an HTTP origin that returns the raw bytes. Using request.url.origin fails when
	// the hostname is an R2 public custom domain: subrequests do not re-enter this Worker, so /_cfr2_origin/* 404s (ERROR 9404).
	// WORKER_SELF_URL is the script's *.workers.dev origin, which always runs this fetch handler.
	const selfBase =
		typeof env.WORKER_SELF_URL === 'string' && env.WORKER_SELF_URL.trim() !== ''
			? env.WORKER_SELF_URL.trim().replace(/\/$/, '')
			: new URL(request.url).origin;

	const originUrl = new URL(selfBase + '/_cfr2_origin/' + encodeURIComponent(key));

	try {
		const originRequest = new Request(originUrl.toString(), {
			method: 'GET',
			headers: {
				'X-CFR2-Origin': '1',
			},
		});

		const response = await fetch(originRequest, options);

		const headers = new Headers(response.headers);
		headers.set('Cache-Control', 'public, max-age=31536000, immutable, stale-while-revalidate=86400');
		headers.set('X-CFR2-Transform', 'true');
		headers.set('X-CFR2-Cache', 'MISS');
		headers.set('X-CFR2-Transform-Time', Date.now().toString());
		headers.set('Date', new Date().toUTCString());

		const transformed = new Response(response.body, {
			status: response.status,
			headers,
		});

		if (response.ok) {
			await cache.put(cacheKey, transformed.clone());
		}

		return transformed;
	} catch (error) {
		// Fallback: serve original from R2
		baseHeaders.set('X-CFR2-Transform', 'fallback');
		baseHeaders.set('X-CFR2-Transform-Error', error.message || 'unknown');
		return fetchOriginalFromBucket(env, key, baseHeaders);
	}
}

/**
 * Serve the original object directly from R2.
 */
async function fetchOriginalFromBucket(env, key, headers) {
	const object = await getObjectWithFallback(env, key);
	if (object) {
		return new Response(object.body, { headers });
	}
	return new Response('Transform failed', { status: 500 });
}

/**
 * Serve the original object for internal image transformation fetches with enhanced caching.
 */
async function fetchOriginalByKey(env, key) {
	if (!key) {
		return new Response('Not Found', { status: 404 });
	}

	const object = await getObjectWithFallback(env, key);
	if (!object) {
		return new Response('Not Found', { status: 404 });
	}

	const headers = new Headers();
	headers.set('Content-Type', object.httpMetadata?.contentType || getMimeType(key));
	headers.set('Cache-Control', 'public, max-age=31536000, immutable, stale-while-revalidate=86400');
	headers.set('ETag', object.httpEtag);
	headers.set('X-CFR2-Source', 'r2-origin');
	headers.set('X-Content-Type-Options', 'nosniff');

	return new Response(object.body, { headers });
}

/**
 * Fetch object with backwards-compatible key fallback.
 * Supports both layouts:
 * - uploads/2026/05/file.jpg
 * - 2026/05/file.jpg
 */
async function getObjectWithFallback(env, key) {
	const normalizedKey = String(key || '').replace(/^\/+/, '');
	if (!normalizedKey) {
		return null;
	}

	let object = await env.BUCKET.get(normalizedKey);
	if (object) {
		return object;
	}

	if (normalizedKey.startsWith('uploads/')) {
		object = await env.BUCKET.get(normalizedKey.slice('uploads/'.length));
		if (object) {
			return object;
		}
	} else {
		object = await env.BUCKET.get('uploads/' + normalizedKey);
		if (object) {
			return object;
		}
	}

	return null;
}

/**
 * Get MIME type from file extension
 */
function getMimeType(filename) {
	const ext = filename.split('.').pop()?.toLowerCase();
	const mimeTypes = {
		'jpg': 'image/jpeg',
		'jpeg': 'image/jpeg',
		'png': 'image/png',
		'gif': 'image/gif',
		'webp': 'image/webp',
		'avif': 'image/avif',
		'svg': 'image/svg+xml',
		'ico': 'image/x-icon',
		'pdf': 'application/pdf',
		'css': 'text/css',
		'js': 'application/javascript',
		'json': 'application/json',
		'html': 'text/html',
		'txt': 'text/plain',
		'xml': 'application/xml',
		'mp4': 'video/mp4',
		'webm': 'video/webm',
		'mp3': 'audio/mpeg',
		'woff': 'font/woff',
		'woff2': 'font/woff2',
		'ttf': 'font/ttf',
		'eot': 'application/vnd.ms-fontobject',
	};
	return mimeTypes[ext] || 'application/octet-stream';
}
