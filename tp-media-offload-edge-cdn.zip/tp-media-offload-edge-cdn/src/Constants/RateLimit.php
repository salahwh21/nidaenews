<?php
/**
 * Rate Limiting Configuration Constants.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Constants;

defined( 'ABSPATH' ) || exit;

/**
 * Rate limiting configuration.
 */
class RateLimit {
	public const MAX_SAVES  = 10;
	public const WINDOW_SEC = 60;
}
