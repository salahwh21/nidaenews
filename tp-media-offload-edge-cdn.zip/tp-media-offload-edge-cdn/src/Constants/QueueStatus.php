<?php
/**
 * Queue Status Constants.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Constants;

defined( 'ABSPATH' ) || exit;

/**
 * Queue status constants.
 */
class QueueStatus {
	public const PENDING    = 'pending';
	public const PROCESSING = 'processing';
	public const COMPLETED  = 'completed';
	public const FAILED     = 'failed';
	public const CANCELLED  = 'cancelled';
}
