<?php
/**
 * Batch Processing Configuration Constants.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Constants;

defined( 'ABSPATH' ) || exit;

/**
 * Batch processing configuration.
 */
class BatchConfig {
	public const DEFAULT_SIZE = 1;
	public const MIN_SIZE     = 1;
	public const MAX_SIZE     = 50;
}
