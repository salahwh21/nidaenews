<?php
/**
 * Meta Keys Constants.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Constants;

defined( 'ABSPATH' ) || exit;

/**
 * Meta keys for attachment tracking.
 */
class MetaKeys {
	public const OFFLOADED  = '_cfr2_offloaded';
	public const R2_URL     = '_cfr2_r2_url';
	public const R2_KEY     = '_cfr2_r2_key';
	public const LOCAL_URL  = '_cfr2_local_url';
	public const THUMBNAILS = '_cfr2_thumbnails';
}
