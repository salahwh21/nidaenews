<?php
/**
 * HTTP Configuration Constants.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Constants;

defined( 'ABSPATH' ) || exit;

/**
 * HTTP configuration constants.
 */
class HttpConfig {
	public const TIMEOUT         = 30;
	public const CONNECT_TIMEOUT = 10;
}
