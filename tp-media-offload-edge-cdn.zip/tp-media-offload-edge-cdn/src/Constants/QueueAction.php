<?php
/**
 * Queue Action Constants.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Constants;

defined( 'ABSPATH' ) || exit;

/**
 * Queue action constants.
 */
class QueueAction {
	public const OFFLOAD      = 'offload';
	public const RESTORE      = 'restore';
	public const DELETE_LOCAL = 'delete_local';
}
