<?php
/**
 * Hookable Interface.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Interfaces;

defined( 'ABSPATH' ) || exit;

/**
 * Interface for classes that register WordPress hooks.
 */
interface HookableInterface {

	/**
	 * Register hooks with WordPress.
	 */
	public function register_hooks(): void;
}
