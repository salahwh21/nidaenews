<?php
/**
 * Plugin Activator class.
 *
 * @package NidaEdge
 */

namespace Salahdev\NidaEdge\Core;

defined( 'ABSPATH' ) || exit;

use Salahdev\NidaEdge\Database\Schema;
use Salahdev\NidaEdge\Services\PluginSettings;

/**
 * Activator class - runs on plugin activation.
 */
class Activator {

	/**
	 * Activate the plugin.
	 */
	public static function activate( bool $network_wide = false ): void {
		// Check PHP version.
		if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
			wp_die(
				esc_html__( 'This plugin requires PHP 8.0 or higher.', 'tp-media-offload-edge-cdn' ),
				'Plugin Activation Error',
				array( 'back_link' => true )
			);
		}

		// Check WP version.
		if ( version_compare( get_bloginfo( 'version' ), '6.0', '<' ) ) {
			wp_die(
				esc_html__( 'This plugin requires WordPress 6.0 or higher.', 'tp-media-offload-edge-cdn' ),
				'Plugin Activation Error',
				array( 'back_link' => true )
			);
		}

		if ( is_multisite() && $network_wide && function_exists( 'get_sites' ) ) {
			$site_ids = get_sites( array( 'fields' => 'ids' ) );
			foreach ( $site_ids as $site_id ) {
				switch_to_blog( (int) $site_id );
				self::activate_for_site();
				restore_current_blog();
			}
			flush_rewrite_rules();
			return;
		}

		self::activate_for_site();

		flush_rewrite_rules();
	}

	private static function activate_for_site(): void {
		// Create database tables.
		Schema::create_tables();

		// Schedule stats cleanup.
		if ( ! wp_next_scheduled( 'cfr2_cleanup_stats' ) ) {
			wp_schedule_event( time(), 'weekly', 'cfr2_cleanup_stats' );
		}

		// Create default settings with the canonical schema.
		PluginSettings::initialize();
	}
}
