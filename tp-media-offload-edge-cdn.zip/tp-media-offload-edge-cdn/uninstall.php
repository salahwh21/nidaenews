<?php
/**
 * Uninstall script.
 *
 * Fired when the plugin is deleted (not deactivated).
 * Removes all plugin data: options, tables, post meta, transients.
 *
 * @package NidaEdge
 */

// Exit if not called by WordPress.
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

$settings_option_key = 'cfr2_settings';

$cleanup_site = static function () use ( $wpdb, $settings_option_key ): void {
	$cfr2_settings = get_option( $settings_option_key, array() );
	if ( ! is_array( $cfr2_settings ) ) {
		$cfr2_settings = array();
	}
	if ( ! empty( $cfr2_settings['r2_secret_access_key'] ) ) {
		$cfr2_settings['r2_secret_access_key'] = str_repeat( '0', strlen( $cfr2_settings['r2_secret_access_key'] ) );
	}
	if ( ! empty( $cfr2_settings['cf_api_token'] ) ) {
		$cfr2_settings['cf_api_token'] = str_repeat( '0', strlen( $cfr2_settings['cf_api_token'] ) );
	}
	update_option( $settings_option_key, $cfr2_settings );

	delete_option( $settings_option_key );
	delete_option( 'cfr2_db_version' );
	delete_option( 'cfr2_cf_api_token' );

	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}cfr2_offload_status" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}cfr2_offload_queue" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}cfr2_stats" );
	// phpcs:enable

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE %s",
			'_cfr2_%'
		)
	);

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( '_transient_cfr2_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_cfr2_' ) . '%'
		)
	);

	wp_clear_scheduled_hook( 'cfr2_process_queue' );
	wp_clear_scheduled_hook( 'cfr2_cleanup_stats' );
};

if ( is_multisite() && function_exists( 'get_sites' ) ) {
	$site_ids = get_sites( array( 'fields' => 'ids' ) );
	foreach ( $site_ids as $site_id ) {
		switch_to_blog( (int) $site_id );
		$cleanup_site();
		restore_current_blog();
	}
} else {
	$cleanup_site();
}
