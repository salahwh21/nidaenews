<?php
/**
 * @package NidaEdge
 */

declare(strict_types=1);

namespace Salahdev\NidaEdge\Tests\Unit;

use PHPUnit\Framework\TestCase;
use Salahdev\NidaEdge\Services\RequestCorrelation;

/**
 * @covers \Salahdev\NidaEdge\Services\RequestCorrelation
 */
class RequestCorrelationTest extends TestCase {

	public function test_get_id_matches_hex_pattern(): void {
		$id = RequestCorrelation::get_id();
		$this->assertMatchesRegularExpression( '/^[a-f0-9]{16}$/', $id );
	}

	public function test_get_id_is_stable_within_same_process(): void {
		$this->assertSame( RequestCorrelation::get_id(), RequestCorrelation::get_id() );
	}

	public function test_enrich_failure_adds_request_id(): void {
		$out = RequestCorrelation::enrich_failure( array( 'success' => false, 'message' => 'x' ) );
		$this->assertArrayHasKey( 'request_id', $out );
		$this->assertSame( RequestCorrelation::get_id(), $out['request_id'] );
	}

	public function test_enrich_failure_skips_success(): void {
		$out = RequestCorrelation::enrich_failure( array( 'success' => true ) );
		$this->assertArrayNotHasKey( 'request_id', $out );
	}
}
