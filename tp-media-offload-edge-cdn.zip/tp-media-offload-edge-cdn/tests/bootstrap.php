<?php
/**
 * PHPUnit bootstrap (minimal — no WordPress test install).
 *
 * @package NidaEdge
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', '/' );
}

require dirname(__DIR__) . '/vendor/autoload.php';
